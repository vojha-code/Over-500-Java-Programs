import java.io.*;
class BinarySearch
{

  public static void main(String args[])
  {
   try
   {

    int n=5;
    int array[]=new int[n];
    int key;
    boolean flag=false;
    int i;

    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

    for(i=0;i<n;i++)
    {
      array[i]=i*2;
      System.out.println("array["+i+"]="+array[i]);
    }

     System.out.print("\nEnter The search element to be searched:");
     key=Integer.parseInt(br.readLine());

     int mid,high=n,low=0;
     boolean found=false;
     mid=(high+low)/2;

     while((!found)&&(high>=low))
     {
       if(array[mid]==key)
       {
        flag=true;
        System.out.println("The Element "+key+" is found at position array["+mid+"]");
        found=true;
        break;
       }
       else if(key<array[mid])
        high=mid-1;
       else
        low=mid+1;
      mid=(high+low)/2;
    }
      if(!flag)
       System.out.println("The element is not found");
    }
    catch(Exception e)
    {
      System.out.println(e);
    }

  }
}
