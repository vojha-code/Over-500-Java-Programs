class BubbleSort
{

  void bubblesort(int a[],int n)
  {
    int i=1,j,t;
    boolean flag=true;

    while((i<n) && (flag))
    {
     flag=false;

      for(j=0;j<n-i;j++)
      {
        if(a[j]>a[j+1])
        {
         flag=true;

          t=a[j];
          a[j]=a[j+1];
          a[j+1]=t;
        }
      System.out.print("Step "+j+"  : ");
        for(int p=0;p<5;p++)
          System.out.print("  "+a[p]);
        System.out.println();

      }
    System.out.print("Pass "+i+"  : ");
      for(int p=0;p<5;p++)
        System.out.print("  "+a[p]);
    System.out.println("\n");

     i++;
    }
  }

 void display(int a[],int n)
 {
   for(int i=0;i<5;i++)
     System.out.print(" "+a[i]);
 }

  public static void main(String args[])
  {

    int a[]=new int[5];

    a[0]=5;
    a[1]=1;
    a[2]=4;
    a[3]=2;
    a[4]=8;


   BubbleSort b=new BubbleSort();

    System.out.println();
    System.out.print("Array Before Sort -->");
    b.display(a,5);
    System.out.println("\n");

    b.bubblesort(a,5);

    System.out.print("\nArray After Sort -->");
    b.display(a,5);
    System.out.println();

  }

}

