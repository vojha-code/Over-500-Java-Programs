import java.util.Random;
public class MatTanas
{
   public int row=4,col=4;
   public float X[][]=new float[row][col];
   public float X_T[][]=new float[row][col]; 


    double randomVaue()
    {
     Random rand = new Random();
     double prob ;
     return prob =  (100 * rand.nextDouble());
     //return prob =  rand.nextDouble();

    } 


    void mat_Trans(float transp[][],int row1,int col1)
    {
	for(int i = 0; i< row1; i++)
	{
		for(int j = 0; j < col1; j++)
		{
			X_T[i][j] = transp[j][i] ;
		}
	}

      display(X_T,row1,col1);
    }

   

     void mat_X_input(float X[][],int n,int m)
     {
         for(int i=0;i<n;i++)
            for(int j=0;j<m;j++)
              X[i][j]=(float)randomVaue();
       
         display(X,n,m);
     }    
    
    void display(float d[][],int n,int m)
    {
     for(int i=0;i<n;i++)
     {
       for(int j=0;j<m;j++)
         System.out.print(d[i][j]+" ");
       System.out.println();
     }
    }

    void linear_regression()
    {    
        
          System.out.println("\nThis is The Input Matrix\n"); 
          mat_X_input(X,row,col); 
          System.out.println("\nThis is The Transposed Matrix\n");          
          mat_Trans(X,row,col);
         
 
    } 

    public static void main(String[] args) 
    {
           
        MatTanas rbsa=new MatTanas();
        rbsa.linear_regression();   
    }
}