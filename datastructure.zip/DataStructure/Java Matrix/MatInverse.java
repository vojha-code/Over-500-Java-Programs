import java.util.Random;
public class MatInverse
{
   public int row=3,col=3;
   public float X[][]=new float[row][col];
   public float X_T[][]=new float[row][col]; 
   public float XI[][]=new float[row][col]; 
   public boolean singular = false; 

    void swap( int row1,int row2, int col, float mat[][],float mat1[][])
     {
        for(int i = 0; i < col; i++)
	{
		float   temp = mat[row1][i];
		mat[row1][i] = mat[row2][i];
		mat[row2][i] = temp;

		temp = mat1[row1][i];
		mat1[row1][i] = mat1[row2][i];
		mat1[row2][i] = temp;

	 }
      }


       /* This function find inverse of matrix */

       void mat_Inverse(int row1, int col1, float mat[][],float mat1[][])
       {
         singular = false;
         int i, r, c;
	 for(r = 0;( r < row1)&& !singular;  r++)
	 {

                if((int)mat[r][r]!=0 )  /* Diagonal element is not zero */
                {
			for(c = 0; c < col1; c++)
                        {
			        if( c == r)
				{

					/* Make all the elements above and below the current principal
					 diagonal element zero */

					float ratio =  mat[r][r];
					for( i = 0; i < col1; i++)
					{
						mat[r][i] /= ratio ;
						mat1[r][i] /= ratio;
					}
				}
				else
				{
					float ratio = mat[c][r] / mat[r][r];
					for( i = 0; i < col1;  i++)
					{
						mat[c][i] -= ratio * mat[r][i];
						mat1[c][i] -= ratio * mat1[r][i];
					}
				}
                         } 
                }
		else
		{
			/* If principal diagonal element is zero */
                        singular = true;

			for(c = (r+1); (c < col1) && singular; ++c)
                               if((int)mat[c][r]!=0)
				{
                                        singular = false;
					/* Find non zero elements in the same column */
					swap(r,c,col1, mat, mat1);
					--r;
				}

		}
	}
     
    }

    void tempx(int row,int col)
    {
      for(int i=0;i<row;i++)
      {   
       for(int j=0;j<col;j++)
           XI[i][j]=(float)0.0;
       XI[i][i]=1;
      }
    }

     void mat_X_input(float X[][],int n,int m)
     {
         X[0][0]=0;X[0][1]=7;X[0][2]=13;
         X[1][0]=0;X[1][1]=21;X[1][2]=43;
         X[2][0]=0;X[2][1]=43;X[2][2]=91;
       
         display(X,n,m);
     }    
    
    void display(float d[][],int n,int m)
    {
     for(int i=0;i<n;i++)
     {
       for(int j=0;j<m;j++)
         System.out.print(d[i][j]+" ");
       System.out.println();
     }
    }

    void linear_regression()
    {    
        
          System.out.println("\nThis is The Input Matrix\n"); 
          mat_X_input(X,row,col); 
          System.out.println("\nThis is The Inversed Matrix\n"); 
          tempx(row,col);         
          mat_Inverse(row,col,X,XI);
          display(XI,row,col);
         
          
 
    } 

    public static void main(String[] args) 
    {
           
        MatInverse rbsa=new MatInverse();
        rbsa.linear_regression();   
    }
}
