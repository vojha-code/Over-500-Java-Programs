class MatSub
{

  public static void main(String args[])
  {
    int n=4;
    int m=4;

    int a[][]=new int[n][m];
    int b[][]=new int[n][m];
    int c[][]=new int[n][m];


    for(int i=0;i<n;i++)
     for(int j=0;j<m;j++)
      a[i][j]=i+j+2;

    for(int i=0;i<n;i++)
     for(int j=0;j<m;j++)
      b[i][j]=i+j;


    System.out.print("\nThe entered value in a[2][2] :\n");

    for(int i=0;i<n;i++)
    {
     for(int j=0;j<m;j++)
      System.out.print(a[i][j]+" ");
     System.out.println();
    }

    System.out.print("\nThe entered value in b[2][2] :\n");

    for(int i=0;i<n;i++)
    {
     for(int j=0;j<m;j++)
      System.out.print(b[i][j]+" ");
     System.out.println();
    }

    System.out.print("\nThe Substution result in a[2][2]-b[2][2] :\n");

    for(int i=0;i<n;i++)
    {
     for(int j=0;j<m;j++)
     {
       c[i][j]=a[i][j]-b[i][j];
       System.out.print(c[i][j]+" ");
     }
     System.out.println();
    }

   }
}
    


   
