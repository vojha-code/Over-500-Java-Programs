import java.util.Random;
public class MatMulti
{
   public int row=3,col=3;
   public float X[][]=new float[row][col];
   public float X1[][]=new float[row][col];
   public float Xr[][]=new float[row][col];
   public float X_T[][]=new float[row][col]; 


    double randomVaue()
    {
     Random rand = new Random();
     double prob ;
     return prob =  (100 * rand.nextDouble());
     //return prob =  rand.nextDouble();

    } 


    void mat_Mul(float mat1[][],int row1,int col1,float mat2[][],int row2,int col2,float mat_res[][])
    {
	int i, j, k;
	if(col1 == row2)
	{
		System.out.printf("\n Multiplication is possible and Result is as follows\n");

		for(i =0; i<row1; i++)
			for(j=0; j<col2; j++)
			{
				mat_res[i][j] = 0;
				for(k = 0; k < col1; k ++)
				{
					mat_res[i][j] += mat1[i][k] * mat2[k][j];

				}
			}
	
	}

	else
	  System.out.printf("\n Multiplication is not possible");
	
     }
   

     void mat_X_input()
     {
         X[0][0]=1.49f;X[0][1]=-0.49f;X[0][2]=0.0f;
         X[1][0]=-0.49f;X[1][1]=0.21f;X[1][2]=0.0f;
         X[2][0]=1.99f;X[2][1]=-2.71f;X[2][2]=1.0f;
         
         X1[0][0]=1;X1[0][1]=1;X1[0][2]=1;
         X1[1][0]=1;X1[1][1]=2;X1[1][2]=4;
         X1[2][0]=1;X1[2][1]=3;X1[2][2]=9;
       
     }    
    
    void display(float d[][],int n,int m)
    {
     for(int i=0;i<n;i++)
     {
       for(int j=0;j<m;j++)
         System.out.print(d[i][j]+" ");
       System.out.println();
     }
    }

    void linear_regression()
    {    
        
          System.out.println("\nThis is The Multiplication  Matrix\n"); 
          mat_X_input();         
          mat_Mul(X,row,col,X1,row,col,Xr);
          display(Xr,row,col);
    } 

    public static void main(String[] args) 
    {
           
        MatMulti rbsa=new MatMulti();
        rbsa.linear_regression();   
    }
}