import java.util.Random;
public class RBSA
{
   public int row=3,col=3,coly=1;
   public float Beta[][]=new float[row][coly];
   public float Yin[][]=new float[row][col];
   public float Xin[][]=new float[row][col];
   public float Xtemp[][]=new float[row][col];
   public float Xr[][]=new float[row][col];
   public float Xr1[][]=new float[row][col];
   public float X_T[][]=new float[row][col]; 
   public float XI[][]=new float[row][col]; 
   
    /* This method find random fraction value */
    double randomVaue()
    {
     Random rand = new Random();
     double prob ;
     return prob =  (100 * rand.nextDouble());
    } 

    /* This method find the multiplication of two Matrix */
    void mat_Mul(float mat1[][],int row1,int col1,float mat2[][],int row2,int col2,float mat_res[][])
    {
	int i, j, k;
	if(col1 == row2)
	{

		for(i =0; i<row1; i++)
			for(j=0; j<col2; j++)
			{
				mat_res[i][j] = 0;
				for(k = 0; k < col1; k ++)
				{
					mat_res[i][j] += mat1[i][k] * mat2[k][j];

				}
			}
	
	}
	else
	  System.out.printf("\n Multiplication is not possible");
	
     }


     /* This method find the transpose of a matix */
     void mat_Trans(float transp[][],int row1,int col1)
     {
	for(int i = 0; i< row1; i++)
	{
		for(int j = 0; j < col1; j++)
		{
			X_T[i][j] = transp[j][i] ;
		}
	}
     }

      
     
     /* This method is a part of Inverse function */
     void swap( int row1,int row2, int col, float mat[][],float mat1[][])
     {
        for(int i = 0; i < col; i++)
	{
		float   temp = mat[row1][i];
		mat[row1][i] = mat[row2][i];
		mat[row2][i] = temp;

		temp = mat1[row1][i];
		mat1[row1][i] = mat1[row2][i];
		mat1[row2][i] = temp;

	 }
      }
     /* This method is a part of Inverse function */
     void tempx(int row,int col)
     {
      for(int i=0;i<row;i++)
      {   
       for(int j=0;j<col;j++)
           XI[i][j]=(float)0.0;
       XI[i][i]=1;
      }
     }

     /* This function find inverse of matrix */
     void mat_Inverse(int row1, int col1, float mat[][],float mat1[][])
     {
         boolean singular = false;
         int i, r, c;
	 for(r = 0;( r < row1)&& !singular;  r++)
	 {

                if((int)mat[r][r]!=0 )  /* Diagonal element is not zero */
                {
			for(c = 0; c < col1; c++)
                        {
			        if( c == r)
				{

					/* Make all the elements above and below the current principal
					 diagonal element zero */

					float ratio =  mat[r][r];
					for( i = 0; i < col1; i++)
					{
						mat[r][i] /= ratio ;
						mat1[r][i] /= ratio;
					}
				}
				else
				{
					float ratio = mat[c][r] / mat[r][r];
					for( i = 0; i < col1;  i++)
					{
						mat[c][i] -= ratio * mat[r][i];
						mat1[c][i] -= ratio * mat1[r][i];
					}
				}
                         } 
                }
		else
		{
			/* If principal diagonal element is zero */
                        singular = true;

			for(c = (r+1); (c < col1) && singular; ++c)
                               if((int)mat[c][r]!=0)
				{
                                        singular = false;
					/* Find non zero elements in the same column */
					swap(r,c,col1, mat, mat1);
					--r;
				}

		}
	}
     
    }
    

    /* This is Displaying the mtrix */
    void display(float d[][],int n,int m)
    {
     for(int i=0;i<n;i++)
     {
       for(int j=0;j<m;j++)
         System.out.print(d[i][j]+" ");
       System.out.println();
     }
    }

    /* This is Input method Xin */
    void mat_X_input(float X[][],int n,int m)
    {
         X[0][0]=1.00f;X[0][1]=0.21f;X[0][2]=0.11f;
         X[1][0]=0.12f;X[1][1]=0.92f;X[1][2]=0.30f;
         X[2][0]=0.31f;X[2][1]=0.44f;X[2][2]=0.88f;   
    } 

    /* This is Input method Yin */
    void mat_Y_input(float Y[][],int n,int m)
    {
         Y[0][0]=0.42f;Y[1][0]=0.38f;Y[2][0]=0.20f;
    } 

    void copy_intemp(int n,int m)
    {
      for(int i=0;i<n;i++)
      {
        for(int j=0;j<m;j++)
          Xtemp[i][j]=Xin[i][j];
      }
    }

    void linear_regression()
    {
          
          System.out.println("\nThis is The Input Matrix X\n"); 
          mat_X_input(Xin,row,col); 
          display(Xin,row,col);

          System.out.println("\nThis is The Input Matrix Y\n"); 
          mat_Y_input(Yin,row,coly); 
          display(Yin,row,coly);
          

          /*copy_intemp(row,col);
          System.out.println("\nThis is The Inversed Matrix\n"); 
          tempx(row,col);         
          mat_Inverse(row,col,Xtemp,XI);
          display(XI,row,col);
          
          copy_intemp(row,col);
          System.out.println("\nThis is The Transposed Matrix\n");          
          mat_Trans(Xtemp,row,col);
          display(X_T,row,col);
      
          System.out.println("\nThis is The Multiplication  Matrix\n"); 
          copy_intemp(row,col);      
          mat_Mul(Xtemp,row,col,X_T,row,col,Xr);
          display(Xr,row,col);*/


          System.out.println("\nThe System Output is\n");
          copy_intemp(row,col);
          mat_Trans(Xtemp,row,col);
          copy_intemp(row,col);
          mat_Mul(X_T,row,col,Xtemp,row,col,Xr);
          tempx(row,col);
          mat_Inverse(row,col,Xr,XI);
          mat_Mul(XI,row,col,X_T,row,col,Xr1);
          mat_Mul(Xr1,row,col,Yin,row,coly,Beta);
          display(Beta,row,coly);
          //display(Xr,row,col);
          //Beta[]= mat_Mul(mat_Mul(mat_Inverse(mat_Mul(X_T[][],X[][])),X_T[][]),Y[]);
 
    } 

    public static void main(String[] args) 
    {
           
        RBSA rbsa=new RBSA();
        rbsa.linear_regression();   
    }
}