class MatMul
{

  public static void main(String args[])
  {
    int n=4;
    int m=4;
    int row=0;
    int col=0;

    int a[][]=new int[n][m];
    int b[][]=new int[n][m];
    int c[][]=new int[n][m];


    for(int i=0;i<n;i++)
     for(int j=0;j<m;j++)
      a[i][j]=i+j;

    for(int i=0;i<n;i++)
     for(int j=0;j<m;j++)
      b[i][j]=i+j+1;


    System.out.print("\nThe entered value in a[n][m] :\n");

    for(int i=0;i<n;i++)
    {
     for(int j=0;j<m;j++)
      System.out.print(a[i][j]+" ");
     System.out.println();
    }

    System.out.print("\nThe entered value in b[n][m] :\n");

    for(int i=0;i<n;i++)
    {
     for(int j=0;j<m;j++)
      System.out.print(b[i][j]+" ");
     System.out.println();
    }

    for(int i=0;i<n;i++)
    {
     for(int l=0;l<n;l++)
     {
      int mul=0;
      int rc=0;
      for(int j=0;j<m;j++)
      {
        row=a[i][j];
        col=b[j][l];
        rc=row*col;
        mul=mul+rc;
      }
      c[i][l]=mul;
     }
    }

    System.out.print("\nThe Multiplicative result in a[n][m]*b[n][m] :\n");

    for(int i=0;i<n;i++)
    {
     for(int j=0;j<m;j++)
      System.out.print(c[i][j]+" ");
     System.out.println();
    }

   }
}
    


   
