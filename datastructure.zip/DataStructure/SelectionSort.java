class SelectionSort
{

  void selectionsort(int a[],int n)
  {
    int min,temp;
    int i,j,s=1;

    for(i=0;i<n-1;i++)
    {
      min=i;

      for(j=i+1;j<n;j++)
       if(a[min]>a[j])
          min=j;

        if(min !=i)
         {
          temp=a[i];
          a[i]=a[min];
          a[min]=temp;
         }

      System.out.print("Step "+(s++)+"  : ");

      for(int p=0;p<5;p++)
        System.out.print("  "+a[p]);

      System.out.println();
     }     
       
  
  }

 void display(int a[],int n)
 {
   for(int i=0;i<5;i++)
     System.out.print(" "+a[i]);
 }

  public static void main(String args[])
  {

    int a[]=new int[5];

    a[0]=5;
    a[1]=1;
    a[2]=4;
    a[3]=2;
    a[4]=8;


   SelectionSort s=new SelectionSort();

    System.out.println();
    System.out.print("Array Before Sort -->");
    s.display(a,5);
    System.out.println("\n");

    s.selectionsort(a,5);

    System.out.print("\nArray After Sort -->");
    s.display(a,5);
    System.out.println();

  }

}

