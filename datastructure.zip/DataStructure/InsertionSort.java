class InsertionSort
{

  void insertionsort(int a[],int n)
  {

    int p,temp;
    int i,j;
    a[0]=-0;

    for(i=1;i<n;i++)
    {
      p=i-1;
      temp=a[i];
      while(temp<a[p])
      {
       a[p+1]=a[p];
       p--;
      }
      a[p+1]=temp;

      System.out.print("Step "+i+" :");
       for(int s=1;s<n;s++)
        System.out.print(" "+a[s]);
      System.out.println();

    }

   
  }

 void display(int a[],int n)
 {
   for(int i=1;i<n;i++)
     System.out.print(" "+a[i]);
 }

  public static void main(String args[])
  {

    int a[]=new int[6];

    a[1]=5;
    a[2]=1;
    a[3]=4;
    a[4]=2;
    a[5]=8;


   InsertionSort i=new InsertionSort();

    System.out.println();
    System.out.print("Array Before Sort -->");
    i.display(a,6);
    System.out.println("\n");

    i.insertionsort(a,6);

    System.out.print("\nArray After Sort -->");
    i.display(a,6);
    System.out.println();

  }

}

