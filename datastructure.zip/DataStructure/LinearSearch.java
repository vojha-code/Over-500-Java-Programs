import java.io.*;
class LinearSearch
{

  public static void main(String args[])
  {
   try
   {

    int n=5;
    int array[]=new int[n];
    int key;
    boolean flag=false;
    int i;

    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

    for(i=0;i<n;i++)
    {
      System.out.print("array["+i+"]=");
      array[i]=Integer.parseInt(br.readLine());
    }

     System.out.print("\nEnter The search element to be searched:");
     key=Integer.parseInt(br.readLine());

      for(i=0;i<n;i++)
      {
       if(array[i]==key)
       {
        flag=true;
        System.out.println("The Element "+key+" is found at position array["+i+"]");
        break;
       }
      }

      if(!flag)
       System.out.println("The element is not found");
    }
    catch(Exception e)
    {
      System.out.println(e);
    }

  }
}
