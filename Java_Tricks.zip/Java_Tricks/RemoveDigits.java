import java.io.*;

class RemoveDigits
{

 public static void main(String args[])
 {
  try
  {

   String str = "I read in class 6 and my brither is 4 inch taller ";

   StringReader strr = new StringReader(str);

   int i=-1;

   while((i = strr.read())!=-1)
   {
    char c=(char)i;
    if(Character.isDigit(c)==true)
     continue;
    else
     System.out.print(c);
    }
   System.out.println();

  StringReader strr1 = new StringReader(str);

   while((i = strr1.read())!=-1)
   {
    char c=(char)i;
    if(Character.isLetter(c)==true)
     continue;
    else
     System.out.print((char)i);
    }

  }
  catch(Exception e)
  {
   System.out.println(e);
  }
 }
}



