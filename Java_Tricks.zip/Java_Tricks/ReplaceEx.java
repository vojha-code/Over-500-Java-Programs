class StringEx
{
  public static void amin(String args[])
  {
    String a="Varun";
    System.out.println(a.replace('V','T');
  }
}
