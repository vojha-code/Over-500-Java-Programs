class NoNeedOfMain
{
 //public static void main(String a[])
 static
 {
   for(int i=0;i<10;i++)
     System.out.println("DGFXG");
 }

}
