class A
{
  int a;

  A(int a)
  {
   a=a;
  }
  public String toString()
  {
    return "\n This is Ex No. "+a+" for toString() Ex ";
  }
}
class ToString
{

  public static void main(String args[])
  {
    A ob = new A(1);
  
    System.out.println(ob);
  }
}



