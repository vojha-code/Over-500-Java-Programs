class ComapreTo1
{

  public static void main(String args[])
  {
    String a = "A";
    String b = "B";
    String c = "A";
   

              
    System.out.println("A(65)<B(66) : "+ a.compareTo(b));
    System.out.println("A(65)=A(65) :  "+ a.compareTo(c));
    System.out.println("B(66)<A(65) :  "+ b.compareTo(a));
  }
}

