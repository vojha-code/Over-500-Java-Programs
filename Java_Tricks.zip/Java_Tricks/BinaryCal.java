import java.io.*;

class BinaryCal
{
  public static void main(String args[])
  {
     try
     {


     FileWriter  fwrite= new FileWriter("E:\\cal.txt");
     PrintWriter pr=new PrintWriter(fwrite);

    for(int k=0;k<1024;k++)
     for(int j=0;j<1024;j++)
      for(int i=0;i<1024;i++)
       pr.print("5");

     pr.close();
     }
     catch(Exception e)
     {
      System.out.println(e);
     }
  }
}
     
