import java.io.*;
import java.lang.*;

  public class CharToLowercase{
	  public static void main(String args[]) throws IOException{
		  BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		  System.out.println("Enter the upercase character:");
		  String s = buff.readLine();
		  char c = s.charAt(0);
		  char lower = Character.toLowerCase(c);
		  System.out.println("Lowercase character: " + lower);
	  }
  }