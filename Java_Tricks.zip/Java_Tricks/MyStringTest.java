class MyStringTest
{
 public static void main(String args[])
 {
   int a=10;
   String s1="a";
   String s3="Z";
   String s4=new String("Hello");

   String s2=s1+"def"+10;

   System.out.println((int)'a');
   System.out.println(s1==s4);
   System.out.println(s1.compareTo(s3));

 }
}

