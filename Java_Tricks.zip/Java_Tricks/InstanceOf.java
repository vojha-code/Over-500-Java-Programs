class A
{
}
class B
{
}

class InstanceOf
{
  public static void main(String args[])
  {
    A a = new A();
    B b = new B();


    boolean b1= a instanceof A;
       System.out.println(b1);
  }
}

 
