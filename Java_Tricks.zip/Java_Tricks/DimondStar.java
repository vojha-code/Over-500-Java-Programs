class DimondStar
{

  public static void main(String args[])
  {
    System.out.println();

    int n,m,b,i,a;

    b=11;

    n=(b+1)/2;

    for(i=1;i<=n;i++)
    {
     for(a=1;a<=n-i;a++)
       System.out.print(" ");

     for(a=1;a<=2*i-1;a++)
       if(a%2==1)
        System.out.print("*");
       else
        System.out.print(" ");

     System.out.print("\n");
    }

   m=(b-1)/2;

   for(i=m;i>=1;i--)
   {
     for(a=0;a<=m-i;a++)
       System.out.print(" ");
     for(a=1;a<=2*i-1;a++)
      if(a%2==1)
        System.out.print("*");
      else
        System.out.print(" ");

     System.out.print("\n");
   }
 }
}
       
       
      

    
