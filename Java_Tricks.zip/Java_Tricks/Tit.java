class Tit
{

 public static void main(String args[])
 {

   StringBuffer s = new StringBuffer("ABC");
   StringBuffer s1 = new StringBuffer();
   System.out.println(s.capacity());
   System.out.println(s1.capacity());
 }
}
