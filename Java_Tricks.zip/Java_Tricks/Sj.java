class Sj
{

  public static void main(String args[])
  {
   String s="abcdef";

   char ca[]=new char[10];

   ca=s.toArray();

   //ca=s.toCharArray();

  // s.getChars(1,3,ca,0);
   System.out.println(ca);
  }
}
