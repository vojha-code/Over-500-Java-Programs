class Static
{
 int m(int x)
 {
  x=10;
  return x;
 }
 static
 {
   Static s=new Static();
   int i=s.m(5);
   for(;i<20;i++)
     System.out.println("Print :"+i);
 }

}
