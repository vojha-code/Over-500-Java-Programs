class FinalizeEx
{
  void m()
  {
   System.out.println(" I M M");
  }
  protected void finalize( )
  {
   System.out.println(" I M F ");
  }
  public static void main(String args[])
  {
    FinalizeEx obj = new FinalizeEx();
     obj.finalize( );
    obj.m();
  }

}
