import java.util.*;
class HashTableEx
{

  public static void main(String args[])
  {
      Hashtable ht = new Hashtable();

      ht.put("A",new Integer(1));
      ht.put("E",new Integer(4));

      ht.put("B",new Integer(2));
      ht.put("C",new Integer(3));
      ht.put("D",new Integer(4));



      System.out.println(ht);
  }
}
