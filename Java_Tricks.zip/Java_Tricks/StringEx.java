class StringEx
{
  public static void main(String args[])
  {
    String a="Varun";
    String b="Ojha";
    String c="     Varun".trim();

    System.out.println(c);
    System.out.println(a.replace('V','T'));
    System.out.println(a.concat(" "+b));
    System.out.println(a.indexOf('r'));
    System.out.println(a.toUpperCase());
    System.out.println(a.toLowerCase());
    System.out.println(a.substring(2));
    System.out.println(a.substring(2,3));

     String s;
     int i = 42;
     StringBuffer sb = new StringBuffer(40);
     s = sb.append("i = ").append(i).append("!").toString();
     System.out.println(s);


     StringBuffer sb1 = new StringBuffer("I Java!");
     sb1.insert(2, "like ");
     System.out.println(sb1);

     StringBuffer s1 = new StringBuffer("abcdef");
     System.out.println(s1);
     s1.reverse();
     System.out.println(s1);

     StringBuffer sb2 = new StringBuffer("This is a test.");
     sb2.delete(4, 7);
     System.out.println("After delete: " + sb2);
     sb2.deleteCharAt(0);
     System.out.println("After deleteCharAt: " + sb2);
  }

}
