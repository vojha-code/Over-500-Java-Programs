class MO
{
 void m()
 {
   System.out.println("1");
 }
  
 void m(int a)
 {
   System.out.println("2");
 }

 public static void main(String args[])
 {
  MO obj=new MO();

  obj.m();
  obj.m(1);
 }
}
