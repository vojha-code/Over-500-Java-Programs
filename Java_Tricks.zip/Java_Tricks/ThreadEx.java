class A
{
    void method(String msg)
    {
            System.out.print("< "+msg);
            try
            {
              Thread.sleep(1000);
            }
            catch(InterruptedException e)
            {
                System.out.println(e);
            }
            System.out.println(" >");     
    }
}

class B implements Runnable
{
    Thread t;
    A obj;
    String msg;
    
    B(A b,String ms)
    {
        obj = b;
        msg = ms;
        t = new Thread(this);
        t.start();    
    }
    public  void run()
   {
       obj.method(msg);
   }
}
        
public class ThreadEx
{
  public static void main(String args[])
  {
      A ob = new A();
   
      
        B obj = new B(ob,"ONE");
        B obj1 = new B(ob,"TWO");
        B obj2 = new B(ob,"THREE");
        B obj3 = new B(ob,"FOUR");
      
      try { 
              obj.t.join();
              obj1.t.join();
              obj2.t.join(); 
              obj3.t.join();
          }
         catch(InterruptedException e)
         {
             System.out.println("Interrupted");
          }
      
  } 
}