/* 8.Write a programme that accept integer from command line 
     and prints the factorial of that value.*/  

class Factorial
{
 void fact(int x)

 {
   int i,fact=1;

   for(i=1;i<=x;i++)

    {
      
      fact *=i;
    }
   System.out.println("\n\nFACTORIAL :"+fact);
 }
}
 
class Progm8

{
  static int i=0;

 public static void main(String args[])

 {
    Factorial obj=new Factorial();

    for(int j=0;j<args.length;j++)

     {        
       i=Integer.parseInt(args[j]);
      
     }

   System.out.print("\n  INPUT IS :"+i);

   obj.fact(i);
 }
}