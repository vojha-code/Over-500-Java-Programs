/* 3a.Create a class Batsman with instance variable No of Innings,
      Total-Run,Avg.Write a methode which will takes one integer
      arrguments.Add this integer with Total-Run,Increament,No of-
      -Innings and calulata other variable accrodingly.  */

class Batsman
{
 int no_of_inn;
 int total_run;
 float avg;
 void update(int run)
 {
  no_of_inn++;
  total_run +=run;
  avg=total_run/no_of_inn;
 }
 void show()
 {
  System.out.println("\n No Of Innings :"+no_of_inn);
  System.out.println("\n Total Run     :"+total_run);
  System.out.println("\n Average       :"+avg);
 }
}
class Progm3a
{
 public static void main(String args[])
 {
  int noi,tr;
  float avg;
  Batsman obj=new Batsman();
  obj.update(100);
  obj.update(10);
  obj.update(150);
  obj.show();
 }
}
