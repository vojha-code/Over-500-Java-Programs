/* 3b.Create a class Boller with instance variable No of Innings,
      Total-Run_given,wicket,Avg.Write a methode which will takes one integer
      arrguments.Add this integer with Total-Run_given,and another
      withwicket  Increament,No of Innings and calulata other variable
      accrodingly.  */

class Boller
{
 int inn ,run,wicket;
 float avgr,avgw;
 void update(int w,int r)
 {
  inn++;
  wicket=wicket+w;
  run +=r;
  avgw=w/inn;
  avgr=r/inn;
 }
 void show()
 {
  System.out.println("\n No Of Innings  :"+inn);
  System.out.println("\n Total Wicket   :"+wicket);
  System.out.println("\n Total Run Given:"+run);
  System.out.println("\n Avg of Run     :"+avgr);
  System.out.println("\n Avg of Wicket  :"+avgw);
 }
}
class Progm3b
{
 public static void main(String args[])
 {
  int noi,tr,w;
  float avg;
  Boller obj=new Boller();
  obj.update(5,34);
  obj.update(2,60);
  obj.update(5,50);
  obj.show();
 }
}
