package pkg2;

import pkg1.*;

class C 
{

  public static void main(String args[])

  {  
    B bobj=new B(); 
    bobj.pkg1call();
     
    System.out.println("\n");

    A obj=new A();
     
    D dobj=new D();
    dobj.D(dobj); 
    
    System.out.println("\n");    


    System.out.println("\n5.  DIFFRENT PACKAGE NON SUB-CLASS ::>\n");

    System.out.println("\n Imported  Package Public as non sub-class :"+obj.pu);
     
    System.out.println("\n");

    
    
  }
 
}


