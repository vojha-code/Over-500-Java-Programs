/* 9.Define a class volume and find the volume
     of cube,cylinder,and rectangular box
     using overloading.  */

class Volume
{
 void volume(int length)
 {
  int l=length,v;
   v=l*l*l;
   System.out.println("\nVolume Of Cube :"+v+" cu.cm");
 }
 void volume(int hight,int redius)
 {
  int h=hight,r=redius;
  double v;
   v=3.14*r*r*h;
   System.out.println("Volume Of Cylinder :"+v+" cu.cm");
 }
 void volume(int length,int bredth,int hight)
 {
  int l=length,b=bredth,h=hight,v;
   v=l*b*h;
   System.out.println("Volume Of Rectanguler Box :"+v+" cu.cm");
 }
}
class Progm9
{
 public static void main(String args[])
 {
  Volume obj=new Volume();
  int l=8,b=4,h=6,r=3;
   obj.volume(l);
   obj.volume(h,r);
   obj.volume(l,b,h);
 }
}
