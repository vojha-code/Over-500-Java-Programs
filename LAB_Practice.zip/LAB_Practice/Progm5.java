/* 5.Create a class Box (instance variable:breadth,hight,&width)
     provide methode to calculate volume. */

class Box
{
 int breadth=2;
 int width=3;
 int hight=4;

   void volume()
   {
    int box_vol,x,y,z;
    x=this.breadth;
    y=this.width;
    z=this.hight;

     box_vol=x*y*z;
     System.out.println("VOLUME OF BOX:"+box_vol);
   }
}
class Progm5
{
 public static void main(String args[])
 {
  Box obj=new Box();
  obj.volume();
 }
}
