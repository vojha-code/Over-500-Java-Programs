/* 19.Write a programme called "NoMatchException"that is thrown
      when String is not equal to "INDIA".write a programme that
      uses the Exception. */


class NoMatchException extends Throwable

 {
 }

class Progm19

{

 public static void main(String args[])
 {

  String str="INDA";
  try
  {

   if(str.equals("INDIA"))
    System.out.println("INDIA");

   else
     throw new NoMatchException();
  }
  catch(NoMatchException e)
  {
   System.out.println("The String Is Not INDIA");
  }
 }
}
