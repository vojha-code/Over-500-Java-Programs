class Resource1
{

  synchronized void printer(Resource2 r2)
  {

    String name = Thread.currentThread().getName();
    System.out.println(name+" inside Resource1.printer");

    try
    {
      Thread.sleep(1000);
    }
    catch(InterruptedException e)
    {
     System.out.println("Resource1 Interrupted");
    }

    System.out.println(name+" waiting for Resource2.scannere");
    r2.scanner();
  }

  synchronized void scanner()
  {

   System.out.println(" Insuide the Resource1.scanner");
  }
}

class Resource2
{

  synchronized void printer(Resource1 r1)
  {

    String name = Thread.currentThread().getName();
    System.out.println(name+" inside Resource2.printer");

    try
    {
      Thread.sleep(1000);
    }
    catch(InterruptedException e)
    {
     System.out.println("Resource2 Interrupted");
    }

    System.out.println(name+" waiting for Resource1.scannere");
    r1.scanner();
  }

  synchronized void scanner()
  {

   System.out.println(" Insuide the Resource1.scanner");
  }
}

public class DeadlockExample implements Runnable
{
 
  
   Resource1 r1 = new Resource1();
   Resource2 r2 = new Resource2();

   DeadlockExample()
   {

     System.out.println("\n Pres ctrl+c to get out of the Deadlock \n");

     Thread.currentThread().setName("Main Thread");
     Thread t = new Thread(this,"Child Thread ");
     t.start();
     r1.printer(r2);
     System.out.println(" Back in the main Thread");
   }

   public void run()
   {
     r2.printer(r1);
     System.out.println("Back in main Thread ");
   }

   public static void main(String args[])
   {
    new DeadlockExample();
   }
}

