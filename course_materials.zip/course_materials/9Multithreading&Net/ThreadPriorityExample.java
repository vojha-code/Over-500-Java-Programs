import java.lang.*;

class ChildThread1 extends Thread
{

  public ChildThread1(String threadName)
  {
    super(threadName);
    start();
  }

  public void run()
  {

    for(int i=0;i<3;i++)
       System.out.println(getName());

    System.out.println("Exiting from "+getName());

  }
}

class ChildThread2 extends Thread
{

  public ChildThread2(String threadName)
  {
    super(threadName);
    start();
  }

  public void run()
  {

    for(int i=0;i<3;i++)
       System.out.println(getName());

    System.out.println("Exiting from "+getName());

  }
}

public class ThreadPriorityExample
{

  public static void main(String args[])
  {

    ChildThread1 child1 = new  ChildThread1("Child : 1");
    child1.setPriority(2);

    ChildThread2 child2 = new  ChildThread2("Child : 2");
    child2.setPriority(4);
  }
}

     
