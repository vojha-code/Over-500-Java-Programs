class ThreadGroupIllustration
{
  public static void main(String args[])
  {

    boolean parent = false;
    boolean daemonThread = false;

    ThreadGroup eg1 = new ThreadGroup("group1");
    Thread t1 = new Thread(eg1,"Thread 1");
    Thread t2 = new Thread(eg1,"Thread 2");

    ThreadGroup eg2 = new ThreadGroup("group2");
    Thread t3 = new Thread(eg2,"Thread 3");
    Thread t4 = new Thread(eg2,"Thread 4");

    parent = eg1.parentOf(eg2);

    if(parent)
      System.out.println(eg1.getName()+" is parent of "+eg2.getName());
    else
      System.out.println(eg1.getName()+" is not parent of "+eg2.getName());

    int numThreads = eg1.activeGroupCount();
    System.out.println("The No. of active Threas in"+ eg1.getName()+" is "+numThreads);

    int numThread = eg2.activeGroupCount();
    System.out.println("The No. of active Threas in"+ eg2.getName()+" is "+numThread);

    eg1.list();
    eg2.list();

    daemonThread = eg1.isDaemon();

    if(daemonThread)
     System.out.println(eg1.getName()+" is a daemon thread");
    else
     System.out.println(eg1.getName()+" is not a daemon thread");


    eg2.setDaemon(true);

    daemonThread = eg2.isDaemon();

    if(daemonThread)
     System.out.println(eg2.getName()+" is a daemon thread");
    else
     System.out.println(eg2.getName()+" is not a daemon thread");


    System.out.println("Priority of"+ t1.getName() +"before using setPriority is : "+t1.getPriority());

    t1.setPriority(Thread.MAX_PRIORITY);
    System.out.println("Priority of"+ t1.getName() +"After seting the MAX PRIORITY is : "+t1.getPriority());

    eg1.setMaxPriority(Thread.MAX_PRIORITY);
    System.out.println("Priority of"+ t1.getName() +"After seting the MAX PRIORITY of group to NORM_PRIORITY is : "+t1.getPriority());

    t2.setPriority(Thread.MAX_PRIORITY);
    System.out.println("Priority of"+ t2.getName() +"After seting the MAX PRIORITY is : "+t2.getPriority());

 }
}
