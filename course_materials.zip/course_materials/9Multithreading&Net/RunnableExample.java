class ChildThread implements Runnable
{

  Thread t;

  public ChildThread()
  {
   t = new Thread(this,"I am a child thread");
   System.out.println("Child Thread : "+t);
   t.start();
  }

  public void run()
  {

    try
    {

      for(int i=0;i<3;i++)
      {
       System.out.println(i +" : Child Thread");

       Thread.sleep(1000);
      }
    }
    catch(InterruptedException e)
    {
     System.out.println("Child thread interrupted");
    }
    System.out.println("I am exiting from Child Thread");
  }
}

public class RunnableExample
{

  public static void main(String args[])
  {
    new ChildThread();

    try
    {
      for(int i=0;i<3;i++)
      {
       System.out.println(i +" : Main Thread");

       Thread.sleep(5000);
      }
    }
    catch(InterruptedException e)
    {
     System.out.println("Main thread  interrupted");
    }
    System.out.println("I am exiting from Main Thread");
   }
}
