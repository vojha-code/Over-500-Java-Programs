class TicketQueue
{

  int n;
  boolean produce = false;
  
  synchronized int collectMoney()
  {
    if(!produce)
    {
     try
     {
      wait();
     }
     catch(InterruptedException e)
     {
      System.out.println("Interrupted1");
     }
    }

    System.out.println("Get Money "+ n);
    produce = false;
    notify();
    return n;
  }

  synchronized void soldTicket(int n)
  {
    if(produce)
    {
     try
     {
      wait();
     }
     catch(InterruptedException e)
     {
      System.out.println("Interrupted1");
     }
    }

    this.n = n;
    produce =true;
    System.out.println("Take Ticket "+n);
    notify();
    return;
  }
}

class TicketCounter implements Runnable
{

  TicketQueue q;

  TicketCounter(TicketQueue q)
  {

    this.q = q;
    new Thread(this,"TicketCounter").start();
  }

  public void run()
  {

    int i=0;
    while(true)
    {
     q.soldTicket(i++);
    }
  }
}

class TicketBuyer implements Runnable
{

  TicketQueue  q;

  TicketBuyer(TicketQueue q)
  {

   this.q = q;
   new Thread(this,"Ticket Buyer").start();
  }

  public void run()
  {
    while(true)
    {
     q.collectMoney();
    }
  }
}

public class TicketCounterQueue
{

  public static void main(String args[])
  {
    TicketQueue q = new TicketQueue();
    new TicketCounter(q);
    new TicketBuyer(q);
   
    System.out.println("Press ctrl+c to break");

  }
   
}
