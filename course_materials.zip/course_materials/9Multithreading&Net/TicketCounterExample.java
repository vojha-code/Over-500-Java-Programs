class TicketQueue
{

  int n;

  synchronized int collectMoney()
  {

    System.out.println("Get Money "+ n);
    return n;
  }

  synchronized void soldTicket(int n)
  {

   this.n = n;
   System.out.println("Take Ticket "+n);
  }
}

class TicketCounter implements Runnable
{

  TicketQueue q;

  TicketCounter(TicketQueue q)
  {

    this.q = q;
    new Thread(this,"TicketCounter").start();
  }

  public void run()
  {

    int i=0;
    while(true)
    {
     q.soldTicket(i++);
    }
  }
}

class TicketBuyer implements Runnable
{

  TicketQueue  q;

  TicketBuyer(TicketQueue q)
  {

   this.q = q;
   new Thread(this,"Ticket Buyer").start();
  }

  public void run()
  {
    while(true)
    {
     q.collectMoney();
    }
  }
}

public class TicketCounterExample
{

  public static void main(String args[])
  {
    TicketQueue q = new TicketQueue();
    new TicketCounter(q);
    new TicketBuyer(q);
   
    System.out.println("Press ctrl+c to break");

  }
   
}
