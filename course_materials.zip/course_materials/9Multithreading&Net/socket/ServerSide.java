import java.io.*;
import java.net.*;

 class ServerSide{
	public static void main(String [] args){
	try{
		ServerSocket ss=new ServerSocket(8080);
		System.out.println("Server listning at"+ 		InetAddress.getLocalHost()+"on port"+ss.getLocalPort());
		while(true){
			Socket s=ss.accept(); //wait for new client to call
			DataInputStream dis=new DataInputStream(s.getInputStream());
			String message=dis.readUTF();
			System.out.println(message);
			
			
			}

	}catch(Exception e)	{
	System.out.println(e);
}
}

}