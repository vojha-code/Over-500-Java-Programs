import java.io.*;
import java.net.*;

public class ClientSide{
	public static void main(String [] args){
		if(args.length<3){
			System.out.println("Usage: Java ClientSide Host port message");
			System.exit(0);
		}
String  serverName=args[0];//either ascii or numeric form
		int serverPort=Integer.parseInt(args[1]);
		String message="";
		for(int i=2;i<args.length;i++)
                                   {
                                      message=message+" "+args[i];
                                  }
                                 try{
			Socket s=new Socket(serverName,serverPort);//wait for server to accept
			DataOutputStream dos=new DataOutputStream(s.getOutputStream());
			dos.writeUTF(message);
			dos.close();
			
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
