import java.lang.*;

class ChildThread extends Thread
{

  public ChildThread(String threadName)
  {
    super(threadName);
    start();
  }
  public void run()
  {

    try
    {
     for(int i=0;i<3;i++)
     {
      System.out.println(i+" : "+getName()+" in  exection!");

      Thread.sleep(500);
     }
    }
    catch(InterruptedException e)
    {
      System.out.println(getName()+ " Interrupted");
    }

    System.out.println("Exiting from "+getName());
  }
}

public class ThreadExample
{

  public static void main(String args[])
  {

   ChildThread child = new ChildThread("Child");

   System.out.println("main in execution!");
   System.out.println("Exiting from main!");
  }
}



