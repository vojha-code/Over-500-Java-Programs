
 
import java.net.*;

public class ParseURL {


    public static void main(String[] args) {

        URL url;
        String protocol;
        String host;
        int port;
        String file;
        String ref;

        try {

            // Create a URL object
            url = new URL("http://www.yahoo.com:80/index.shtml#main");

            // Get all components of the URL object
            protocol = url.getProtocol();
            host     = url.getHost();
            port     = url.getPort();
            file     = url.getFile();
            ref      = url.getRef();

            // Print out results
            System.out.println("Original URL Object : " + url);
            System.out.println("Protocol            : " + protocol);
            System.out.println("Host                : " + host);
            System.out.println("Port                : " + port);
            System.out.println("File                : " + file);
            System.out.println("Ref                 : " + ref);

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

    }

}
