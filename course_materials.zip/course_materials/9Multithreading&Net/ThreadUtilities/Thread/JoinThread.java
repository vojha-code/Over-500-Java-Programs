class NewThread implements Runnable
{
 String name;
 Thread t;
 NewThread(String threadname)
 {
  name=threadname;
  t=new Thread(this,name);
   System.out.println("New thread :"+t);
    t.start();
 }
 public void run()
 {
  try
  {
   for(int i=3;i>0;i--)
   {
    System.out.println(name+" :"+i);
     Thread.sleep(500);
   }
  }
  catch(InterruptedException e)
  {
   System.out.println(name+" Interrupted");
  }
  System.out.println("Exiting Thraed"+name);
 }
}
class JoinThread
{
 public static void main(String args[])
 {
  NewThread ob1=new NewThread("one  ");

  NewThread ob2=new NewThread("two  ");

  NewThread ob3=new NewThread("three");

   System.out.println("Thread one Is alive   :"+ob1.t.isAlive());

   System.out.println("Thread two Is alive   :"+ob2.t.isAlive());

   System.out.println("Thread three Is alive :"+ob3.t.isAlive());

    try
    {
     System.out.println("waiting for Thread To Finish");
      ob1.t.join();
      ob2.t.join();
      ob2.t.join();
    }
    catch(InterruptedException e)
    {
     System.out.println("Main thread Interrupted ");
    }

   System.out.println("Thread one Is alive   :"+ob1.t.isAlive());

   System.out.println("Thread two Is alive   :"+ob2.t.isAlive());

   System.out.println("Thread three Is alive :"+ob3.t.isAlive());

  }
}
