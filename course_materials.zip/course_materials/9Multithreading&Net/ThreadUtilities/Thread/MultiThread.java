
class NewThread implements Runnable
{
 String name;
 Thread t;

 NewThread(String threadname)
 {
  name=threadname;

   t=new Thread(this,name);

   System.out.println("New Thread :"+t);

   t.start();
 }

  public void run()
  {

   try
   {
  
    for(int i=5;i>0;i--)
    {
     System.out.println("\n"+name+" :"+i);
  
     Thread.sleep(1000);
    }

   }
     catch(InterruptedException e)
     {
       System.out.println(name+" Intrrupted ");
     }

  System.out.println(name+"  Exiting.");

  }
}

class MultiThread

{

 public static void main(String args[])
 {

   new NewThread("one   ");
                        
   new NewThread("two   ");
                         
   new NewThread("threee");


  try
  {

   Thread.sleep(10000);
  }
  catch(InterruptedException e)
  {

  System.out.println("  Intrrupt   ");

  }

  System.out.println("Main Thread  Exiting.");
 }

}

