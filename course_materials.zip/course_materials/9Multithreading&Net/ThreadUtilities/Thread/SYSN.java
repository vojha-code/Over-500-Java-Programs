class Day
{
 synchronized void day(String day)
 {
  System.out.println("Today Is"+day+". It is Morming");
  try
   {
    Thread.sleep(1000);
   }
   catch(InterruptedException e)
   {
      System.out.println("ERROR");
   }
  System.out.println("End of This day "+day);
 }
}
 class Call implements Runnable
 {
   String day;
   Day d;
   Thread t;

   Call(Day obj,String msg)
   {
    d=obj;
    day=msg;
    t=new Thread(this);
    t.start();
   }
   public void run()
   {
    d.day(day);
   }
 }
public class SYSN
{
 public static void main(String args[])
 {
  Day obj=new Day();

  Call c1=new Call(obj,"Sunday");
  Call c2=new Call(obj,"Monday");
  Call c3=new Call(obj,"Tuesday");

  try
  {
   c1.t.join();
   c2.t.join();
   c3.t.join();
  }
  catch(InterruptedException e)
  {
   System.out.println("ERROR");
  }
 }
}







  
