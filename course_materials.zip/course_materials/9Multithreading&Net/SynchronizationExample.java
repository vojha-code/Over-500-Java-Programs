class Printer
{

  void printMessage(String msg)
  {
    System.out.print("Begin Connection "+ msg+"\n");

    try
    {
     Thread.sleep(1000);
    }
    catch(InterruptedException e)
    {
     System.out.println("Interrupted");
    }
    System.out.println("End Connection");
  }
}

class Client implements Runnable
{

  String msg;
  Printer pr;
  Thread t;

  public Client(Printer pr1,String msg)
  {

    pr=pr1;
    this.msg=msg;
    t=new Thread(this);
    t.start();
  }

  public void run()
  {
   pr.printMessage(msg);
  }
}

public class SynchronizationExample
{

 public static void main( String args[])
 {
  Printer pr = new Printer();

  System.out.println("User trying to connect the printer");

  Client c1 = new Client(pr,"I am user  ID : 101");
  Client c2 = new Client(pr,"I am user  ID : 102");
  Client c3 = new Client(pr,"I am user  ID : 103");
  Client c4 = new Client(pr,"I am user  ID : 104");

  try
  {
   
   c1.t.join();
   c2.t.join();
   c3.t.join();
   c4.t.join();
  }
  catch(InterruptedException e)
  {
   System.out.println("Interrupted");
  }
 }
}
