class Throw
{
 static void meth()
 {
  try
  {
   throw new NullPointerException("THROW");
  }
  catch(NullPointerException e)
  {
   System.out.println("Cought ");
   throw e;
  }
 }
 public static void main(String args[])
 {
   try
   {
    meth();
   }
   catch(NullPointerException e)
   {
    System.out.println("ReCought ");
   }
  }
}
