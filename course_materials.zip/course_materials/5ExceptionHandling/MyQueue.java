import java.io.*;

class TypeMismatchException extends Exception
{
 TypeMismatchException()
 {
  System.out.println(" Enter only objects of MyObject");
 }
}

class MyQueueFullException extends Exception
{
 MyQueueFullException()
 {
  System.out.println("Opps ! The Queue is Full");
 }
}

class MyQueueEmptyException extends Exception
{
 MyQueueEmptyException()
 {
  System.out.println("Opps ! The Queue is Empty");
 }
}

class MyObject
{
 public String toString()
 {
  return "MyObject has been removed";
 }
}

class MyQueue
{

 int front,rear,MAX=5;

 Object object[] = new Object[MAX];

 MyQueue()
 {
  rear=0;
  front=0;
 }

// ADD TO Q

 public void addToQueue(Object o)throws MyQueueFullException,TypeMismatchException
 {

  Class classname = o.getClass();

   if(classname.toString().equals("class MyObject"))
    {
     if(rear<MAX)
      {
        object[rear] = o;
        rear+=1;
      }
     else
      {
       throw new MyQueueFullException();
      }
    }
   else
    {
     throw new TypeMismatchException();
    }
  }

// REMOVE FROM Q

 public void removeFromQueue(Object o)throws MyQueueEmptyException,TypeMismatchException
 {

   Class classname = o.getClass();
   front=rear-1;

   if(classname.toString().equals("class MyObject"))
    {
     if(front>=0)
      {
        System.out.println(object[front].toString());
        rear--;
      }
     else
      {
       throw new MyQueueEmptyException();
      }
    }
   else
    {
     throw new TypeMismatchException();
    }
  }

// MAIN

  public static void main(String args[])
  {

   int count,read;

   MyQueue ms =  new MyQueue();

   MyObject ol = new MyObject();

    try
     {
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

       do
        {
          System.out.print("\nEnter Your Option (MAX size of Queue is 5) ");
          System.out.print("\nEnter 1.->To Add into Q , 2.->To Remove from Q , 3.->To Exit :");

          read= Integer.parseInt(br.readLine());

            switch(read)
             {
              case 1:

                ms.addToQueue(ol);
                break;

              case 2:

                ms.removeFromQueue(ol);
                break;

             case 3:

                 System.exit(1);
             }

          System.out.print("\nEnter 1->continue , 0 -> Discontinue :");

          count=Integer.parseInt(br.readLine());

         }
         while(count==1);
      }
      catch(Exception e)
      {
       System.out.println(e);
      }
   }
}



