class SimpleExceptionImp
{
 public static void main(String args[])
 {
  System.out.println("\n\n Exxception has not been cought here:");
  System.out.println("\n O/P---------------->");
  
  try
  {
   System.out.println("\n we are going to catch exception in try block");

   int a=5/3; //if exception is not cought here then next part
              //are executed else they are not executed

   System.out.println(" we are in try block ");

   //System.exit(0);// if this statement is present in try then
                    // next part of whole programme is not excecuted

   //return; // even there is return statement finally is executed
             // * but return statement once executed in try-catch block
             // then the next part of programme are " UREACHABLE "
  }
  catch(Exception e)
  {
   System.out.println(" we are in catch block");

   //System.exit(0);// if this statement is present in try then
                    // next part of whole programme is not excecuted

   return; // even there is return statement finally is executed
             // * but return statement once executed in try-catch block
             // then the next part of programme are " UREACHABLE "
  }
  finally
  {
   System.out.println(" we are in finally block");
  }

  System.out.println("\n\n Exxception has been cought here:");
  System.out.println("\n O/P---------------->");
  
  try
  {
   System.out.println("\n we are going to catch exception in try block");
   
   int a=5/0; //if exception is not cought here then next part
              //are executed else they are not executed

   System.out.println(" we are in try block ");

   //System.exit(0);// if this statement is present in try then
                    // next part of whole programme is not excecuted

   return; //-->even there is return statement finally is executed
  }
  catch(Exception e)
  {
   System.out.println(" we are in catch block");

   //System.exit(0);// if this statement is present in try then
                    // next part of whole programme is not excecuted

   return;//it can not effect the execution of finally block
  }
  finally
  {
   System.out.println(" we are in finally block");
  }

 }
}

