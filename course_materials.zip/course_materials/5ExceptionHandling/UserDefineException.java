
//---> 1st User define exception

class ColdException extends Exception
{
 ColdException()
 {
  System.out.println(" The Room is very Cold ");
 }
}

//---> 2nd User define exception

class HotException extends Exception
{
 HotException()
 {
  System.out.println(" The Room is very Hot ");
 }
}

//---> main programme start here

class UserDefineException
{

 //---> USE OF " throws "  FOR THROWING EXCEPTION

 public static void main(String args[]) throws ColdException,HotException
 {
 
   int range;

   System.out.println(" Request Manager for meeting ");
   System.out.println(" Obtaining the temprature range");

   try
   {
      range=10;

      System.out.println("\n Now the temprature is :"+range);

      ScheduleMeeting(range);
   }
   catch(ColdException e)
    {
     System.out.println("\n Sorry the meeting can not be schedule ");
     System.out.println("  becouse "+e);
    }
   catch(HotException e)
    {
     System.out.println("\n Sorry the meeting can not be schedule ");
     System.out.println("  becouse "+e);
    }

   try
   {
      range=20;

      System.out.println("\n Now the temprature is :"+range);

      ScheduleMeeting(range);
   }
   catch(ColdException e)
    {
     System.out.println("\n Sorry the meeting can not be schedule ");
     System.out.println("  becouse "+e);
    }
   catch(HotException e)
    {
     System.out.println("\n Sorry the meeting can not be schedule ");
     System.out.println("  becouse "+e);
    }

   try
   {
      range=35;

      System.out.println("\n Now the temprature is :"+range);

      ScheduleMeeting(range);
   }
   catch(ColdException e)
    {
     System.out.println("\n Sorry the meeting can not be schedule ");
     System.out.println("  becouse "+e);
    }
   catch(HotException e)
    {
     System.out.println("\n Sorry the meeting can not be schedule ");
     System.out.println("  becouse "+e);
    }

 }

  public static void ScheduleMeeting(int r) throws ColdException,HotException
  {
   if(r<15)
    throw new ColdException(); //-->THROWING exception by " throw "
   else if(r>25)
    throw new HotException();  //-->THROWING exception by " throw "
   else
    System.out.println("\n The Room temprature is favourable for the Meeting");
  }

}   

