class IntegerExceptionDemo
{
 public static void main(String args[])
 {
  System.out.println("\n---> Calling Integer Division  : 15 by 3");
  integerDivision(15,3);

  System.out.println("\n---> Calling Integer Division  : 15 by 0");
  integerDivision(15,0);
 }
 public static void integerDivision(int x,int y)
 {
   try
    {
     int z=x/y;
     System.out.println("\n Quotient :"+z);
    }
   catch(Exception e)
    {
     System.out.println("\n "+e);
     return;
    }
    finally
    {
     System.out.println("\n Exception Method End <---");
    }
 }
}


