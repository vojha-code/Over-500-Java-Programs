class MyBaseException extends Exception
{
 public MyBaseException()
 {
  super();
 }
 public MyBaseException(String s)
 {
  super(s);
 }
}

class MySubException extends MyBaseException
{
 public MySubException()
 {
  super();
 }
 public MySubException(String s)
 {
  super(s);
 }
}

class ExceptionDemo
{
 public static void method1(int i)
 {
  try
  {
   method2(i);
  }
  catch(MyBaseException e)
  {
   System.out.print("MyBaseException"+":");
   System.out.println(e.getMessage());
   System.out.println("Handelled in method1");
  }
 }
 public static void method2(int i)throws MySubException,MyBaseException
 {
  int result;
  try
  {
   System.out.println(" i= "+i+"\n");
   result=method3(i);
   System.out.println(" method3(i) = "+result);
  }
  catch(MySubException e)
  {
   System.out.println(e+" :");
   System.out.println("Handled in method2");
  }
  finally
  {
   System.out.println("\n");
  }
 }

//-Method  3>>

 public static int method3(int i)throws MySubException,MyBaseException
 {
  if(i==0)
   throw new MyBaseException("The value assigned is too less");
  else if(i==99)
   throw new MySubException("The value assigned is too high");
  else
   return i+i;
 }

// Home >>

 public static void main(String args[])
 {
  System.out.println("\n\n Experiment No 1");
  try
   {
    method1(0);
   }
   catch(Exception e)
   {}

  System.out.println("\n\n Experiment No 2");
  try
   {
    method1(99);
   }
   catch(Exception e)
   {}

  System.out.println("\n\n Experiment No 3");
  try
   {
    method1(20);
   }
   catch(Exception e)
   {}


 }
}



 
