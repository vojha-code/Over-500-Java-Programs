class EmptyListException extends Exception
{
 EmptyListException(String message)
 {
  super(message);
 }
}

class InvalidIndexException extends Exception
{
 InvalidIndexException(String message)
 {
  super(message);
 }
}


class ListManager
{
 public String getStringAt(java.util.Vector list,int position)
 throws EmptyListException,InvalidIndexException
 {
   if(list==null)
    {
     throw new NullPointerException(" No List is Available to process.");
    }
   if(list.size()==0)
    {
     throw new EmptyListException("List is Empty");
    }
   if(position<0 || position> (list.size() - 1))
    {
     throw new InvalidIndexException("Invalid Index ["+position+"] to the list");
    }

  Object o=list.elementAt(position);

  String  className=o.getClass().toString().substring(o.getClass().toString().lastIndexOf(".")+1);

    if (  className.equalsIgnoreCase("string"))
      return (String) o;
    else
      return null;
 }
}


public class ListTest
{
  public static void main(String args[])
  {
   java.util.Vector list = createList();

   ListManager manager= new ListManager();

   int position=0;
   position=Integer.parseInt(args[0]);

    try
     {
      String s=manager.getStringAt(list,position);
      System.out.println(s);
     }
     catch(NullPointerException npe)
     {
      System.out.println("Error occured......");
      npe.printStackTrace();
     }
     catch(EmptyListException  le)
     {
      System.out.println("EmptyListError occured.....");
      le.printStackTrace();
     }
     catch(InvalidIndexException iie)
     {
      try
       {
        String s= manager.getStringAt(list,0);
        System.out.println(s);
       }
       catch(Exception e)
       {
        e.printStackTrace();
       }
     }
     catch(Exception e)
     {
      System.out.println("Some other error.....");
      e.printStackTrace();
     }
   }

  private static java.util.Vector createList()
  {
   java.util.Vector list=new java.util.Vector();

    for(int i=0;i<5;i++)
     list.addElement(new Integer(i));

    for(int i=5;i<10;i++)
     list.addElement("String"+1);

   return list;
  }
}
