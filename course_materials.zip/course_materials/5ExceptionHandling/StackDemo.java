import java.util.*;
import java.io.*;

class EmptyStackException extends Exception
{
 EmptyStackException()
 {
  System.out.println(" Stack is empty ");
 }
}

class StackDemo extends Stack
{
 public static void top(StackDemo st)throws EmptyStackException
 {
  if(st.empty()==true)
  {
   throw new EmptyStackException();
   //exception when there is no element on the top of stack
  }
  else
  {
   Integer a=(Integer) st.pop();
   System.out.print(a);
  }
 }

 public static void main(String args[])
 {
  int total,number;
  StackDemo stack = new StackDemo();

  try
  {
    BufferedReader br = new BufferedReader( new InputStreamReader(System.in));

    System.out.print("\n Enter the no of element you want to push:");

    total = Integer.parseInt(br.readLine());

    System.out.println("\n");

      if(total !=0)
       {
        System.out.println(" Enter the element:");

        while(total>0)
        {
         number = Integer.parseInt(br.readLine());
         stack.push(new Integer(number));
         total--;
        }
       }
    System.out.print("\n The element is on the top of Stack is: ");
    stack.top(stack);
   }
   catch(EmptyStackException se)
   {
    System.out.println(se);
   }
   catch(IOException e)
   {
     e.printStackTrace();
   }
  catch(NumberFormatException e)
  {
   System.out.println("Invalid value entered ");
   System.exit(0);
  }
 }
}
  
 
