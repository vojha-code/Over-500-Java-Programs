class StaticMeth
{
 static int a;
 static void add(int x,int y)
 {
  a=x+y;
  System.out.println("Static Add :"+a);
 }
 public static void main(String args[])
 {
  add(3,4);
 }
}
