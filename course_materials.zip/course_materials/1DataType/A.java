//Class file not created
//identifire expected
//ilegle start of type
class A
{
 int a=5;
   System.out.println(a);
 public static void main(String args[])
  {
    A obj=new A();
   System.out.println("a");
  }
}
