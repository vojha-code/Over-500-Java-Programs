class DoubleValueTest
{
 public static void main(String args[])
 {
  int a=9;
  int b=7;
  System.out.println();
  System.out.println("a = 9");
  System.out.println("b = 7\n");
  System.out.println("Diffrent results\n");
  
  double result=0.0;

  result=a/b;
  System.out.println("Dividing a/b         : "+result);

  result=a/(double)b;
  System.out.println("Dividing a/(double)b : "+result);

  result=b/a;
  System.out.println("Dividing b/a         : "+result);

  result=b/(double)a;
  System.out.println("Dividing b/(double)a : "+result);

 }
}

