class BooleanType
{
 public static void main(String args[])
 {

  Boolean bool;

  //bool=0;  //wrong initialization of boolean type

  bool=true; // the write way

  System.out.println(" Simple Boolean is "+bool);

  String str1="Varun";
  String str2="varun";

  bool=str1.equals(str2);

  System.out.println(" Compare Boolean is "+bool);

  System.out.println(" Compare Boolean is "+str1.hashCode());

  
  }
}

