class ShortType
{
 public static void main(String args[])
 {

  Short short1;//Caps
  short s;//Small

  short1=12;
  s=9;

  System.out.println(" Simple Short is "+short1+ " & "+s);

 }
}

