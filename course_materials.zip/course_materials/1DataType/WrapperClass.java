public class WrapperClass
{
 public static void main(String args[])
 {
  Integer i=new Integer(5);
  String s="34.9";

  System.out.println(" Value of i is 5& "+i.toString());
  System.out.println(" Value of s is "+Float.parseFloat(s));

  Float f=Float.valueOf(s);

  System.out.println(" Value of s is "+f);

  float primitiveFloat=f.floatValue();
  int primitiveInt=f.intValue();
  byte b=f.byteValue();


  System.out.println(" primitive Float value  is "+primitiveFloat);

  System.out.println(" primitive Int value  is "+primitiveInt);

  System.out.println(" primitive Byte value  is "+b);

  }
}
