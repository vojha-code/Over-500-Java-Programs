class ToString
{
 public static void main(String args[])
 {

  Integer i=new Integer(11);
  Float f=new Float(83.2);

  System.out.println("\nVarun's Roll no is"+i.toString());
  System.out.println("\nVarun's Marks   is"+f.toString());

 }

}
