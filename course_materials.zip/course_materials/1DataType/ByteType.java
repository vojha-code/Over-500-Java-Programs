class ByteType
{
 public static void main(String args[])
 {
  //byte byte1;//small
  Byte byte1;//caps

  byte1=12;

  System.out.println(" Simple Byte is "+byte1);

 }
}

