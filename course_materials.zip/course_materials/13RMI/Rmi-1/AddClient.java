//Add Client.java

import java.rmi.*;

public class AddClient
{

  public static void main(String argc[])
  {
    String addServerURL;
    AddServerInterface addServerInterface;
    double d1,d2;

    try
    {
      addServerURL = "rmi://"+argc[0]+"/AddServer";

      addServerInterface = (AddServerInterface)Naming.lookup(addServerURL);

      System.out.println("The first number is:"+argc[1]);

      d1=Double.valueOf(argc[1]).doubleValue();

      System.out.println("The Second number is:"+argc[2]);

      d2=Double.valueOf(argc[2]).doubleValue();

      System.out.println("The Summ is :"+addServerInterface.add(d1,d2));
    }
    catch(Exception e)
    {
      System.out.println(e);
    }

  }
}
