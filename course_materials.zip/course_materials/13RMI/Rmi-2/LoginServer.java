import java.rmi.*;
import java.net.*;

public class LoginServer
{

 public static void main(String args[])
 {
   try
   {

      ValidiatorImpl aValidiator = new ValidiatorImpl();

      Naming.rebind("validiator",aValidiator);

      System.out.println("Login Server is open for bussiness");
   }
   catch(RemoteException e)
   {

     e.printStackTrace();
   }
   catch(MalformedURLException me)
   {
    System.out.println("MalformedURLExceptio "+me);
   }
 }
}

 
