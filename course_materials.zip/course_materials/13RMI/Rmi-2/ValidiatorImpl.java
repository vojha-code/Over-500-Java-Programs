import java.rmi.*;
import java.util.*;
import java.rmi.server.UnicastRemoteObject;

public class ValidiatorImpl extends  UnicastRemoteObject
implements Validiator
{

   Map memberMap;

   ValidiatorImpl()throws RemoteException
   {

      memberMap = new HashMap();

      memberMap.put("Varun","Ojha");
   }

   public String validiate(String aUserName,String aPassword)throws RemoteException
   {

     if(getMemberMap().containsKey(aUserName)&&getMemberMap().get(aUserName).equals(aPassword))
       return "Welcome "+aUserName;
     return "Sorry invalid login information";
   }
   public Map getMemberMap()
   {
      return memberMap;
   }
}
