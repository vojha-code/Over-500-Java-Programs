import java.rmi.*;
import java.net.*;

public class ValidiatorClient
{

  public static void main(String args[])
  {

    if(args.length==0||!args[0].startsWith("rmi"))
    {
      System.out.println("Usage:java ValidatorClient "+
      " rmi://host.domin.port/validiator username password");
    }

    try
    {
       Object remote = Naming.lookup(args[0]);

       Validiator reply = (Validiator)remote;
       System.out.println(reply.validiate(args[1],args[2]));

    }
    catch(MalformedURLException me)
    {
     System.out.println(" MalformedURLException "+me);
    }
    catch(RemoteException e)
    {
      System.out.println("could not find remote url server ");
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
}

     
