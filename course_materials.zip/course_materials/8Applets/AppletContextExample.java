import java.awt.*;
import java.applet.*;
import java.net.*;

public class AppletContextExample extends Applet
{

  public void start()
  {
  }

  public void paint(Graphics g)
  {
    AppletContext ac = getAppletContext();
    URL url = getCodeBase();

    try
    {
      ac.showDocument(new URL(url+"AppletContext.html"));
    }
    catch(MalformedURLException e)
    {
     showStatus("URL notfound");
    }
  }

}
