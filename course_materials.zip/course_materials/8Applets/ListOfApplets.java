import java.applet.Applet;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class ListOfApplets extends Applet
implements ActionListener
{
  Button go;
  Label promptLabel;
  Label result;
  TextArea taobj;
  TextField tfobj;

  public void init()
  {

    try
    {
      result      = new Label(" View Reasult : ");
      promptLabel = new Label();
      promptLabel.setName("PromptLabel");
      promptLabel.setText("Enter the Class Name as shown in text area");

      go = new Button("GO");

      taobj = new TextArea(5,30);
      taobj.setName("taobj");

      tfobj = new TextField(20);
      tfobj.setName("tfobj");

      setName("ListOfApplets");
      setLayout(new FlowLayout());

      add(promptLabel);
      add(tfobj);
      add(taobj);
      add(go);
      add(result);

      Enumeration em = getAppletContext().getApplets();

      while(em.hasMoreElements())
      {

        Applet appletTemp = (Applet)em.nextElement();

        taobj.setText( taobj.getText() + appletTemp.getClass().toString() +"\n");
      }

      go.addActionListener(this);
    }
    catch(Exception e)
    {
     e.printStackTrace();
    }
   }

   public void actionPerformed(ActionEvent e)
   {

     if((e.getSource() == go))
     {
       result.setText("");
       this.findClassExists(tfobj.getText());
     }
   }

   public void findClassExists(String className)
   {

     boolean flag = false;

     Enumeration em = getAppletContext().getApplets();

     while(em.hasMoreElements())
     {

      Applet appletTemp = (Applet)em.nextElement();

      if(className.equals(appletTemp.getClass().toString().substring(appletTemp.getClass().toString().indexOf("")).trim()))
      {
        result.setText("The Class Exits");
      }
     }
     return;
   }
}




     
