import java.applet.Applet;
import java.awt.Graphics;

public class MyFirst extends Applet
{
  StringBuffer bufobj;

  public void init()
  {
    bufobj=new StringBuffer();
    displayMassage("INIT");
  }

  public void start()
  {
   displayMassage("START");
  }

  public void stop()
  {
   displayMassage("STOP");
  }

  public void destroy()
  {
   displayMassage("DESTROY");
  }

  void displayMassage(String msg)
  {
   System.out.println(msg);
   bufobj.append(msg+" || ");
   repaint();
  }

  public void paint(Graphics graph)
  {
   graph.drawString(bufobj.toString(),5,200);
  }
}



