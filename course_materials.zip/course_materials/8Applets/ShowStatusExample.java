import java.awt.*;
import java.applet.*;

public class ShowStatusExample extends Applet
{

  Image image;

  public void start()
  {
   image = getImage(getCodeBase(),"IOC.gif");
  }

  public void paint(Graphics g)
  {
   showStatus("Sucess in loding Image....");
   g.drawImage(image,0,0,this);
  }  
}



