import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class AppletMouseEventExample extends Applet
implements MouseListener
{

  String msg = "";
  int count = 20;

  public void init()
  {
    addMouseListener(this);
  }

  public void mouseClicked(MouseEvent me)
  {

    msg = "Welcome to varun's World";

    count = count + 20;

    if(count > 300)
      count = 20;

    repaint();

  }
  public void mouseEntered(MouseEvent me){}
  public void mouseExited(MouseEvent me){}
  public void mousePressed(MouseEvent me){}
  public void mouseReleased(MouseEvent me){}
                           
  public void paint(Graphics g)
  {
    g.drawString(msg,30,count);
  }
}

