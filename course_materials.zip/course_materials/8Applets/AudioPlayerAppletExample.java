import java.applet.Applet;
import java.applet.AudioClip;
import java.applet.AppletContext;
import java.net.*;

public class AudioPlayerAppletExample extends java.applet.Applet
{
 AudioClip audioClip = null;

  public AudioPlayerAppletExample()
  {
   super();
  }

  public void destroy(){}


  public void init()
  {
   String audioClipName = getParameter("audioClipName");

   try
   {
    audioClip = getAudioClip(new URL(getDocumentBase(),audioClipName));
   }
   catch(MalformedURLException e)
   {
    e.printStackTrace();
   }
  }

  public void paint(java.awt.Graphics g)
  {
   audioClip.play();
   audioClip.loop();
  }

  public void start(){}

  public void stop()
  {
   audioClip.stop();
  }
}

   


  
   

