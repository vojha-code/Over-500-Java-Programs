import java.awt.*;
import java.applet.Applet;

public class SenderApplet extends Applet
implements java.awt.event.ActionListener
{

  private Label       appName      = null;
  private TextField   name         = null;
  private Label       msg          = null;
  private TextField  msgToBeSent  = null;
  private Button      sendButton   = null;
  private Label       ack          = null;

  public SenderApplet()
  {
    super();
  }

  public void init()
  {

    super.init();
    try
    {
      ack = new java.awt.Label();
      ack.setName("ack");
      ack.setText("");
      ack.setBounds(5,199,413,23);

      sendButton = new java.awt.Button();
      sendButton.setName("sendButton");
      sendButton.setBounds(140,144,85,23);
      sendButton.setLabel("Send");

      msgToBeSent = new java.awt.TextField();
      msgToBeSent.setName("msgToBeSent");
      msgToBeSent.setBounds(147,80,257,23);

      msg = new java.awt.Label();
      msg.setName("msg");
      msg.setText("Message To Be Sent");
      msg.setBounds(13,83,123,23);

      name = new java.awt.TextField();
      name.setName("name");
      name.setBounds(145,31,258,23);

      appName = new java.awt.Label();
      appName.setName("appletName");
      appName.setText("Applet name");
      appName.setBounds(13,38,93,23);

      setName("Sender Applet");
      setLayout(null);
      setSize(426,240);

      add(name,name.getName());
      add(msgToBeSent,msgToBeSent.getName());
      add(appName,appName.getName());
      add(msg,msg.getName());
      add(sendButton,sendButton.getName());
      add(ack,ack.getName());

      sendButton.addActionListener(this);
    }
    catch(java.lang.NullPointerException e)
    {
     System.out.println("Applet does not exit");
    }
    catch(Throwable e)
    {
     System.out.println(e);
    }
  }

  public void reciveAck(String msg)
  {

   ack.setText("Received Acknowledgement  from message");
  }

  public void send(String appName,String msg)
  {

    if(appName.equals("receiver"))
    {
      ReceiverApplet  recApp = (ReceiverApplet)getAppletContext().getApplet(appName);
      recApp.receiveMsg(appName,msg);
    }
    else
    {
     System.out.println("Receiver applet name not exits");
    }
  }

  public void actionPerformed(java.awt.event.ActionEvent e)
  {
   if((e.getSource() == sendButton))
   {
    send(name.getText(),msgToBeSent.getText());
   }
  }
  public String getAppletInfo()
  {
    return "SenderApplet";
  }
}


/*public class ReceiverApplet extends Applet
{

   private Label msgLabel = null;

   public ReceiverApplet()
   {
    super();
   }

   public void init()
   {
    super.init();

    try
    {

      setName("ReceiverApplet");
      setLayout(null);
      setSize(508,37);

      msgLabel = new java.awt.Label();
      msgLabel.setName("msgLabel");
      msgLabel.setText("Waiting for message");
      msgLabel.setBounds(9,5,494,23);

      add(msgLabel,msgLabel.getName());
    }
    catch(NullPointerException e)
    {
     System.out.println(e);
    }
    catch(Throwable e)
    {
     System.out.println(e);
    }
  }

  public void receiveMsg(String appName,String msg)
  {

   msgLabel.setText("Got The msg fron the applet"+appName);
   sendAck();
  }

  public void sendAck()
  {

    SenderApplet sendApp = (SenderApplet)getAppletContext().getApplet("sender");
    sendApp.reciveAck(getAppletInfo());
  }

  public String  getAppletInfo()
  {

    return "ReceiverApplet";
  }
}

    
*/



