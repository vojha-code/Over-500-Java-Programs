import java.awt.*;
import java.applet.*;

public class LoadImageExample extends Applet
{

  Image image;

  public void init()
  {
    System.out.println("loding the image.....");
    image = getImage(getCodeBase(),"IOC.gif");
  }

  public void paint(Graphics g)
  {
    g.drawImage(image,0,0,this);
  }

}
