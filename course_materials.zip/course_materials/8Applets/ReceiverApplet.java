import java.awt.*;
import java.applet.Applet;

public class ReceiverApplet extends Applet
{

   private Label msgLabel = null;

   public ReceiverApplet()
   {
    super();
   }

   public void init()
   {
    super.init();

    try
    {

      setName("ReceiverApplet");
      setLayout(null);
      setSize(508,37);

      msgLabel = new java.awt.Label();
      msgLabel.setName("msgLabel");
      msgLabel.setText("Waiting for message");
      msgLabel.setBounds(9,5,494,23);

      add(msgLabel,msgLabel.getName());
    }
    catch(NullPointerException e)
    {
     System.out.println(e);
    }
    catch(Throwable e)
    {
     System.out.println(e);
    }
  }

  public void receiveMsg(String appName,String msg)
  {

   msgLabel.setText("Got The msg fron the applet : "+appName);
   sendAck();
  }

  public void sendAck()
  {

    SenderApplet sendApp = (SenderApplet)getAppletContext().getApplet("sender");
    sendApp.reciveAck(getAppletInfo());
  }

  public String  getAppletInfo()
  {

    return "ReceiverApplet";
  }
}





