class EscapeCharacter
{
  public static void main(String args[])
  {

   System.out.println("\n\n  The Use of  Backslash b  in word Hello World : Hello \bWorld  ");
   System.out.println("\n\n       World \rHello  ");
   System.out.println("\n\n  ooooo\toooooooo  ");

  }
}
