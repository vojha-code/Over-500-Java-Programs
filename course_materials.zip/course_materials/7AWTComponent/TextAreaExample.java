import java.awt.*;

public class TextAreaExample extends Frame
{
  TextArea textArea;
  TextField textField;

  Label emailID,msg;

  String string;

  TextAreaExample()
  {
     string = "you can not edit the text";

     setLayout(new FlowLayout());
     setTitle("Text Area Example");

     emailID = new Label("email ID :");
     add(emailID);

     textField = new TextField(20);
     add(textField);

     msg = new Label("massage :");
     add(msg);

     textArea = new TextArea(5,20);
     add(textArea);

     msg = new Label("massage :");
     add(msg);

     textArea = new TextArea(string,3,20);
     textArea.setEditable(false);
     add(textArea);
   }

   public static void main(String args[])
   {

     TextAreaExample tae = new TextAreaExample();

     tae.pack();
     tae.setSize(300,270);
     tae.setVisible(true);

   }
}



