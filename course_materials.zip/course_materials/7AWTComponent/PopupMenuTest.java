/* To Run Put The Following Command
   >appletviewer PopupMenuTest.html
*/

import java.awt.*;
import java.awt.event.*;
import java.applet.*;


public class PopupMenuTest extends Applet
{
 
  PopupMenu popMenu;

  public void init()
  {
    MenuItem item;

    popMenu = new PopupMenu("Edit");
    item = new MenuItem("Select All");

    popMenu.add(item);
    item = new MenuItem("Replace");

    popMenu.add(item);
    popMenu.addSeparator();
    item = new MenuItem("Show JDK Help");

    popMenu.add(item);

    add(popMenu);
    enableEvents(AWTEvent.MOUSE_EVENT_MASK);
    resize(200,200);
  }

  public void processMouseEvent(MouseEvent me)
  {
   if(me.isPopupTrigger())
    popMenu.show(me.getComponent(),me.getX(),me.getY());
  }
}






