import java.awt.*;
import java.awt.event.*;

public class CheckboxExample extends Frame
implements ActionListener
{
  Checkbox servlets,jsp,ejb,vc;
  
  Button submit;

  CheckboxExample()
  {
    setTitle(" Checkbox Example ");
    setLayout(new FlowLayout());
    setFont(new Font("SanSerif",Font.BOLD,15));

    servlets = new Checkbox("Servlets",true);
    jsp       = new Checkbox("jsp",false);
    ejb       = new Checkbox("ejb");
    vc        = new Checkbox("VC");

    submit = new Button("Submit");

    add(servlets);
    add(jsp);
    add(ejb);
    add(vc);
    add(submit);

  }
  public void actionPerformed(ActionEvent e){}

  public static void main(String args[])
  {

    CheckboxExample ce = new CheckboxExample();

    ce.pack();
    ce.setSize(300,200);
    ce.setVisible(true);
  
    ce.addWindowListener(new WindowAdapter(){public void windowClosing( WindowEvent e ){System.exit( 0 );}}); 
  }
}
     
