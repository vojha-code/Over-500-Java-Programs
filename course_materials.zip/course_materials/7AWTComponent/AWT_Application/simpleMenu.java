
import java.awt.*;
public class simpleMenu extends Frame {
    simpleMenu () {
        super ("Menu Example");
        Menu m = new Menu ("File", true);
        m.add (new MenuItem ("New Web Browser", new MenuShortcut ('n')));
        m.add (new MenuItem ("New Mail Message", new MenuShortcut ('n', true)));
        m.add (new MenuItem ("New Folder"));
        m.addSeparator ();
        m.add (new MenuItem ("Close"));
        m.add (new MenuItem ("Quit"));
	MenuBar mb = new MenuBar ();
	mb.add (m);
        setMenuBar (mb);
        resize (200, 200);
      Menu  mm=new Menu("Edit",true) ;
    }
    public static void main (String args[]) {
        simpleMenu f = new simpleMenu();
	f.show();
    }
}
