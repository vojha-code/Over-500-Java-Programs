import java.awt.*;

public class ScrollBarExample extends Frame
{

  Scrollbar verticalSB,horizontalSB;

  Label vertical,horizontal;

  ScrollBarExample()
  {
    setTitle("Scroll Example");
    setLayout(new FlowLayout());

    vertical = new Label("This is vertical scroll bar");
    horizontal = new Label("This is horizontal scroll bar");

    int width = 300, height = 200;

    verticalSB    = new Scrollbar(Scrollbar.VERTICAL,0,1,0,height);
    horizontalSB  = new Scrollbar(Scrollbar.HORIZONTAL,0,1,0,width);

    add(vertical);
    add(verticalSB);
    add(horizontal);
    add(horizontalSB);

  }

  public static void main(String args[])
  {

    ScrollBarExample sbe = new ScrollBarExample();

    sbe.pack();
    sbe.setSize(300,200);
    sbe.setVisible(true);

  }
}

    
