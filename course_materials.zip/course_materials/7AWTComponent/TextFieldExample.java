import java.awt.*;

public class TextFieldExample extends Frame
{

  TextField emailID,password;

  TextFieldExample()
  {
    setLayout(new FlowLayout());
    setTitle("Text Filed Example");

    Label label1 = new Label("email ID :",Label.RIGHT);
    Label label2 = new Label("Password :",Label.RIGHT);

    emailID  = new TextField(12);
    password = new TextField(8);
    password.setEchoChar('*');

    add(label1);
    add(emailID);
    add(label2);
    add(password);
  }

  public static void main(String args[])
  {

    TextFieldExample textfe = new TextFieldExample();

    textfe.pack();
    textfe.setSize(500,200);
    textfe.setVisible(true);

  }

}





