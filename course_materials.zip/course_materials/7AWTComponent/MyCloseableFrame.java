import java.awt.*;
import java.awt.event.*;

public class MyCloseableFrame extends Frame
{

  private Button top        = new Button("Say Hello");
  private Button buttom     = new Button("Say Goodbye");
  private TextArea textArea = new TextArea(15,30);
  private MyButtonListener  mbl;
  private MyWindowListener mwl;

  MyCloseableFrame()
  {
   setupGUI();
  }
    
  public static void main(String args[])
  {
   MyCloseableFrame mcf = new MyCloseableFrame();
  }

  private void setupGUI()
  {

   // Container c ;

   //c = getContentPane();

   add(top,BorderLayout.NORTH);
   add(buttom,BorderLayout.SOUTH);
   add(textArea,BorderLayout.CENTER);

   mbl = new MyButtonListener(textArea);
   mwl = new MyWindowListener();

   top.addActionListener(mbl);
   buttom.addActionListener(mbl);
   addWindowListener(mwl);
                                
   setSize(300,300);
   setVisible(true);
 }
}

class MyButtonListener implements ActionListener
{
  TextArea textArea;

  MyButtonListener(TextArea ta)
  {
    textArea = ta;
  }

  public void actionPerformed(ActionEvent e)
  {
    if(e.getActionCommand().equals("Say Hello"))
      textArea.append("Hello \n");

    else if(e.getActionCommand().equals("Say Goodbye"))
      textArea.append("Bye \n");
    
  }
}

class MyWindowListener implements WindowListener
{

  public void windowClosing(WindowEvent e)
  {

    Window w = (Window) e.getSource();
    w.setVisible(false);
    w.dispose();
    System.exit(0);
  }
  public void windowOpened(WindowEvent e){}
  public void windowClosed(WindowEvent e){}
  public void windowIconified(WindowEvent e){}
  public void windowDeiconified(WindowEvent e){}
  public void windowActivated(WindowEvent e){}
  public void windowDeactivated(WindowEvent e){}

}
