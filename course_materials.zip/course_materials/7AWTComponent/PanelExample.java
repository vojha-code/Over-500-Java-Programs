import java.awt.*;

public class PanelExample extends Panel
{

   public static void main(String args[])
   {

      Frame f = new Frame("Panel Example Window ");

      PanelExample pe = new PanelExample();

      f.add("Center",pe);

      Label msg = new Label("Wellcome to Varuns world");

      f.add("Center",msg);

      f.setSize(200,200);

      f.show();// making frame visible

   }
}
