import java.awt.*;
import java.awt.event.*;

public class ChoiceListExample extends Frame
implements ActionListener
{
  Choice choice;

  Label label;

  ChoiceListExample()
  {

    setLayout(new FlowLayout());
    setTitle(" Choice List Example");

    choice  = new Choice();

    label = new Label("Choice your Option");

    choice.add("C++");
    choice.add("c");
    choice.add("Core Java ");
    choice.add("DB2");

    add(label);
    add(choice);

  }
  
  public void actionPerformed(ActionEvent e){}
  
  public static void main(String args[])
  {

    ChoiceListExample cle = new ChoiceListExample();

    cle.setSize(300,200);
    cle.pack();
    cle.setVisible(true);
    
    cle.addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){System.exit(0);}}); 
  }                                
}



