import java.awt.*;
import java.awt.event.*;

public class EventExample extends Frame
{

  Label empName;
  TextField name;
  Button setName;
  Button exit;
  EventHandling exitEvent;

  EventExample()
  {
    setLayout(new FlowLayout());
    setFont(new Font("Arial",Font.PLAIN,12));

    empName = new Label("Employee Name",Label.LEFT);
    name    = new TextField(11);
    setName = new Button("Set Name");
    exit    = new Button("Exit");

    add(empName);
    add(name);
    add(setName);
    add(exit);

    exitEvent = new EventHandling(this);
    setName.addActionListener(exitEvent);
    exit.addActionListener(exitEvent);

  }

  public static void main(String args[])
  {

    EventExample fls = new EventExample();

    fls.pack();
    fls.setSize(250,200);
    fls.setVisible(true);
  }

}

class EventHandling implements ActionListener
{

  private EventExample ee;

  public EventHandling(EventExample e)
  {
    ee = e;
  }

  public void actionPerformed(ActionEvent ae)
  {

    if(ae.getSource() == ee.setName)
    {
     ee.name.setText("George");
    }

    if(ae.getSource() == ee.exit)
    {
     System.out.println("Exiting...!!!");
     ee.dispose();
     System.exit(0);
    }
  }
}
