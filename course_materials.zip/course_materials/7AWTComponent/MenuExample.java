import java.awt.*;

public class MenuExample extends Frame
{

  MenuExample(String title)
  {
    super(title);

    MenuBar mbr = new MenuBar();
    setMenuBar(mbr);

    Menu menuprofessional = new Menu("Software Professional");

    MenuItem personalInfo,qualification,experience;

    menuprofessional.add(personalInfo = new MenuItem("Personal Info"));
    menuprofessional.add(new MenuItem("-"));
    menuprofessional.add(qualification = new MenuItem("Qualification"));

    CheckboxMenuItem fresher = new CheckboxMenuItem("Fresher");

    menuprofessional.add(fresher);
    menuprofessional.add(experience = new MenuItem("Professional Experience"));

    Menu skills = new Menu("Skill");
    MenuItem skill1,skill2,skill3,skill4;

    skills.add(skill1 = new MenuItem("C"));
    skills.add(skill2 = new MenuItem("C++"));
    skills.add(skill3 = new MenuItem("Java"));
    skills.add(skill4 = new MenuItem("Oracle"));

    menuprofessional.add(skills);

    mbr.add(menuprofessional);

  }

  public static void main(String args[])
  {

    MenuExample menu = new MenuExample("Employee Details");

    menu.pack();
    menu.setSize(300,200);
    menu.setVisible(true);
  }
}


  
