import java.awt.*;

public class ListExample extends Frame
{

  List list1,list2;

  Label select1,select2;

  ListExample()
  {

    setTitle("List Example");
    setLayout(new FlowLayout());

    list1 = new List(4,true);
    list2 = new List(4,false);

    select1 = new Label("select one or more:");
    select2 = new Label("select only one   :");

    list1.add("Java");
    list1.add("servelet");
    list1.add("EJB");
    list1.add("JSP");
    list2.add("ASP");
    list2.add(".NET");
    list2.add("VC++");
    list2.add("Activex");
    list2.add("VB");
    list2.add("VB.NET");



    add(select1);
    add(list1);
    add(select2);
    add(list2);

  }

  public static void main(String args[])
  {

    ListExample le = new ListExample();

    le.pack();
    le.setSize(300,200);
    le.setVisible(true);

  }
}











