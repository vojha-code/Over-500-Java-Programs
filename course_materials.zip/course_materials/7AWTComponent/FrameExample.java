import java.awt.*;

public class FrameExample extends Frame
{

   FrameExample()
   {
     Label massage = new Label("Wellcome to Varun's world");
     add(massage);
   }

   public static void main(String args[])
   {

      FrameExample f = new FrameExample();

      f.setTitle("Working with frames");//title of frame

      f.setSize(300,100);//The size of window

      f.setVisible(true);//To show the frame window
   }
}


