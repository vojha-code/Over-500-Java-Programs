import java.awt.*;

public class ScrollPaneExample extends Frame
{

  ScrollPaneExample()
  {
   super();
  }

  public static void main(String args[])
  {

    ScrollPaneExample spe = new ScrollPaneExample();

    spe.setTitle("Scroll Pane EXample ");
    spe.setSize(300,100);
    spe.setVisible(true);
    spe.setLayout(new FlowLayout());

    ScrollPane sp = new ScrollPane();

    sp.setSize(100,45);
    TextArea ta = new TextArea();
    ta.setSize(125,50);
    sp.add(ta);
    spe.add(sp);

    ScrollPane sp1 = new ScrollPane();
    sp1.setSize(100,45);
    spe.add(sp1);
  }
}
