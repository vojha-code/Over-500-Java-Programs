import java.awt.*;

class CanvasExample extends Canvas
{

  public CanvasExample()
  {
    setBackground(Color.yellow);
  }

  public void paint(Graphics g)
  {
    g.drawString("Welcome to varun's world display using Canvas",50,100);
    //the(x,y)=(50,100)
  }
}

public class FrameCanvas extends Frame
{
    CanvasExample ce = new CanvasExample();

   public FrameCanvas()
   {
      setSize(400,200);

      setTitle("Canvas Example");

      add(ce,BorderLayout.CENTER);

      setVisible(true);

   }

   public static void main(String args[])
   {

      FrameCanvas fc = new FrameCanvas();
    }

}
    

    
