import java.awt.*;
import java.awt.event.*;

public class ButtonExample extends Frame
implements ActionListener
{

  Button reset, submit;

  Label click;

  ButtonExample()
  {
    setTitle("Button Example");
    setLayout(new FlowLayout());

    click = new Label("Click any of this button");

    reset  = new Button("reset");
    submit = new Button("submit");

    add(click);
    add(reset);
    add(submit);

  }
  public void actionPerformed(ActionEvent e){}

  public static void main(String args[])
  {

    ButtonExample be = new ButtonExample();

    be.pack();
    be.setSize(300,200);
    be.setVisible(true);

    be.addWindowListener(new WindowAdapter(){public void windowClosing( WindowEvent e ){System.exit( 0 );}});
  }
}
