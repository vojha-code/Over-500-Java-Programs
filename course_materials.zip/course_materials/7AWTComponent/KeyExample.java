import java.awt.*;
import java.awt.event.*;

public class KeyExample extends Frame
{
  Label empName;

  TextField name;

  ExitButtonClass exit,setName;

  KeyExample()
  {

    super(" Key Example");

    setLayout(new FlowLayout());
    setFont(new Font("Arial",Font.PLAIN,12));

    empName = new Label("Employee Name",Label.LEFT);

    name    = new TextField(11);

    setName = new ExitButtonClass("setName",this);
    exit    = new ExitButtonClass("Exit",this);

    add(empName);
    add(name);
    add(setName);
    add(exit);

    enableEvents(AWTEvent.KEY_EVENT_MASK | AWTEvent.WINDOW_EVENT_MASK);

    pack();
    setVisible(true);

   }

   public void processEvent(AWTEvent event)
   {
     if(event.getID() == WindowEvent.WINDOW_CLOSING)
        exitApplication();

     if(event.getID() == KeyEvent.KEY_TYPED && (((KeyEvent) event).getKeyChar() == 'e' || ((KeyEvent) event).getKeyChar() == 'E'))
        exitApplication();

     if(event.getID() == KeyEvent.KEY_TYPED && (((KeyEvent) event).getKeyChar() == 's' || ((KeyEvent) event).getKeyChar() == 'S'))
        name.setText("Varun");
   }

   public void exitApplication()
   {
     System.out.println("Exiting..!!!");
     dispose();
     System.exit(0);
   }

   public static void main(String args[])
   {

    KeyExample ke = new KeyExample();

    ke.pack();
    ke.setSize(250,200);
    ke.setVisible(true);

   }
}

class ExitButtonClass extends Button
{
  private KeyExample ke;

  public ExitButtonClass(String str,KeyExample e)
  {

   super(str);
   ke = e;

    enableEvents(AWTEvent.KEY_EVENT_MASK | AWTEvent.WINDOW_EVENT_MASK);
  }

  public void processEvent(AWTEvent event)
   {
     if((event instanceof ActionEvent) && ((ActionEvent) event).getSource() == this)
         ke.exitApplication();

     if(event.getID() == KeyEvent.KEY_TYPED && (((KeyEvent) event).getKeyChar() == 'e' || ((KeyEvent) event).getKeyChar() == 'E'))
        ke.exitApplication();

     if(event.getID() == KeyEvent.KEY_TYPED && (((KeyEvent) event).getKeyChar() == 's' || ((KeyEvent) event).getKeyChar() == 'S'))
        ke.name.setText("Varun");

     super.processEvent(event);
   }
}




