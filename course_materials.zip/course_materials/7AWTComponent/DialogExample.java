import java.awt.*;

public class DialogExample extends Frame
{

  DialogExample()
  {
    super();
  }

  public static void main(String  args[])
  {
    DialogExample de = new DialogExample();

    de.setTitle("Working with dialog");

    de.setSize(300,100);

    de.setVisible(true);

    Dialog d = new Dialog(de,"Dialog");

    d.setSize(200,75);

    d.show();

    FileDialog fd = new FileDialog(de,"FileDialog");

    fd.setVisible(true);

  }
}

