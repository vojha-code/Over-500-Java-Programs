import java.lang.reflect.*;
import java.awt.*;

class ConstructorArrgumentExample
{

  public static void main(String args[])
  {

    Label lobj;
    Class jbcl;
    String text = "Message";

    Class[] argsClass = new Class[]{String.class};

    Object[] arguments = new Object[]{text};

    Constructor argsCons;

    try
    {

      jbcl = Class.forName("java.awt.Label");

      argsCons = jbcl.getConstructor(argsClass);

      lobj = (Label)instantiateClass(argsCons,arguments);
   }
   catch(ClassNotFoundException e)
   {
    e.printStackTrace();
   }
   catch(NoSuchMethodException e)
   {
    e.printStackTrace();
   }
  }

  public static Object instantiateClass(Constructor  consParam,Object[] argArray)
  {

    System.out.println("Constructor : "+consParam.toString());

    Object obj = null;

    try
    {

      obj = consParam.newInstance(argArray);


      System.out.println("Object :"+obj.toString());

      return obj;
    }
    catch(InstantiationException e)
    {
    e.printStackTrace();
    }
    catch(IllegalAccessException e)
    {
    e.printStackTrace();
    }
    catch(IllegalArgumentException e)
    {
    e.printStackTrace();
    }
    catch(InvocationTargetException e)
    {
    e.printStackTrace();
    }

    return obj;
   }
}

      
     
