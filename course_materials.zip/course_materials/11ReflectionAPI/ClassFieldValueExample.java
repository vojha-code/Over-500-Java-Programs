import java.lang.reflect.*;
import java.awt.*;

public class ClassFieldValueExample
{

  public static void main(String args[])
  {

   Point p = new Point(100,250);
   displayXY(p);
  }

  static void displayXY(Point p)
  {

    Field xField;
    Field yField;

    Integer xValue;
    Integer yValue;

    Class cl = p.getClass();

    try
    {

      xField = cl.getField("x");
      yField = cl.getField("y");

      xValue = (Integer) xField.get(p);
      yValue = (Integer) yField.get(p);

      System.out.println("Value of point class field are :");

      System.out.println("x  Coordinate :"+xValue.toString());
      System.out.println("y  Coordinate :"+yValue.toString());

    }
    catch(NoSuchFieldException e)
    {
     e.printStackTrace();
    }
    catch(SecurityException e)
    {
      e.printStackTrace();
    }
    catch(IllegalAccessException e)
    {
     e.printStackTrace();
    }
  }
}


