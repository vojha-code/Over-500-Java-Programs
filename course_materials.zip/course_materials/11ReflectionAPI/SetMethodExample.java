import java.lang.reflect.*;
import java.awt.*;

class SetMethodExample
{
 static
 {
  System.out.println();
 }
 public static void main(String args[])
 {
  Point p = new Point(200,200);

  System.out.println("Intially  assigned value is :"+p.toString());

  changeXY(p,new Integer(350),new Integer(600));

  System.out.println("Changed value is            :"+p.toString());
 }

 static void changeXY(Point p,Integer xVal,Integer yVal)
 {

   Field xField;
   Field yField;

   Class cl = p.getClass();

   try
   {

     xField = cl.getField("x");
     yField = cl.getField("y");

     xField.set(p,xVal);
     yField.set(p,yVal);

   }
   catch(NoSuchFieldException e)
   {
    e.printStackTrace();
   }
   catch(SecurityException e)
   {
     e.printStackTrace();
   }
   catch(IllegalAccessException e)
   {
    e.printStackTrace();
   }
 }
}

