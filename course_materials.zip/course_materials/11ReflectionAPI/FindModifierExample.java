import java.lang.reflect.*;
import java.util.*;

final class MyClass{}

class FindModifierExample
{

  public static void main(String args[])
  {

    Class cl = MyClass.class;
    displayModifiers(cl);
  }

  static void displayModifiers(Class cl)
  {

    int mod = cl.getModifiers();

    if(Modifier.isPublic(mod))
      System.out.println("\nModifier is public ");

    if(Modifier.isPrivate(mod))
      System.out.println("\nModifier is private ");

    if(Modifier.isAbstract(mod))
      System.out.println("\nModifier is Abstarct ");

    if(Modifier.isFinal(mod))
      System.out.println("\nModifier is Final ");

    return;
  }
}


