import java.util.*;

interface MyInterfaceOne{};
interface MyInterfaceTwo{};
class Grandfather{};
class Father extends Grandfather {};
class Son extends Father implements MyInterfaceOne,MyInterfaceTwo{};

public class SuperClassHierarchy
{

  public static void main(String args[])
  {

    Son  sObj = new Son();

    displaySuperClass(sObj);
    displayInterfaces(sObj);
  }

  public static void displaySuperClass(Object obj)
  {

    Class cl = obj.getClass();
    Class superClass = cl.getSuperclass();

    int i=1;

    System.out.println("Hierarchy from immediate super class to top");

    while(superClass !=null)
    {

      String name = superClass.getName();
      System.out.println("Hierarchy :"+i++ +" "+name);

      superClass = superClass.getSuperclass();
    }

   }

   public static void displayInterfaces(Object obj)
   {

     int count = 0;

     Class cl = obj.getClass();
     Class[] interfaceList = cl.getInterfaces();

     System.out.println("Interface implemented by class are");

     while(count<interfaceList.length)
     {

       String iname = interfaceList[count].getName();
       System.out.println(iname);
       count++;
     }
   }
}




