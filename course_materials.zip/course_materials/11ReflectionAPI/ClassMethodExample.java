import java.lang.reflect.*;

class MyClass
{
  static
  {
    System.out.println();
  }

  public void getData(int a,String s,float c){}
  public void putData(int a,int b){}
}

class ClassMethodExample
{

   public  static void main(String args[])
   {

     MyClass myObj = new MyClass();

     displayMethod(myObj);
   }

   static void displayMethod(Object obj)
   {

     int count = 0;

     Class cl = obj.getClass();

     Method[] stringMethods = cl.getMethods();

     while(count<stringMethods.length)
     {

       String methodName = stringMethods[count].getName();
       String returnType  = stringMethods[count].getReturnType().getName();

       System.out.print(returnType+"  "+methodName+"(");

       Class[] parameterType = stringMethods[count].getParameterTypes();

       for(int i=0; i<parameterType.length;i++)
       {
         String parameterName = parameterType[i].getName();
         System.out.print("  "+parameterName);
       }

       System.out.println(" );");
       count++;
     }
   }


}

          


    
  
