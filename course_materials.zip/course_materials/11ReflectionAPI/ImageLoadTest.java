import java.awt.*;
import java.awt.image.*;
import java.applet.*;

public class ImageLoadTest extends Applet
{

  private Font f;
  private Image im = null;
  private String str = null;

  public void init()
  {
    f = new Font( "Courier", Font.BOLD, 20 );
    im  = getImage(getDocumentBase(),getParameter("image"));
    str = "Minisha Lamba";
  }

  public void paint(Graphics g)
  {
   g.setFont( f );
   g.drawImage(im,50,50,this);
   try
   {
     Thread.sleep(1000);
   }
   catch(Exception e)
   {
    System.out.println(e);
   }
   g.drawString(str,160,350);

  }
}
