import java.util.*;

class MyClass
{ 
  {System.out.println();}
};

class FindClassNameExample
{

  public static void main(String args[])
  {

    String className;

    MyClass myObj = new MyClass();

    Class cl = myObj.getClass();

    System.out.println("Class Name is :"+cl.getName());

  }
}
