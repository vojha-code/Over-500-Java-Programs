import java.lang.reflect.*;
import java.awt.*;

class ClassFieldExample
{

  public static void main(String args[])
  {
   
    Class ab = java.awt.Button.class;
    displayField(ab);
  }

  public static void displayField(Class cl)
  {

    int count = 0;

    Field[] publicField = cl.getFields();

    System.out.println();
    System.out.println("DataType\tField Name");
    System.out.println();

    while(count<publicField.length)
    {

      String fName = publicField[count].getName();
      Class  fType = publicField[count].getType();

      String typeName = fType.getName();

      System.out.println(typeName+"\t\t"+fName);

      count++;

    }
  }
}
