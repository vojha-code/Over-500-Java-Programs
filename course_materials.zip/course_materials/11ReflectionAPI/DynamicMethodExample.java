import java.lang.reflect.*;

class DynamicMethodExample
{

  public static void main(String args[])
  {

    String str1 = "Hello ";
    String str2 = "Welcome to Variun's World";

    String concatenatedstring =  concatenateStrings(str1,str2);

    System.out.println(concatenatedstring);
  }

  public static String  concatenateStrings(String sourceString,String targetString)
  {

     String resultantString = null;

     Class cl = String.class;

     Class[] parameterType = new Class[]{String.class};

     Method concatenateMethod;

     Object[] args = new Object[]{targetString};

     try
     {

       concatenateMethod = cl.getMethod("concat",parameterType);

       resultantString = (String)concatenateMethod.invoke(sourceString,args);
     }
     catch(NoSuchMethodException e)
     {
      e.printStackTrace();
     }
     catch(IllegalAccessException e)
     {
      e.printStackTrace();
     }
     catch(InvocationTargetException e)
     {
      e.printStackTrace();
     }
     return resultantString;
   }
}
    
