import java.lang.reflect.*;
import java.awt.*;

class GetSetExample
{
  static
  {
   System.out.println();
  }

  public static void main(String args[])
  {

    int[] arr1 = {1,2,3,4,5};
    int[] arr2 = new int[5];

    arrayCopy(arr1,arr2);
  }

  public static void arrayCopy(Object arr1,Object arr2)
  {

    Object temp = null;

    for(int i=0;i<5;i++)
    {
     temp = Array.get(arr1,i);
     Array.set(arr2,i,temp);
    }

    for(int i=0;i<5;i++)
    {

      temp = Array.get(arr2,i);
      System.out.println(temp);
    }
  }
}

