import java.lang.reflect.*;
import java.net.*;

class MyClass
{

  public MyClass()
  {
   
    System.out.println("0 arrgument invoked by constructor");
  }

  public MyClass(int a,String s,float f){}
};

class ClassConstructorExample
{

  public static void main(String args[])
  {
   Class myClass =MyClass.class;
   Constructor[] mycons = myClass.getConstructors();

   int count = 0;

   while(count<mycons.length)
   {

     System.out.print(myClass.getName()  +"( ");

     Class[] ConsParameterType = mycons[count].getParameterTypes();

     for(int index=0; index < ConsParameterType.length; index++)
     {

       String parameterString = ConsParameterType[index].getName();
       System.out.print(parameterString+" ");
     }

     System.out.println(");");
     count++;
   }

   try
   {
     Object obj = myClass.newInstance();
     obj = null;
   }
   catch(InstantiationException e)
   {
    e.printStackTrace();
   }
   catch(IllegalAccessException e)
   {
    e.printStackTrace();
   }
 }
}

    
   
  
   
