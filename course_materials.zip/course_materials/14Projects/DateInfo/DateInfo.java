import java.io.*;

class DateInfo
{
  int callYear(int x)//claculate info about the year
  {
   int leep=x/4;
   int odinary=x-leep;
   int Todd=leep*2+odinary;
   int week=Todd/7;
   int Aodd=Todd-week*7;
   //System.out.println("\n ODD : "+Aodd);
   return Aodd;
  }

//------> DMO , If LEEP YEAR:

  int callDayMonthL(int d,int m)//calculate info about the month of leep year
  {
   if(m==1)
    return  callDayCalculator(d);
   else if(m==2)
    return  callDayCalculator(d+31);
   else if(m==3)
    return  callDayCalculator(d+60);
   else if(m==4)
    return  callDayCalculator(d+91);
   else if(m==5)
    return  callDayCalculator(d+121);
   else if(m==6)
    return  callDayCalculator(d+152);
   else if(m==7)
    return  callDayCalculator(d+182);
   else if(m==8)
    return  callDayCalculator(d+213);
   else if(m==9)
    return  callDayCalculator(d+244);
   else if(m==10)
    return  callDayCalculator(d+274);
   else if(m==11)
    return  callDayCalculator(d+305);
   else  if(m==12)
    return  callDayCalculator(d+335);
   else
    return 0;
  }

//-------->DMO, IF NOT LEEP YEAR

  int callDayMonthNotL(int d,int m)//calculate info about the month of not leep year
  {
   if(m==1)
    return  callDayCalculator(d);
   else if(m==2)
    return  callDayCalculator(d+31);
   else if(m==3)
    return  callDayCalculator(d+59);
   else if(m==4)
    return  callDayCalculator(d+90);
   else if(m==5)
    return  callDayCalculator(d+120);
   else if(m==6)
    return  callDayCalculator(d+151);
   else if(m==7)
    return  callDayCalculator(d+181);
   else if(m==8)
    return  callDayCalculator(d+212);
   else if(m==9)
    return  callDayCalculator(d+243);
   else if(m==10)
    return  callDayCalculator(d+273);
   else if(m==11)
    return  callDayCalculator(d+304);
   else if(m==12)
    return  callDayCalculator(d+334);
   else
    return 0;
  }

//-----> ODD DAY CALCULATOR:

 int callDayCalculator(int d)//calculate info about the day
 {
  int week=d/7;
  int TO=d-week*7;
  return TO;
 }


//----> MAIN BODY:

  void calculate()
  {
   
   try
   { 
 
    BufferedReader br  =  new BufferedReader(new InputStreamReader(System.in));
    System.out.println("\n -------------> This is the Day finder System <----------");
   
    System.out.print("\nEnter Day :"); 
    int Day=Integer.parseInt(br.readLine());

    System.out.print("\nEnter Month :");
    int Month=Integer.parseInt(br.readLine());

    System.out.print("\nEnter Year :"); 
    int Year=Integer.parseInt(br.readLine());

    int DMO=0;
    int Odd=0;
    System.out.println("\n The  Input Date is : "+Day+"/"+Month+"/"+Year);

    if(Year%4==0)
      DMO=callDayMonthL(Day,Month);
    else
      DMO=callDayMonthNotL(Day,Month);
    
    //System.out.println(" DMO :"+DMO);


    if(Day!=0 && Month!=0)
      Year=Year-1;
  
    int YR=Year-400*(Year/400);
    //System.out.println("\n Rem:"+YR);


    if(YR==0 && Day==0 && Month==0)
      System.out.println("\n\n 1st Jan of This Year is SATURDAY");

    if(YR<100)
    {
      Odd=DMO+callYear(YR);

      if(Odd<=7)
        callDayPrinter(Odd);
      else
        callDayPrinter(callDayCalculator(Odd));
    }

    if(YR==100)
    {
      Odd=DMO+5;

      if(Odd<=7)
         callDayPrinter(Odd);
      else
         callDayPrinter(callDayCalculator(Odd));
    }

    if(YR>100&&YR<200)
    {
      int R1=YR-100;
      Odd=5+callYear(R1);
      Odd=Odd+DMO;

      if(Odd<=7)
        callDayPrinter(Odd);
      else
        callDayPrinter(callDayCalculator(Odd));
     //System.out.println("\n Total Odd Day : "+Odd);
    }

    if(YR==200)
    {
      Odd=DMO+3;

      if(Odd<=7)
        callDayPrinter(Odd);
      else
        callDayPrinter(callDayCalculator(Odd));
    }

    if(YR>200 && YR<300)
    {
      int R1=YR-200;
      Odd=3+callYear(R1);
      Odd=Odd+DMO;

      if(Odd<=7)
        callDayPrinter(Odd);
      else
        callDayPrinter(callDayCalculator(Odd));
     //System.out.println("\n Total Odd Day : "+Odd);
    }

    if(YR==300)
    {
      Odd=DMO+1;
 
      if(Odd<=7)
        callDayPrinter(Odd);
      else
        callDayPrinter(callDayCalculator(Odd));
    } 
   
    if(YR>300)
    {
      int R1=YR-300;
      Odd=1+callYear(R1);
      Odd=Odd+DMO;

      if(Odd<=7)
        callDayPrinter(Odd);
      else
        callDayPrinter(callDayCalculator(Odd));
     //System.out.println("\n Total Odd Day : "+Odd);
    }
   
   }
   catch(Exception e)
   {
    System.out.println("Errpr "+e);
   } 
  }

//-------->Printing BODY:

 void callDayPrinter(int d)
  {
   if(d==0 || d==7)
    System.out.println("\n The  Day is SUNDAY ");
   if(d==1)
    System.out.println("\n The  Day is MONDAY ");
   if(d==2)
    System.out.println("\n The  Day is TUESDAY ");
   if(d==3)
    System.out.println("\n The  Day is WEDNESDAY ");
   if(d==4)
    System.out.println("\n The  Day is THURSDAY ");
   if(d==5)
    System.out.println("\n The  Day is FRIDAY ");
   if(d==6)
    System.out.println("\n The  Day is SUTRDAY ");
  }

 public static void main(String args[])
  {
   DateInfo di=new DateInfo();
   di.calculate();
  }
}
