import java.io.*;
import java.sql.*;
import java.util.Date;

class Railways
{
 public static void main(String args[])
 {
   try{
 
       Date today=new Date();
      
       System.out.println("\n\n ****** Welcom To The Railways Ticket Counter ******  ");
       System.out.println("\n\n        Today is "+today);
       System.out.println("\n\n ----------------------------------------------------- ");

       
       BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
       
       System.out.print("\n  From St. : "); 
       String City1=br.readLine();
       
       System.out.print("\n  To St.   : ");   
       String City2=br.readLine();

       System.out.print("\n  For The class ( FL->Local , FE->Express , FS->Super Fast ) : ");
       String OfFare=br.readLine(); 

       int dist=0;
       int fare=0;
 
       
       if(OfFare.equals("FL")) 
        System.out.println("\n  The Ticket is for the Local Class Tarval");
       if(OfFare.equals("FE")) 
        System.out.println("\n  The Ticket is for the Exprese Class Tarval");
       if(OfFare.equals("FS"))
        System.out.println("\n  The Ticket is for the Super Fast Class Tarval");

       
       
   
       Connection Con;
       Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
       Con=DriverManager.getConnection("jdbc:odbc:Railway");
       Statement stmt=Con.createStatement();

       String sql="Select "+ City1 +" from Dist where City='"+City2+"' ";

       ResultSet rs=stmt.executeQuery(sql);
   
       while(rs.next())
        {
        dist=rs.getInt(City1);
        }    
       System.out.println("\n  The Distence is : "+dist);
      
      Statement stmt1=Con.createStatement();
      
      String sql1=" Select "+ OfFare + " from FARE_TABLE where R1<"+dist+" AND  R2>="+dist+" ";
      
      ResultSet rs1=stmt1.executeQuery(sql1); 
      
      while(rs1.next())
       {
        fare=rs1.getInt(OfFare);
       }    
      System.out.println("\n  The Fare     is : "+fare);
 
      System.out.println("\n\n        ***********  Thank You  ***********");
     
      System.out.println("\n  ----------------------------------------------------- "); 
       
     }
     catch(Exception e)
     {
      System.out.println(e);
     }
           
 }
}

