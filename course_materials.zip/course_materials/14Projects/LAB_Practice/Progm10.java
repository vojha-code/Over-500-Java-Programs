/* 10.Writw a programme using concept of inheritance as the
      following discription:In class A two variable are declered.
      This is the parent class .Class B which takes variable a,b
      from parent class multiply with third variable with its own
      and display the result. */

class A
{
 int a=2;
 int b=3;
}
class B extends A
{
 int c=4;
 
 int a()
 {
  return(c*a);
 }
 int b()
 {
  return(c*b);
 }
}
class Progm10
{
 public static void main(String args[])
 {
  B obj=new B();

  int r;
  r=obj.a();
    System.out.println("\nResult AXC:"+r);

  r=obj.b();
    System.out.println("\nResult BXC:"+r);
 }
}

