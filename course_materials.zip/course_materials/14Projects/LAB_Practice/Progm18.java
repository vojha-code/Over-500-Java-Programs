/* 18.Write a programme using try catch to generate -ve
     ArrayIndexException,ArithmaticException to catch division
     by zero.  */

class Progm18
{
 public static void main(String args[])
 {
 int array[]=new int[2];
  int a;
   try
   {
    array[0]=1;
    array[1]=2;
    array[-2]=3;
    }
   catch(ArrayIndexOutOfBoundsException e)
   {
    System.out.println("\nWrong Array Opration");
   }
   try
   {
     a=1/0;
   }
   catch(ArithmeticException e)
   {
    System.out.println("\nWrong Arithmatic Opration");
   }
  }
}

