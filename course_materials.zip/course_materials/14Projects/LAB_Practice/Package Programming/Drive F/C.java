import p1.*;
import p2.p3.*;
class C
{
   public static void main(String args[])
   {
      A a=new A();
      B b=new B();
   } 
}
