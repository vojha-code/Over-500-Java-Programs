package p2.p3;
public class B
{
  public B()
  {
     System.out.println("I M B");
  } 
   
}
