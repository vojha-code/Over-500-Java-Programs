package p1;
public class A
{
   public A()
   {
      System.out.println("I M A");
   } 
}
