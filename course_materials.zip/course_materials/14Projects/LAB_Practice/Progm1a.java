/* 1a.Write a programme of Summing Even numbers. */

class SumEven
{
 void sum(int n)
 {
  int i,sum=0;
   for(i=1;i<=n;i++)
    {
     if((i&1)==0)
     //if(i%2==0)
        sum=sum+i;
    }
  System.out.println("\n Sum Of Even Numbers Is :"+sum);
 }
}
class Progm1a
{
public  static void  main(String args[])
  {
   SumEven obj=new SumEven();
    obj.sum(10);
  }
 
}
