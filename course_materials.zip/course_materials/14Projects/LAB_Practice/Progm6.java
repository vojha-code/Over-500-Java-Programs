/* 6.Write a programme to illustrate the concept of 
     instance varriable hidding. */



class Instance

 {

   int x=2;
   
   void hide(int x)
   {
    
 
     System.out.println("\nHide Variable:"+x);
   }
   
 }


class Progm6

 {
   public static void main(String args[])

   {

     Instance obj=new Instance();
    
         obj.hide(4);

   }

 }
