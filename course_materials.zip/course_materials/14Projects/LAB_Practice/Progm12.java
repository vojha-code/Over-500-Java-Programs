/* 12.Using interface calculate area of rectangl
      and circle.   */

interface Area
{
  double PI=3.14;
  abstract void area();
}
class Rectangle implements Area
{
 int l,b;
 public void area()
 {
  int a=l*b;
  System.out.println("\nArea Of Rectangle :"+a+" cm sqr");
 }
 void rect(int l,int b)
 {
  this.l=l;
  this.b=b;
 }
} 

class Circle implements Area
{
 int r;
 public void area()
 {
  double a=r*r*PI;
  System.out.println("\nArea Of Circle :"+a+" cm sqr");
 }
 void circle(int r)
 {
  this.r=r;
 }
} 
class Progm12
{
 public static void main(String args[])
 {
  Rectangle ob1=new Rectangle();
  ob1.rect(2,4);
  ob1.area();

  Circle ob=new Circle();
  ob.circle(3);
  ob.area();
 }
}

          
