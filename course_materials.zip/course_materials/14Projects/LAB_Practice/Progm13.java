/* 13.Write a programme that will read two matrix and their
      products.Before peformming oppration also check the
      oder of matrix.  */

class Matrix
{
  Matrix()
  {
   int i,j=0,k;
    int a[][]={{1,2},{2,4}};
    
     for(i=0;i<a.length;i++)
     {
       System.out.print("\n");
      for(j=0;j<a.length;j++)
       {
        System.out.print("  "+a[i][j]);
        System.out.print(" ");
       }
     }
   System.out.print("\n The order of matrix Is: "+i+"X"+j);

    int b[][]={{3,4},{1,0}};
      for(i=0;i<2;i++)
      {
        System.out.print("\n");
       for(j=0;j<2;j++)
        {
         System.out.print("  "+b[i][j]);
         System.out.print(" ");
        }
      }
      System.out.print("\n The order of matrix Is: "+i+"X"+j);
   
    int c[][]=new int[i][j];
     for(i=0;i<c.length;i++)
     {
      for(j=0;j<c.length;j++)
       {
        c[i][j]=0;
        for(k=0;k<c.length;k++)
          c[i][j]=c[i][j]+a[i][k]*b[k][j];
       }
     }
   System.out.print("\n The Resultant  matrix Is:");

     for(i=0;i<2;i++)
      {
        System.out.print("\n");
       for(j=0;j<2;j++)
        {
         System.out.print("  "+c[i][j]);
         System.out.print(" ");
        }
      }
      System.out.print("\n The order of matrix Is: "+i+"X"+j);
   }
}
class Progm13
{
 public static void main(String args[])
  {
    Matrix obj=new Matrix();
  }
}
   
