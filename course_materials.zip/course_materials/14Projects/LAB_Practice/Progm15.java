/* 15 create thread of priority 1,3,5,7  and uodate a counter
      in each for 10ms and print the final value  */


class counter implements Runnable
{
 int count=0;

 Thread t;
 private volatile boolean running=true;

  public counter(int p)
  {
   t=new Thread(this);
   t.setPriority(p);
  }
  public void run()
  {
   while(running)
   {
     count++;
   }
  }
  public void stop()
  {
   running=false;
  }
  public void start()
  {
   t.start();
  }
 }
class Progm15
{
 public static void main(String args[])
 {

  Thread.currentThread().setPriority(Thread.MAX_PRIORITY);

   counter P1= new counter(1);
   counter P3= new counter(3);
   counter P5= new counter(5);
   counter P7= new counter(7);


   P1.start();
   P3.start(); 
   P5.start();
   P7.start();

  try
   {
    Thread.sleep(10);
   }
  catch(InterruptedException e)
   {
    System.out.println("Main Thread interrupted ");
   } 

  P1.stop();
  P3.stop(); 
  P5.stop();
  P7.stop();
  
 try
  {
   P1.t.join();
   P3.t.join();
   P5.t.join();
   P7.t.join();  
  }
  catch(InterruptedException e)
  {
   System.out.println("interrupted Eception caught");
  }
  System.out.println("\n  P1 Priority thread  :"+P1.count);
  System.out.println("  P3 Priority thread  :"+P3.count);
  System.out.println("  P5 Priority thread  :"+P5.count);
  System.out.println("  P7 Priority thread  :"+P7.count);  

 }                                                           
}
