/* 1c.Write a programme of Reverse no. */

class Reverse
{
 void reverse(int r)
 {
  int s=0,rem;
   while(r>0)
   {
    rem=r%10;
    r=r/10;
    s=s*10+rem;
   }
  System.out.println("\n The Reverse No.Is :"+s);
 }
}
class Progm1c
{
 public static void main(String args[])
 {
  Reverse obj=new Reverse();
  int n=124;
   System.out.println("\nThe Number Is :"+n);
   obj.reverse(n);
 }
}

