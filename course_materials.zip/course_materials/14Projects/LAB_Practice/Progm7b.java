/* 7b.Write a programme for call by refrence .*/

class Test
{
  int a,b;

  Test(int i,int j)

  {

    a=i;
    b=j;
  }

  void oprate(Test obj)

  {
    obj.a *=2;

    obj.b /=2;

  }
}
class Progm7b
{

  public static void main(String args[])

  {

    Test ob=new Test(15,20);

   System.out.println("\nBfore Call :"+ob.a+" "+ob.b);

    ob.oprate(ob);

   System.out.println("\nAfter Call :"+ob.a+" "+ob.b);

  }

}
