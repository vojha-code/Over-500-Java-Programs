/* 2.Create a class Rectangle(Hight,width).And check whether the 
     value of hight & width are within the range 0.0 to 5.0.
     provide methode to calculate perimeter & area .determine
     whether the rectangle is a square. */



class Ractangle

 {
    float ht,wt;

  Ractangle(float x,float y)

   {
     ht=x;

     wt=y;
   }

   void area()

    {
      float a=ht*wt;

       System.out.println("\n Area Of Ractangle :"+a);
    }
   void perimeter()

    {
      float p=2*(ht+wt);

       System.out.println("\n Perimeter Of Ractangle :"+p);
    }
   boolean checksqr()
 
    {
      if(ht==wt)

        return true;

          return false;
    }
   boolean range()

    {
      if((ht>=0.0&&ht<=5.0)&&(wt>=0.0&&wt<=5.0))

       return true;

         return false;
    }    
  }

class Progm2

{
  public static void main(String args[])

   {
    Ractangle obj=new Ractangle(2.0f,4.0f);

     obj.area();

     obj.perimeter();

     System.out.println("\n It is a Square :"+obj.checksqr());

     System.out.println("\n Within Range :"+obj.range());
    }
}

