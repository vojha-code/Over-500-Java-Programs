/* 11.Create three classes A,B,&C each with the instance variable a.
      B inherit A and C inherit B.Write a methode in class C which
      will add its instance variable and return the result.  */
class A
{
  int a=1;
}
class B extends A
{
 int a=2;
}
class C extends B
{
 int a=3;

  int add()
  {
   B ob=new B();
   A ref=ob;
   return(a+(ob.a)+(ref.a));
  }
}
class Progm11
{
 public static void main(String args[])
 {
  C obj=new C();
  int r;
  r=obj.add();
  System.out.println("\n Addition Is :"+r);
 }
}
