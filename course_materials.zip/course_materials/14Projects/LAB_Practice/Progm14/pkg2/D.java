package pkg2;

import pkg1.*;

class D extends A
{
   void D(D dobj)
   { 
     System.out.println("\n4.  DIFFRENT PACKAGE SUB-CLASS ::>\n");     
  
    System.out.println("\n Imported  Package Public as sub-class:"+dobj.pu);
    System.out.println("\n Imported  Package protected as Sub-class:"+dobj.pro);

   }
}

