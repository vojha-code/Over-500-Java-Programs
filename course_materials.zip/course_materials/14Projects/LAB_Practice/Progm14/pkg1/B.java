package pkg1;
//import pkg1.*;
public class B
{
 
 
  public void pkg1call()
  
  {
    A aobj=new A();    
      aobj.same(aobj);    
    
    A1 a1=new A1();
      a1.call(a1);  
    
    System.out.println("\n3. SAME PACKAGE NON SUB-CLASS ::>\n");         

    System.out.println("\n     Public In same pkg diff Class :"+aobj.pu); 
    System.out.println("     Protected In same pkg diff Class :"+aobj.pro);
    System.out.println("     Defult In same pkg diff Class :"+aobj.d);
   
    
  }


}
 