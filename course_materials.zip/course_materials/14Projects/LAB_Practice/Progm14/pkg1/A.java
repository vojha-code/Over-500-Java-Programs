package pkg1;

public class A

{
   public int pu=0;
   protected int pro=1;
   int d=2;
   private int pri=3;
  
 void same(A aobj)
 { 
    System.out.println("\n1. SAME CLASS ::>\n");
    
    System.out.println("\n     Public In same pkg same Class :"+aobj.pu); 
    System.out.println("     Protected In same pkg same Class :"+aobj.pro);
    System.out.println("     Defult In same pkg same Class :"+aobj.d);
    System.out.println("     Private In same pkg same Class :"+aobj.pri);
 }  
   
}
class A1 extends A
{
  
  void call(A1 a1)  
   { 
      System.out.println("\n2. SAME PACKAGE SUB-CLASS ::>\n");
      
      System.out.println("\n     Public In same pkg sub-Class :"+a1.pu); 
      System.out.println("     Protected In same pkg sub-Class :"+a1.pro);
      System.out.println("     Defult In same pkg sub-Class :"+a1.d);
   }

}

//SET classpath=%Classpath%;.;F:\..\...\.....\Progm14;C:\java\classes
//javac A.java
//java pkg1.A 