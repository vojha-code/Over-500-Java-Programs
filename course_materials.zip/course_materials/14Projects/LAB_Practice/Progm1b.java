/* 1b.Write a programme of Summing odd numbers. */ 

class SumOdd
{
 void sum(int n)
 {
  int i,sum=0;
   for(i=1;i<n;i++)
   {
    if((i&1)==1)
    //if(i%2!=0)
    sum=sum+i;
   }
  System.out.println("\nSum Of Odd Numbers Is :"+sum);
 }
}
class Progm1b
{
 public static void main(String args[])
 {
  SumOdd obj=new SumOdd();
   obj.sum(10);
 }
}
