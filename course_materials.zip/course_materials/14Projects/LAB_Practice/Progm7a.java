/* 7a.Write a programme for call by value. */ 

class TestCBV

{

  void swap(int a,int b)

   {

     a=a+b;
     b=a-b;
     a=a-b;
   System.out.println("\nA & B  after swaping :>"+"A:"+a+"  B:"+b);
   }
}
class Progm7a
{

 public static void main(String args[])
 {

   TestCBV obj=new TestCBV();

    int a=10,b=20;

  System.out.println("\nA & B before swaping :>"+"A:"+a+"  B:"+b);

     obj.swap(a,b);

  

 }

}


