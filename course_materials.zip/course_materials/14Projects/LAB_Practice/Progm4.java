/* 4.Create a programme to implement stack data structure to store
     integer datatype,defining suitable methode(push,pop)and
     a constuctor.  */ 

class Stack
{
 
 Stack()
 {

  System.out.println("\nThe Stack Is Implimented :");
 }

 int a[]=new int [5];

 int top=-1;

 void push(int p)
 {

  top++;

  a[top]=p;

  System.out.println("\nPushed Top :"+a[top]+"  At index :"+top);

 }

 void pop()

 {

   System.out.println("\nPoped Top :"+a[top]+"   From index :"+top);

   top--;

 }
 void array()
 {

  System.out.print("\nArray Contain :");

  for(int i=0;i<top+1;i++)

   System.out.print(" "+a[i]);

   System.out.print("\n");
 }
}
class Progm4

{

 public static void main(String args[])

 {

  Stack obj=new Stack();

  obj.push(2);

  obj.push(3);

  obj.push(4);

  obj.pop();

  obj.array();
  }
}
