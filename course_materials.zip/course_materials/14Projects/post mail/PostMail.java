import java.io.*;
class PostMail
 {
   String companyName;
    int distance;
    int weight;
   void postInfo()
     {
        System.out.println(" \n          Prices for Posting mail (in Rupee)  \n\n");      
        System.out.println("  Distance 100 kms & Weight within 15 gms :            5 Rs./mail ");      
        System.out.println("  Distance  above 100 kms & within 500 kms:            1Rs/mail ");
        System.out.println("  Distance above 500 kms:                              2 Rs/mail  ");
        System.out.println("  Weight betwee 15gms & 50 gms :                       25 paisa/mail  ");
        System.out.println("  Weight above 50 gms                                  50 paisa/mail "); 	
           } 
    void companyName(String companyName)
      {
         this.companyName=companyName;
         System.out.println("\n  Company Name :"+companyName);
      }     
   int getDistance(int distance)
     {
        this.distance=distance;
        return distance;
     }
   int getWeight(int weight)
    {
        this.weight=weight;
         return weight;
    }
   /*int getCost(){}*/
  public static void main(String args[])
  { 
     PostMail pm=new PostMail();
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
       String cn="",ch;  
      System.out.print("\n PASSWORD :"); 
 try{     
     String pass=br.readLine();
      if(pass.equals("postmail"))
       {  
        String str; 
           do
           { 
            int count=0,count1=0,count2=0,count3=0,count4=0,count5=0;
             double cost=0.0;
            boolean q=true;
             do
              {  
               System.out.print("\n      Pres 1-->Mail Price Info , 2-->Post Mail 3-->quit :");          
               switch(Integer.parseInt(br.readLine()))  
                {
                case 1:
                 {
                    pm.postInfo();          
                     break;
                 }
                case  2:
                 {
                    System.out.print("\n  ENTER COMPANY NAME: "); 
                      cn=br.readLine();
                    pm.companyName(cn); 
                    do
                     {
                       System.out.print("\n  Enter The Post Distance : ");
                         int d=Integer.parseInt(br.readLine());
                         pm.getDistance(d);

                       System.out.print("\n  Enter The Post Weight   : ");
                          int w=Integer.parseInt(br.readLine()); 
                          pm.getWeight(w);

                       System.out.print("\n     MAIL POST SUCCSSESFULLY    \n");
                           cost=cost+5;
                           count=count+1;  
                        if(pm.distance<=100&&pm.weight<=15)
                          {
                         count1=count1+1;
                          }
                       if(100<pm.distance&&pm.distance<=500)
                          {
                         count2=count2+1;
                         cost=cost+count2;
                          } 
                       if(pm.distance>500)
                         {
                         count3=count3+1;
                         cost=cost+(count3*2);
                         } 
                       if(15<pm.weight&&pm.weight<=50)
                          {
                         count4=count4+1;
                         cost=cost+(count4*0.25);
                          }  
                        if(pm.weight>50)
                           {
                          count5=count5+1;
                          cost=cost+(count5*0.50);
                           }
                        if(cost>1000)
                         {
                           cost= (cost*20)/100;
                         }   
                       System.out.print(" \n Want to Post more mail :" );
                         ch=br.readLine();
                         }while(ch.equals("y"));
                        
                     break;
                 }
               case 3:
                  q=false;
              }
            }while(q);
           
           pm.companyName(cn);
           System.out.println("\n"); 
           System.out.println("  Mail having distance<=100&weight<=15             :"+count1);
           System.out.println("  Mail having distance >100&distance<=500          :"+count2);
           System.out.println("  Mail having distance>500                         :"+count3);
           System.out.println("  Mail having weight>15&weight<=50                 :"+count4);
           System.out.println("  Mail having weight>50                            :"+count5); 
           System.out.println("\n  Total no of Mail Post                            :"+ count);
           System.out.println("  Total cost to the company                        :"+cost+"\n"); 
           System.out.print("\n\n  Do U WANT TO CONTINUE : ");
           str=br.readLine();      
        }while(str.equals("yes"));
     } 
     else
        System.out.println("\n Try Again \n");
       }catch(IOException e)
       {
       System.out.println(e.getMessage());
       }
     }
  }     
