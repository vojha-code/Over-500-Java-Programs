import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.DriverManager;                  
import java.sql.Connection;                  
import java.sql.Statement;                  
import java.sql.SQLException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;


public class LoginFrame  implements ActionListener{
	
	
	  JFrame logframe;
	 
	  private JTextField textField1;
      private JPasswordField passwordField;
      JButton button1;
      JButton button2;
      public Statement statement;
      Connection connection;
      
	JFrame frame;
	JPanel panel;
	String b1;
    String b2;
    String a1;
    String a2; 
    String b3;
    private JTextField field1;
    private JTextField field2;
    Box vbox1;
    Box hbox1;
   // public JButton enterbutton;
    public JButton cancelbutton;
    public JButton passwardbutton;
    private ButtonGroup group;
    final JDesktopPane desk ;
    
	public LoginFrame()
	
	{
		connectdatabase();
      
			   	
		 JLabel userid = new JLabel("USER ID");
		 field1 = new JTextField(18);
		 field1.setMaximumSize(field1.getPreferredSize());  
		 Box hbox2 = Box.createHorizontalBox();
		 hbox2.add(Box.createHorizontalStrut(6));
		 hbox2.add(userid);
		 hbox2.add(Box.createHorizontalStrut(65));
		 hbox2.add(field1); 
		 
		 JLabel passward = new JLabel("PASSWARD");
		 field2 = new JTextField(18); 
		 field2.setMaximumSize(field2.getPreferredSize());  
		 Box hbox3 = Box.createHorizontalBox();
		 hbox3.add(Box.createHorizontalStrut(5));
		 hbox3.add(passward);
		 hbox3.add(Box.createHorizontalStrut(40));
		 hbox3.add(field2); 
		 
		 
		 passwardbutton  = new JButton("Enter");
		 passwardbutton.addActionListener(this);
		 b3="Enter";
		 passwardbutton.setActionCommand(b3);
		 
		 cancelbutton  = new JButton("CANCEL");
		 cancelbutton.addActionListener(this);
		 b2="CANCEL";
		 cancelbutton.setActionCommand(b2);
		 
		 Box hbox4 = Box.createHorizontalBox();
		
		 hbox4.add(passwardbutton);
		 hbox4.add(Box.createHorizontalStrut(20));
		 hbox4.add(cancelbutton);
		 
		 vbox1 = Box.createVerticalBox();
		 vbox1.add(hbox2);
		 vbox1.add(Box.createVerticalStrut(10));
		 vbox1.add(hbox3);
		 vbox1.add(Box.createVerticalStrut(20));
		 vbox1.add(hbox4);
		 
	     desk = new JDesktopPane();
         
	}    
           
   
	
	public void actionPerformed(ActionEvent e)
	{
	//	String uid = field1.getText();
        //String pwd = field2.getText();
        String logindatetime;

      String txtuid =(textField1.getText());
      String txtpwd=new String (passwordField.getPassword()); 
      String uid=new String();
      String pwd=new String();
      
      boolean ans1=false; 
      boolean ans2=false;   	
         
          if (b2.equals(e.getActionCommand()))
          {
            //System.out.println(pwd);
           System.exit(1)   ;  
            
        } 
        
         
      try
     {
     
    
      ResultSet loginResults = statement.executeQuery("select * from table_user1");
      while (loginResults.next())
      {
        	
          uid=(loginResults.getString(1));     	
     	uid=uid.trim();    
     	pwd=(loginResults.getString(2));
     	pwd=pwd.trim();
   
               
         if (b3.equals(e.getActionCommand()) )
         {
       if ((uid.equals(txtuid))&&(pwd.equals(txtpwd)))  
          
         {
         
         //  JOptionPane.showMessageDialog(desk, "Congratulation You Sucessfully Login");
          int n=JOptionPane.showConfirmDialog(desk, "You Want to Continue?","CONFIRMATION",
                            JOptionPane.YES_NO_OPTION);
         
  
                    if (n == JOptionPane.YES_OPTION) {
     					  SketchKol obj=new  SketchKol(statement,"Welcome To Kolkata");
                         logframe.setVisible(false);

                     break;
                                                  
                    } else if (n == JOptionPane.NO_OPTION) {
                    	
                         //System.out.println("NO");
                         field1.setText("");
                         field2.setText("");
                        break; 
                         
                      }  
                    //  break;  	
        } 
        
        else if((uid.equals(txtuid))&&(pwd.equals("")))
        {
        	
        JOptionPane.showMessageDialog(desk, "Please Enter Passward");
        break;	
        }
        
             else if((uid.equals(""))&&(pwd.equals(txtpwd)))
        {
        	
        	JOptionPane.showMessageDialog(desk, "Please Enter User Id");
        	break;	
        }
         
       else
        {
        JOptionPane.showMessageDialog(desk, "Please Check Passward or UserId");
        break;	
        }
      }
     loginResults.close();                        // Close the result set
    }
    } catch (SQLException ex) {
      System.err.println("\nSQLException-------------------\n");
      System.err.println("SQLState: " + ex.getSQLState());
      System.err.println("Message : " + ex.getMessage());
    }
  
        
      /*	else if( b3.equals (e.getActionCommand()))
      	{
      	
        //JOptionPane.showInternalConfirmDialog(desk, "You want to continue?");
        int n=JOptionPane.showConfirmDialog(desk, "You want to continue?","CONFIRMATION",
                            JOptionPane.YES_NO_OPTION);            
       
                    if (n == JOptionPane.YES_OPTION) {
     					 SketchKol obj=new  SketchKol("Welcome To Kolkata");
                         //System.out.println("YES");
                       // dispose();
                     // frame.setVisible(false); 
                                                  
                    } else if (n == JOptionPane.NO_OPTION) {
                    	
                         System.out.println("NO");
                      } 
        }*/
        
	}
public void showindow()
{
      JFrame.setDefaultLookAndFeelDecorated(true);
	  JFrame frame = new JFrame(); 
      frame.setTitle("Login");
      Toolkit theKit = frame.getToolkit();      
      Dimension wndSize = theKit.getScreenSize();  
      frame.setBounds(wndSize.width/4, wndSize.height/4,   
                      2*wndSize.width/5, wndSize.height/4); 
      
       JPanel panel = new JPanel();
      panel.add(vbox1);
      //desk.add(panel);

      frame.add(panel, BorderLayout.CENTER); 
       
      frame.setVisible(true);
      
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
           	
}		








  public void connectdatabase(){
      	 try {
    
      String url = "jdbc:odbc:tg";
      String driver = "sun.jdbc.odbc.JdbcOdbcDriver";

      Class.forName(driver);
      connection = DriverManager.getConnection(url); 
      statement = connection.createStatement();
          
       } catch (Exception e1) {
        System.err.println(e1);
       }
      }
      
	
/*	public static void main(String[] args)
	{LoginFrame obj1=new LoginFrame();
          obj1.showindow();
		
	}*/
}
