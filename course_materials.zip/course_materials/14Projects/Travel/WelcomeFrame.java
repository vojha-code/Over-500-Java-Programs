import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;

public class WelcomeFrame extends JFrame

{
    private JPanel northPanel;
    private JProgressBar pbar;
    private JLabel welcome;
    private JLabel picture;
    private JLabel text;
    private static final int FONTSIZE = 22;
    static final int	MINIMUM=0;
    static final int	MAXIMUM=13; 
	 
    public WelcomeFrame()
    {
	  
      welcome = new JLabel("Welcome To Kolkata");
      welcome.setFont(new Font("SansSerif", Font.PLAIN, FONTSIZE));
      welcome.setForeground(Color.blue);
      picture = new JLabel();
      text = new JLabel("Please wait Login Window connecting..");  
      pbar = new JProgressBar();
      pbar.setMinimum(MINIMUM);
      pbar.setMaximum(MAXIMUM);
      
     
    }
	
    public void updateBar(int newValue)
    {
      pbar.setValue(newValue);
    }
  
 public void showindow()
 {
      JFrame.setDefaultLookAndFeelDecorated(true);
      JFrame frame = new JFrame(); 
      frame.setTitle("NAMASTE");
      Toolkit theKit = frame.getToolkit();      
      Dimension wndSize = theKit.getScreenSize();  
      frame.setBounds(wndSize.width/4, wndSize.height/4,   
                      2*wndSize.width/5, wndSize.height/2); 
     
      
      JPanel northPanel = new JPanel();
      northPanel.setBackground(Color.pink);
      northPanel.add(welcome);
      frame.add(northPanel, BorderLayout.NORTH);
      
      
      
      JPanel centerPanel = new JPanel();
      centerPanel.setBackground(Color.black);
      centerPanel.add(picture);
      frame.add(centerPanel, BorderLayout.CENTER);
     
      picture.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLoweredBevelBorder(),
                BorderFactory.createEmptyBorder(10,10,10,10)));
      
      JPanel southPanel = new JPanel();
      southPanel.add(text);
      southPanel.add(pbar);
      frame.add(southPanel, BorderLayout.SOUTH);
         
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setVisible(true);
	
     for (int i = MINIMUM; i <= MAXIMUM; i++) 
     {
       final int percent=i;
      try{
      		System.out.print(" "+i);	
       	      updateBar(percent);
       	  	updatePicture(i);
      	java.lang.Thread.sleep(1000);
     }
      catch(InterruptedException e) {;} 
     }
 
     frame.setVisible(false);
     
     /* login obj=new login();
          obj.showwindow();*/

     welcome obj=new welcome();
         	
}	
void updatePicture(int frameNum)
     {
        
        
        if(createImageIcon("images/" + frameNum + ".jpg")!= null)
        {
        	picture.setText("");
        	picture.setIcon(createImageIcon("images/" + frameNum + ".jpg"));
        }
         else { //image not found
            picture.setText("image #" + frameNum + " not found");
        }
        
        
    } 	

   static ImageIcon createImageIcon(String path)
     {
        java.net.URL imgURL = WelcomeFrame.class.getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }	
	
	public static void main(String[] args)
	{
	final WelcomeFrame obj1=new WelcomeFrame();
          obj1.showindow();
          	
	}
   
   
}