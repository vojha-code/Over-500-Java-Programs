import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.Border;
import java.sql.*;     

import java.text.SimpleDateFormat;
import java.util.Date;
             

public class Admin extends JPanel {
	
      static JPanel panel1;
      static JPanel panel2;
      static JPanel panel3;
      static JPanel panel4;
      static JFrame frame;

      
      static Statement statement;
      Connection connection;
      
      ResultsModel model;
      JScrollPane resultsPane;
      
      JTextField ntextField2;
	  JTextField ntextField3;
	  JTextField ntextField4;
	  JTextField ntextField5;
	  JTextField ntextField6;
      JTextField ntextField7;
      	  
	  private JTextField utextField2;
	  private JTextField utextField3;
	  private JTextField utextField4;
	  
      
      String uid=new String();
      String udesig=new String();
      String upossi=new String();
      String uname=new String();
      String uuname=new String();
      String upwd=new String();
      String uconpwd=new String();
      String ulogintm=new String();
      String ulogouttm=new String();
      
      String nid=new String();
      String ndesig=new String();
      String npossi=new String();
      String nname=new String();
      String nadd=new String();
      String nph=new String();
      String nemail=new String();
      String nquali=new String();
      String ndob=new String();
      String nsalary=new String();
      
     
      String nuname=new String();
      String npwd=new String();
      String nconpwd=new String();
      String nlogintm=new String();
      String nlogouttm=new String();
      
      String dateString2;
           
      int nk=0 ;
      JComboBox ncombo ;

      String nelement;
      String[]narray=new String[15];
      
      int uk=0 ;
      JComboBox ucombo ;

      String uelement;
      String[]uarray=new String[15];
      
      private JTextField textField1;
	  private JTextField textField2;
	  private JTextField textField3;
	  private JTextField textField4;
	  private JTextField textField5;
	  private JTextField textField6;
      private JTextField textField7;
	  private JTextField textField8;
	  private JTextField textField9;
      private JTextField textField10;
      
      
      String txtid;
      String txtdesig;
      String txtpossi;
      String txtname;
      String txtadd;
      String txtph;
      String txtemail;
      String txtquali;
      String txtdob;
      String txtsalary;

      
      String id=new String();
      String desig=new String();
      String possi=new String();
      String name=new String();
      String add=new String();
      String ph=new String();
      String email=new String();
      String quali=new String();
      String dob=new String();
      String salary=new String();
	
	
  public Admin(JFrame frame1,Statement statement) {

  	    super(new BorderLayout());
  	    //connectdatabase();
        this.statement=statement;
  	    
        JPanel newuser = NewUser();
        JPanel updateuser = UpdateUser();
      
       JPanel loginhistory = LoginHistory();
      ////// JPanel frequentPanel4 = createSimpleDialogBox2();

        Border padding1 = BorderFactory.createEmptyBorder(100,10,10,10); 
        Border padding2 = BorderFactory.createEmptyBorder(10,10,10,10); 
        newuser.setBorder(padding1);  
        updateuser.setBorder(padding1); 
     
        loginhistory.setBorder(padding2); 
        //frequentPanel4.setBorder(padding1); 


        JTabbedPane tabbedPane = new JTabbedPane(); 
        tabbedPane.addTab("NewUser", null, 
                          newuser,
                          "New");
                          
       tabbedPane.addTab("UpdateUser", null, 
                         updateuser,
                          "Update");   
                          
       
                                                             
       tabbedPane.addTab("LoginHistory", null, 
                          loginhistory,
                          "Loghistory"); 
                                 
                                                
       add(tabbedPane, BorderLayout.CENTER);
    }
    
    
  private JPanel LoginHistory() {
  	
  	  	
  	 //connectdatabase();
      
      JLabel label1 = new JLabel("TO SEE THE LOG IN HISTORY CLICK SHOW BUTTON :-");
      Box hbox1 = Box.createHorizontalBox();
      hbox1.add(label1);
      
      
      model = new ResultsModel();  ///              
      JTable table = new JTable(model);    ///     
      //table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);   
      resultsPane = new JScrollPane(table); 
      
      Box hbox2 = Box.createHorizontalBox();
      hbox2.add(resultsPane);
      //getContentPane().add(resultsPane, BorderLayout.CENTER);
      
      JButton button1 = new JButton("SHOW");
      //button1.addActionListener(this);
      button1.setActionCommand("SHOW");
           button1.addActionListener(new ActionListener() {

          
   public void actionPerformed(ActionEvent e) { 
   
       if ("SHOW".equals(e.getActionCommand())) {
          
   try{
   	 model.setResultSet(statement.executeQuery("select * from log_history")); 

    } catch (SQLException sqle) {

    }
  }
  }
    });
    
      Box hbox3 = Box.createHorizontalBox();
      hbox3.add(button1);
            
      Box vbox1 = Box.createVerticalBox();
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox1);
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox2);
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox3);
            
      JPanel panel1 = new JPanel();
      panel1.add(vbox1);
      return panel1;
    
    }  
             
    
  private JPanel UpdateUser() {
  	     
      JLabel label1 = new JLabel("USER NAME:-");
       ucombo=new JComboBox();
       //combo.addActionListener(this);
       updateusercombofilling();
       
      Box hbox1 = Box.createHorizontalBox();
      //hbox1.add(Box.createHorizontalStrut(5));
      hbox1.add(label1);
      hbox1.add(Box.createHorizontalStrut(137));
      hbox1.add(ucombo);
      hbox1.add(Box.createHorizontalStrut(40));
      
      JLabel label2 = new JLabel("OLD PASSWORD:-");
      utextField2 = new JTextField(18);
      utextField2.setMaximumSize(utextField2.getPreferredSize());
      //textField2.addActionListener(this); 
       
      Box hbox2 = Box.createHorizontalBox();
      hbox2.add(label2);
      hbox2.add(Box.createHorizontalStrut(110));
      hbox2.add(utextField2);
      hbox2.add(Box.createHorizontalStrut(40));
      
      JLabel label3 = new JLabel("NEW PASSWORD:-");
      utextField3 = new JTextField(18);
      utextField3.setMaximumSize(utextField3.getPreferredSize());
      //textField3.addActionListener(this); 
       
      Box hbox3 = Box.createHorizontalBox();
      hbox3.add(label3);
      hbox3.add(Box.createHorizontalStrut(107));
      hbox3.add(utextField3);
      hbox3.add(Box.createHorizontalStrut(40));
      
      JLabel label4 = new JLabel("CONFIRM NEW PASSWORD:-");
      utextField4 = new JTextField(18);
      utextField4.setMaximumSize(utextField4.getPreferredSize());
      //textField4.addActionListener(this); 
       
      Box hbox4 = Box.createHorizontalBox();
      hbox4.add(label4);
      hbox4.add(Box.createHorizontalStrut(54));
      hbox4.add(utextField4);
      hbox4.add(Box.createHorizontalStrut(40));
           
      Box vbox1 = Box.createVerticalBox();
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox1);
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox2);
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox3);
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox4);
           
      JButton button1 = new JButton("UPDATE");
   
      button1.setActionCommand("UPDATE");
      button1.addActionListener(new ActionListener() {

       public void actionPerformed(ActionEvent e) { 
 
    
      String txtconnewpwd= utextField3.getText();
      
        String txtconoldpwd= utextField2.getText();	
       	  try{
       	
            String SQLStatement1 = null;
            
     SQLStatement1="UPDATE newuser SET password='"+ txtconnewpwd +"'"+" WHERE user_name='"+uelement+"' and password='"+ txtconoldpwd+ "'";
   
    
        System.out.println(SQLStatement1);
        statement.executeUpdate(SQLStatement1);
        SQLStatement1=null;
        
       
        
                  
            	       
             
    	    	
    	 } catch (Exception e1) {
        System.err.println(e1);
      }
      
      
      //textField1.setText(null);
      utextField2.setText(null);
      utextField3.setText(null);
      utextField4.setText(null);
     
         }
           });
                  
      JButton button2 = new JButton("  CLEAR ");
//      button2.addActionListener(this);
      button2.setActionCommand("CLEAR"); 
      button2.addActionListener(new ActionListener() {

   public void actionPerformed(ActionEvent e) { 
      utextField2.setText(null);
      utextField3.setText(null);
      utextField4.setText(null);
       }
           });
                  
      
      Box vbox2 = Box.createVerticalBox();
      vbox2.add(Box.createHorizontalStrut(20));
      vbox2.add(button1);
      vbox2.add(Box.createHorizontalStrut(10));
      vbox2.add(button2);
      vbox2.add(Box.createHorizontalStrut(20));
     
      Box hbox5 = Box.createHorizontalBox();
      hbox5.add(vbox1);
      hbox5.add(vbox2);
      
      panel2 = new JPanel();
      panel2.add(hbox5);
      
      return panel2;
    
    }   
    
     public void updateusercombofilling()
     
     {
     		try
     		
     		{
     			
       ResultSet mon2Results = statement.executeQuery("select * from newuser");
      while (mon2Results.next()) {
     	
     	uname=(mon2Results.getString(1));
     	uname=uname.trim()	;   
     	upwd=(mon2Results.getString(2));
     	upwd=upwd.trim()	;
     /*	ulogintm=(mon2Results.getString(3));
     	ulogintm=ulogintm.trim()	;
     	ulogouttm=(mon2Results.getString(4));
     	ulogouttm=ulogouttm.trim()	;*/
     	
      	 uarray[uk]=uname;
      	 uk++;
      	       	
      	} 
      	ucombo = new JComboBox(uarray);
      	
//        ucombo.addActionListener(this);
       ucombo.addActionListener(new ActionListener() {

       public void actionPerformed(ActionEvent e) { 
 
         int index = ucombo.getSelectedIndex();
            uelement =(String)ucombo.getModel().getElementAt(index);
            uelement=uelement.trim();
          

	try{
      
   ResultSet mon2Results = statement.executeQuery("select * from newuser");
      while (mon2Results.next()) {
     
     	uname=(mon2Results.getString(1));
     	uname=uname.trim()	;
     
     /*	uuname=(mon2Results.getString(5));
     	uuname=uuname.trim()*/
     		;
     	upwd=(mon2Results.getString(2));
     	upwd=upwd.trim()	;
     	
     	/*ulogintm=(mon2Results.getString(3));
     	ulogintm=ulogintm.trim()	;
     	ulogouttm=(mon2Results.getString(4));
     	ulogouttm=ulogouttm.trim()	;*/
     
     	
         
             } 
       
         mon2Results.close();          

      //System.exit(0);
      // connection.close();
      	       	 
      		 } catch (Exception e1) {
        System.err.println(e1);
          }
          }
           });
            
      	//mon2Results.close();          

      	 
      		 } catch (Exception e1) {
        System.err.println(e1);
        }
     }    
    
 private JPanel NewUser() {
         
    	  
	  JLabel label5 = new JLabel("USER NAME:-");
      ntextField5 = new JTextField(18);
      ntextField5.setMaximumSize(ntextField5.getPreferredSize());
      //textField5.addActionListener(this); 
       
      Box hbox5 = Box.createHorizontalBox();
      hbox5.add(label5);
      hbox5.add(Box.createHorizontalStrut(82));
      hbox5.add(ntextField5);
      hbox5.add(Box.createHorizontalStrut(40));
    
      JLabel label6 = new JLabel("PASSWORD:-");
      ntextField6 = new JTextField(18);
      ntextField6.setMaximumSize(ntextField6.getPreferredSize());
      //textField6.addActionListener(this); 
       
      Box hbox6 = Box.createHorizontalBox();
      hbox6.add(label6);
      hbox6.add(Box.createHorizontalStrut(80));
      hbox6.add(ntextField6);
      hbox6.add(Box.createHorizontalStrut(40));
      
      JLabel label7 = new JLabel("CONFIRM PASSWORD:-");
      ntextField7 = new JTextField(18);
      ntextField7.setMaximumSize(ntextField7.getPreferredSize());
      //textField7.addActionListener(this); 
       
      Box hbox7 = Box.createHorizontalBox();
      hbox7.add(label7);
      hbox7.add(Box.createHorizontalStrut(26));
      hbox7.add(ntextField7);
      hbox7.add(Box.createHorizontalStrut(43));


      Box vbox1 = Box.createVerticalBox();
    
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox5);
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox6);
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox7); 
      
      JButton button1 = new JButton("  SAVE  ");
      //button1.addActionListener(this);
      button1.setActionCommand("SAVE");
      
      button1.addActionListener(new ActionListener() {

       public void actionPerformed(ActionEvent e) { 
      
      String txtuname= ntextField5.getText();
      String txtpwd= ntextField6.getText();
   String currentPattern1 = "h:mm:ss a";
   Date today1 = new Date();
    
   SimpleDateFormat formatter1 =new SimpleDateFormat(currentPattern1);
            
           String dateString1= formatter1.format(today1);
           System.out.println(dateString1);

        try{
         
       String SQLStatement1 = null;
           

         SQLStatement1="INSERT INTO newuser values("+"'"+ txtuname+"','"+txtpwd +"')";
        
        
     while(SQLStatement1!=null) {
        System.out.println(SQLStatement1);
        statement.executeUpdate(SQLStatement1);
        SQLStatement1=null;
        
        }
        
    
     ResultSet mon2Results = statement.executeQuery("select * from newuser");
      while (mon2Results.next()) {
     	
     	nuname=(mon2Results.getString(1));
     	nuname=nuname.trim()	;
     	npwd=(mon2Results.getString(2));
     	npwd=npwd.trim();
     	     
     /*	nlogintm=(mon2Results.getString(3));
     	nlogintm=nlogintm.trim()	;
     	nlogouttm=(mon2Results.getString(4);
     	nlogouttm=nlogouttm.trim()	;*/
     	    	
    
       	System.out.print(nuname+" ,");
       	System.out.print(npwd+" ,");
       	//System.out.print(nlogintm+" ,");
       //	System.out.println(nlogouttm);

        }
     	
         mon2Results.close();          
       
      
      }catch (Exception e1) {
        System.err.println(e1);
      }
        
      
      ntextField5.setText(null); 
      ntextField6.setText(null);
      ntextField7.setText(null); 
                     
           }
            });
                        
      JButton button2 = new JButton(" CLEAR ");
      //button2.addActionListener(this);
      button2.setActionCommand("CLEAR");
      button2.addActionListener(new ActionListener() {

      public void actionPerformed(ActionEvent e) { 
     
     ntextField5.setText(null); 
      ntextField6.setText(null);
      ntextField7.setText(null);
      }
            });
                 
     
      Box vbox2 = Box.createVerticalBox();
      vbox2.add(Box.createVerticalStrut(25));
      vbox2.add(button1);
      vbox2.add(Box.createVerticalStrut(40));
      vbox2.add(button2);
      vbox2.add(Box.createVerticalStrut(25));
      
      Box hbox8 = Box.createHorizontalBox();
      hbox8.add(vbox1);
      hbox8.add(vbox2);
      
      panel3 = new JPanel();
      panel3.add(hbox8);
      
      return panel3;
    
    }              
    
    public static void showwindow() {
    	
        JFrame.setDefaultLookAndFeelDecorated(true);
        frame = new JFrame("ADMIN");
        //frame.setBounds(200,200,300,200);
        frame.setBounds(150,25,575,560);
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Admin obj=new Admin(frame,statement);
        frame.setContentPane(obj);
        //frame.pack();
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {      
    
        public void windowClosing(WindowEvent e) {
              frame.dispose();  
                
      }
     } );
     
    }

    /*public static void main(String[] args) {
    	 showwindow();
                   
     }*/
}
          

