
import java.awt.*;
import java.awt.event.*;          
import javax.swing.*;   
import java.sql.Statement;    
import java.sql.*;                  
import java.text.SimpleDateFormat;
import java.util.Date;            
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.ButtonGroup;
import javax.swing.KeyStroke;
import static java.awt.event.InputEvent.*;

public class SketchKol extends JFrame {
	 public Statement statement;
  // Constructor
  public SketchKol(final Statement statement,String title) {
  	 //super("Welcome To Kolkata"); 
  	 this.statement=statement;
    setTitle(title); 
    busstatus=false;
    carstatus=false;
   // setBounds(200,200,400,400);    
   setBounds(0, 0, 1100, 800);                         // Set the window title
   // setDefaultCloseOperation(EXIT_ON_CLOSE);
    setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);  
    setJMenuBar(menuBar);                     // Add the menu bar to the window

    JMenu dataMenu = new JMenu("Data");           // Create Data menu
    JMenu spotbookingMenu = new JMenu("Spotbooking");  
    JMenu chargesMenu = new JMenu("Charges");
    JMenu accountsMenu = new JMenu("Accounts");
    JMenu administrationMenu = new JMenu("Admin");
    JMenu helpMenu = new JMenu("Help");  
    JMenu exitMenu = new JMenu("Exit");

    dataMenu.setMnemonic('D');                    // Create shortcut
    spotbookingMenu.setMnemonic('S'); 
   chargesMenu.setMnemonic('C');
    accountsMenu.setMnemonic('A');   
    administrationMenu.setMnemonic('M'); 
    helpMenu .setMnemonic('H');  
    exitMenu.setMnemonic('E');            // Create shortcut

    // Construct the DATA drop-down menu
   entryItem =  dataMenu.add("Customer Data");              // Add entry item

       // Add DATA menu accelerators
     entryItem.setAccelerator(KeyStroke.getKeyStroke('D',CTRL_DOWN_MASK ));
     
     
                  
    entryItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                   if ("Customer Data".equals(e.getActionCommand())) {
                   	
                   //window.setVisible(false); 	
                   
                  biodata  obj=new biodata(statement); 
                    obj.showwindow();
                    }
                }
            });
            
          
                  
   
      JMenu NorthMenu = new JMenu("North");     
      spotbookingMenu.add(NorthMenu);
      JMenu SouthMenu = new JMenu("South");
      spotbookingMenu.add(SouthMenu);
      JMenu EastMenu = new JMenu("East");
      spotbookingMenu.add( EastMenu);
      JMenu WestMenu = new JMenu("West");
      spotbookingMenu.add(WestMenu);
      
      spotbookingMenu.addSeparator(); 
    
      JMenu AllMenu = new JMenu("All");
      spotbookingMenu.add(AllMenu);
      JMenu MixMenu = new JMenu("Mix");
      spotbookingMenu.add( MixMenu);
               
    NorthMenu.add("Bus-ac");
    NorthMenu.add("Bus-non ac");
    NorthMenu.add("Car-ac");
    NorthMenu.add("Car-non ac");
    
    SouthMenu.add("Bus-ac");
    SouthMenu.add("Bus-non ac");
    SouthMenu.add("Car-ac");
    SouthMenu.add("Car-non ac");
    
    EastMenu.add("Bus-ac");
    EastMenu.add("Bus-non ac");
    EastMenu.add("Car-ac");
    EastMenu.add("Car-non ac");
    
    WestMenu.add("Bus-ac");
    WestMenu.add("Bus-non ac");    
    WestMenu.add("Car-ac");
    WestMenu.add("Car-non ac");
   
    
    AllMenu.add("Bus-ac"); 
    AllMenu.add("Bus-non ac"); 
    AllMenu.add("Car-ac"); 
    AllMenu.add("Car-non ac");
    
    MixMenu.add("Bus-ac"); 
    MixMenu.add("Bus-non ac"); 
    MixMenu.add("Car-ac"); 
    MixMenu.add("Car-non ac"); 
 
     
    JMenu MemberMenu = new JMenu("Member");
    chargesMenu.add( MemberMenu);
    JMenu NonMemberMenu = new JMenu("NonMember");
    chargesMenu.add( NonMemberMenu);
    
    MemberMenu.add("Group");
    MemberMenu.add("Individual");
    
    NonMemberMenu.add("Group");
    NonMemberMenu.add("Individual");
    
    JMenuItem exitItem = new JMenuItem("Exit");      
     exitMenu.add(exitItem); 
     exitItem.setActionCommand("Exit") ; 
     exitItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                   if ("Exit".equals(e.getActionCommand())) {
                   	    
                   	   // insertlogoutdatetime();	
                   	    dispose();
                   	    Exit obj=new Exit();
                        
                   	  //  System.exit(1);
                      }
                }
            });
            
      JMenuItem logOutItem = new JMenuItem("Log Out");              
       exitMenu.add(logOutItem);                
      logOutItem.setActionCommand("Log Out") ; 
      
      logOutItem.addActionListener(new ActionListener() {
    	 public void actionPerformed(ActionEvent e) {
                if ("Log Out".equals(e.getActionCommand())) {
  	
                   	int n = JOptionPane.showConfirmDialog(
                            pane, "Do you want to log out from this Project?", 
                            "LOG OUT DIALOG",
                            JOptionPane.YES_NO_OPTION);
  
                    if (n == JOptionPane.YES_OPTION) {
     
                         //insertlogoutdatetime();
                         dispose();
                         //logframe.setVisible(true); 
                         login obj=new login();
                         obj.showwindow();
                        try{
        		String currentPaturn1 ="dd/MM/yy 'at' h:mm:ss a"; 
                Date today1=new Date();
                SimpleDateFormat  formater1 =new SimpleDateFormat(currentPaturn1); 
                String logouttimedate = formater1.format(today1);
   	   String SQLStatement1 = null;
       
      SQLStatement1="UPDATE log_history SET LogOutTime='"+logouttimedate+"'";
   
        if(SQLStatement1!=null) 
        {
        System.out.println(SQLStatement1);
        statement.executeUpdate(SQLStatement1);
        SQLStatement1=null;
        }
      	
   	       }
   	     catch(Exception e1)
 	        	{
 		        System.err.println(e1);	
 		        } 
                           
                    }
                     else if (n == JOptionPane.NO_OPTION) {
                         
                      } 
                    }
                }
            });
            

  
    
 // JMenuItem chgpswdMenuItem  = new JMenuItem("Log Out");              
     //  administrationMenu.add(chgpswdMenuItem);      
     
     
     JMenuItem backupItem = new JMenuItem("Backup");        
    administrationMenu.add(backupItem);                
    backupItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                 if ("Backup".equals(e.getActionCommand())) {
                     JFrame frame=new JFrame(); 	
                     Admin obj=new Admin(frame,statement);
                     // frame.setContentPane(obj);
                     obj.showwindow();
               
                    }
                }
            });
            
            
    JMenuItem noteItem = new JMenuItem("Note");        
    administrationMenu.add(noteItem);                
    noteItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                 if ("Note".equals(e.getActionCommand())) {
                     JFrame frame=new JFrame(); 	
                     StyledEditor2 editor = new StyledEditor2();
                     // frame.setContentPane(obj);
                      editor.setVisible(true);
                     //editor.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                    }
                }
            });
            
       JMenu browserMenu = new JMenu("browser");
    administrationMenu.add(browserMenu);
    
    //browserMenu.add("webpage");
    browserMenu.add("email");     
     JMenuItem webpageItem = new JMenuItem("webpage");        
    browserMenu.add(webpageItem);                
   webpageItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                 if ("webpage".equals(e.getActionCommand())) {
                     
                      
    String url = "";
  
      url = "http://www.yahoo.com/";
   // }
    new MiniBrowser(url).setVisible(true);
 // }

               
                    }
                }
            });
            
       
                
           
           JMenuItem busMenuItem = new JMenuItem("Bus Detail");              
       administrationMenu.add(busMenuItem);       
        
        //busMenuItem = administrationMenu.add("Bus Detail");
     	//busMenuItem.addActionListener(this);
    // busMenuItem.setActionCommand("Bus Detail");
     	
     		busMenuItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
     	
     	     //if("Bus Detail".equals (e.getActionCommand()))
	//{
		if (busstatus==false)
		{
		
	BusDetailFrame BusDetailobj=new BusDetailFrame(statement,"Bus Detail");
    BusDetailobj.showindow();
    busstatus=true;
   	}
   	    // }
		
	   }
	   
	  });
     	
         carMenuItem = administrationMenu.add("Car Detail");
     	// carMenuItem.addActionListener(this);
     //	 carMenuItem.setActionCommand("Car Detail");
     	 
     	  	carMenuItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
     	
     	     if("Car Detail".equals (e.getActionCommand()))
	{
		BusDetailFrame BusDetailobj;
		
		if (carstatus==false)
		{
		
	 BusDetailobj=new BusDetailFrame(statement,"Car Detail");
        BusDetailobj.showindow();
    	carstatus=true;
   	}
   	     }
		
	   }
	   
	  });
	  
	  
	   
      JMenuItem aboutItem = new JMenuItem("About"); 
    
        helpMenu.add(aboutItem);               
        aboutItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                   if ("About".equals(e.getActionCommand())) {
                   
                       About obj=new About ();
                       obj.showwindow();
              
                    }
                }
            });
                 
      
            
          
         
   
    menuBar.add(dataMenu);
    
    menuBar.add(spotbookingMenu);
    
    menuBar.add(chargesMenu);
    
    menuBar.add(accountsMenu);
    
    menuBar.add(administrationMenu);
    
    menuBar.add(helpMenu);
     
    menuBar.add(exitMenu);  
    
    
	 setVisible(true);  
    
    }
    
     private JMenuBar menuBar = new JMenuBar();  

  // File menu items
  private JMenuItem entryItem, chgpswdMenuItem, carMenuItem ;      
                    
 Boolean busstatus;
 Boolean carstatus;

//JFrame logframe;
  JOptionPane pane;	
}