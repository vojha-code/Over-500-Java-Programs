import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class chgpwd  implements ActionListener{

	JFrame frame;
	JPanel panel;
	String b1;
    String b2;
    String a1;
    String a2; 
    String b3;
    private JTextField field1;
    private JTextField field2;
    Box vbox1;
    Box hbox1;
   // public JButton enterbutton;
    public JButton cancelbutton;
    public JButton passwardbutton;
    private ButtonGroup group;
    final JDesktopPane desk ;
    
	public chgpwd()
	
	{
			   	
		 JLabel userid = new JLabel("USER ID");
		 field1 = new JTextField(18);
		 field1.setMaximumSize(field1.getPreferredSize());  
		 Box hbox2 = Box.createHorizontalBox();
		 hbox2.add(Box.createHorizontalStrut(6));
		 hbox2.add(userid);
		 hbox2.add(Box.createHorizontalStrut(65));
		 hbox2.add(field1); 
		 
		 JLabel passward = new JLabel("PASSWARD");
		 field2 = new JTextField(18); 
		 field2.setMaximumSize(field2.getPreferredSize());  
		 Box hbox3 = Box.createHorizontalBox();
		 hbox3.add(Box.createHorizontalStrut(5));
		 hbox3.add(passward);
		 hbox3.add(Box.createHorizontalStrut(40));
		 hbox3.add(field2); 
		 
		 
		 passwardbutton  = new JButton("CHANGE PASSWARD");
		 passwardbutton.addActionListener(this);
		 b3="CHANGE PASSWARD";
		 passwardbutton.setActionCommand(b3);
		 
		 cancelbutton  = new JButton("CANCEL");
		 cancelbutton.addActionListener(this);
		 b2="CANCEL";
		 cancelbutton.setActionCommand(b2);
		 
		 Box hbox4 = Box.createHorizontalBox();
		
		 hbox4.add(passwardbutton);
		 hbox4.add(Box.createHorizontalStrut(20));
		 hbox4.add(cancelbutton);
		 
		 vbox1 = Box.createVerticalBox();
		 vbox1.add(hbox2);
		 vbox1.add(Box.createVerticalStrut(10));
		 vbox1.add(hbox3);
		 vbox1.add(Box.createVerticalStrut(20));
		 vbox1.add(hbox4);
		 
	     desk = new JDesktopPane();
         
	}    
           
   
	
	public void actionPerformed(ActionEvent e)
	{
		String uid = field1.getText();
        String pwd = field2.getText();
         
          if (b2.equals(e.getActionCommand())){
            System.out.println(pwd);
            
        } 
        
      	else if( b3.equals (e.getActionCommand()))
      	{
      	
        //JOptionPane.showInternalConfirmDialog(desk, "You want to continue?");
        int n=JOptionPane.showConfirmDialog(desk, "You want to continue?","CONFIRMATION",
                            JOptionPane.YES_NO_OPTION);            
       
                    /*if (n == JOptionPane.YES_OPTION) {
     					 SketchKol obj=new  SketchKol("Welcome To Kolkata");
                         //System.out.println("YES");
                       // dispose();
                     // frame.setVisible(false); 
                                                  
                    } else if (n == JOptionPane.NO_OPTION) {
                    	
                         System.out.println("NO");
                      }*/ 
        }
        
	}
public void showindow()
{
      JFrame.setDefaultLookAndFeelDecorated(true);
	  JFrame frame = new JFrame(); 
      frame.setTitle("Login");
      Toolkit theKit = frame.getToolkit();      
      Dimension wndSize = theKit.getScreenSize();  
      frame.setBounds(wndSize.width/4, wndSize.height/4,   
                      2*wndSize.width/5, wndSize.height/4); 
      
       JPanel panel = new JPanel();
      panel.add(vbox1);
      //desk.add(panel);

      frame.add(panel, BorderLayout.CENTER); 
       
      frame.setVisible(true);
      
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
           	
}		
	
/*	public static void main(String[] args)
	{
	chgpwd obj1=new chgpwd();
          obj1.showindow();
	}*/
}
