import java.awt.*;
import javax.swing.*;
import java.awt.event.*;



public class About
                   implements ActionListener
                              
{
	  JFrame frame;
	  Box vbox1;
	  JButton button1;
    
 public About(){
      
      JLabel label1 = new JLabel("DEVELOPED BY:-");
      JLabel label2 = new JLabel("TANIA GHOSH");
      JLabel label3 = new JLabel("Ph		: 9433337938�");
      JLabel label4 = new JLabel("E_mail	: ghoshtania@yahoo.com");
      
      Box hbox1 = Box.createHorizontalBox();
      hbox1.add(label1);
      hbox1.add(Box.createHorizontalStrut(140));
      hbox1.add(label2);
      hbox1.add(Box.createHorizontalStrut(120));
      
      Box hbox2 = Box.createHorizontalBox();
      hbox2.add(Box.createHorizontalStrut(140));
      hbox2.add(label3);
      
      Box hbox3 = Box.createHorizontalBox();
      hbox3.add(Box.createHorizontalStrut(225));
      hbox3.add(label4);

      
      JLabel label5 = new JLabel("UNDER THE GUIDANCE OF:-");
      JLabel label6 = new JLabel("Mr.Sanjit Kumar Sinha");
      JLabel label7 = new JLabel("Ph		: 9831488009");
      JLabel label8 = new JLabel("E_mail	: sanjit_kumar_sinha@email.com");

      label1.setForeground(Color.red);
      label2.setForeground(Color.gray);
      label3.setForeground(Color.gray);
      label4.setForeground(Color.blue);
      
      label5.setForeground(Color.red);
      label6.setForeground(Color.gray);
      label7.setForeground(Color.gray);
      label8.setForeground(Color.blue);


      Box hbox4 = Box.createHorizontalBox();
      hbox4.add(label5);
      hbox4.add(Box.createHorizontalStrut(85));
      hbox4.add( label6);
      hbox4.add(Box.createHorizontalStrut(70));

      
      Box hbox5 = Box.createHorizontalBox();
      hbox5.add(Box.createHorizontalStrut(130));
      hbox5.add(label7);
      
      Box hbox6 = Box.createHorizontalBox();
      hbox6.add(Box.createHorizontalStrut(270));
      hbox6.add(label8);	
                        
      JButton button1 = new JButton("OK");
      button1.addActionListener(this);
      button1.setActionCommand("OK");
      
      button1.setForeground(Color.red);
      button1.setFont(new Font("SansSerif", Font.BOLD, 15));

      
      Box hbox7 = Box.createHorizontalBox();
      hbox7.add(button1);
    
    
      vbox1 = Box.createVerticalBox();
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox1);
      vbox1.add(hbox2);
      vbox1.add(hbox3);
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox4);
      vbox1.add(hbox5);
      vbox1.add(hbox6);
      vbox1.add(Box.createVerticalStrut(30));
      vbox1.add(hbox7);
        
     }
     
    public void actionPerformed(ActionEvent e) { 
  
       if ("OK".equals(e.getActionCommand())) {
       	
          frame.dispose();
          }
       }
          
          
     public void showwindow(){
      	
      JFrame.setDefaultLookAndFeelDecorated(true);
	  frame = new JFrame(); 
      frame.setTitle("SOFTWARE DEVELOPING");
      Toolkit theKit = frame.getToolkit();      
      Dimension wndSize = theKit.getScreenSize();  
      frame.setBounds(wndSize.width/5, wndSize.height/4,   
                      2*wndSize.width/3, 7*wndSize.height/18); 
      
      JPanel panel = new JPanel();
      panel.add(vbox1);
      //label0.setForeground(Color.blue);
      panel.setBackground(Color.white);
      frame.add(panel, BorderLayout.CENTER);  
      frame.setVisible(true);
      
      frame.addWindowListener(new WindowAdapter() {      
    
            public void windowClosing(WindowEvent e) {
              frame.dispose();  
                
      }
     } );
     
           //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

     
    }
        public static void main(String[] args)
       {  
          About obj=new About();
          obj.showwindow();
         
       }
 }

      