import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JMenuBar;
import javax.swing.JMenu;

import java.sql.DriverManager;                  
import java.sql.Connection;                  
import java.sql.Statement;                  
import java.sql.SQLException;
import java.sql.ResultSet;


import javax.swing.border.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class biodata extends JFrame implements ActionListener
                              
{     
	  JFrame frame;
	  Box vbox1;
	  Box hbox11;
	  private JTextField textField1;
	  private JTextField textField2;
	  private JTextField textField3;
	  private JTextField textField4;
	  private JTextField textField5;
	  private JTextField textField6;
      private JTextField textField7;
	  private JTextField textField8;
	  private JTextField textField9;
      private JTextField textField10;
      
   public JButton button1,button2,button3,button4,button5;
   
   public Statement statement;
      Connection connection;
      final JDesktopPane desk ;
      
      private ButtonGroup group;
            
     JComboBox adCombo;
     JComboBox namCombo;
     JRadioButton radionew;
    JRadioButton radiosearch;
     
     String a1;
     String a2; 
    
      String txtid;
      String txtprofe;
      String txtgen;
      String txtname;
      String txtadd;
      String txtph;
      String txtemail;
      String txtquali;
      String txtdob;
      String txtnation;

      String id=new String();
      String profe=new String();
      String gen=new String();
      String name=new String();
      String ad=new String();
      String ph=new String();
      String email=new String();
      String quali=new String();
      String dob=new String();
      String nation=new String();
        
    public biodata ( Statement statement)
 {
 	this.statement=statement;
 	  //connectdatabase();
 	 group = new ButtonGroup();
	 hbox11 = Box.createHorizontalBox();
		 hbox11.add(Box.createHorizontalStrut(30));

      JLabel label1 = new JLabel("USER ID -");
      textField1 = new JTextField(18);
      textField1.setMaximumSize(textField1.getPreferredSize());
      //textField1.addActionListener(this); 
       
      Box hbox1 = Box.createHorizontalBox();
      hbox1.add(Box.createHorizontalStrut(10));
      hbox1.add(label1);
      hbox1.add(Box.createHorizontalStrut(200));
      hbox1.add(textField1);

      JLabel label10 = new JLabel("PROFESSION -");
      textField10 = new JTextField(18);
      textField10.setMaximumSize(textField10.getPreferredSize());
      //textField10.addActionListener(this); 
       
      Box hbox12 = Box.createHorizontalBox();
      hbox12.add(Box.createHorizontalStrut(10));
      hbox12.add(label10);
      hbox12.add(Box.createHorizontalStrut(170));
      hbox12.add(textField10);
      
      JLabel label2 = new JLabel("GENDER  -");

      textField2 = new JTextField(18);		
      textField2.setMaximumSize(textField2.getPreferredSize()); 
      //textField2.addActionListener(this);   
            
      Box hbox2 = Box.createHorizontalBox();
      hbox2.add(Box.createHorizontalStrut(10));
      hbox2.add(label2);
      hbox2.add(Box.createHorizontalStrut(196));
      hbox2.add(textField2);	
      
      JLabel label3 = new JLabel("NAME -");
      textField3 = new JTextField(18);
      textField3.setMaximumSize(textField3.getPreferredSize());
      //textField3.addActionListener(this); 
       textField3.setVisible(true);
      Box hbox3 = Box.createHorizontalBox();
      hbox3.add(Box.createHorizontalStrut(10));
      hbox3.add(label3);
      hbox3.add(Box.createHorizontalStrut(214));
      hbox3.add(textField3);
            	 
		 namCombo = new JComboBox();
		 //namCombo.setMaximumSize(namCombo.getPreferredSize());
		 namCombo.setEditable(false);
	     namCombo.setVisible(false);
		 hbox3.add(namCombo); 
      
      JLabel label4 = new JLabel("ADDRESS -");
      textField4 = new JTextField(18);
      textField4.setMaximumSize(textField4.getPreferredSize());
      //textField4.addActionListener(this); 
       textField4.setVisible(true);
      Box hbox4 = Box.createHorizontalBox();
      hbox4.add(Box.createHorizontalStrut(10));
      hbox4.add(label4);
      hbox4.add(Box.createHorizontalStrut(192));
      hbox4.add(textField4);
      
		 adCombo = new JComboBox();
		 adCombo.setEditable(false);		 
	     adCombo.setVisible(false);
		 hbox4.add(adCombo); 
	
      JLabel label5 = new JLabel("PHONE -");
      textField5 = new JTextField(18);
      textField5.setMaximumSize(textField5.getPreferredSize());
      //textField5.addActionListener(this); 
       
      Box hbox5 = Box.createHorizontalBox();
      hbox5.add(Box.createHorizontalStrut(10));
      hbox5.add(label5);
      hbox5.add(Box.createHorizontalStrut(205));
      hbox5.add(textField5);
      
      JLabel label6 = new JLabel("E-MAIL -");
      textField6 = new JTextField(18);
      textField6.setMaximumSize(textField6.getPreferredSize());
      //textField6.addActionListener(this); 
       
      Box hbox6 = Box.createHorizontalBox();
      hbox6.add(Box.createHorizontalStrut(10));
      hbox6.add(label6);
      hbox6.add(Box.createHorizontalStrut(205));
      hbox6.add(textField6); 
      
      JLabel label7 = new JLabel("QUALIFICATION -");
      textField7 = new JTextField(18);
      textField7.setMaximumSize(textField7.getPreferredSize());
      //textField7.addActionListener(this); 
       
      Box hbox7 = Box.createHorizontalBox();
      hbox7.add(Box.createHorizontalStrut(10));
      hbox7.add(label7);
      hbox7.add(Box.createHorizontalStrut(158));
      hbox7.add(textField7); 
      
      JLabel label8 = new JLabel("DATE OF BIRTH -");
      textField8 = new JTextField(18);
      textField8.setMaximumSize(textField8.getPreferredSize());
      //textField8.addActionListener(this); 
       
      Box hbox8 = Box.createHorizontalBox();
      hbox8.add(Box.createHorizontalStrut(10));
      hbox8.add(label8);
      hbox8.add(Box.createHorizontalStrut(159));
      hbox8.add(textField8); 
      
      JLabel label9 = new JLabel("NATIONALITY -");
      textField9 = new JTextField(18);
      textField9.setMaximumSize(textField9.getPreferredSize());
      //textField9.addActionListener(this); 
       
      Box hbox9 = Box.createHorizontalBox();
      hbox9.add(Box.createHorizontalStrut(10));
      hbox9.add(label9);
      hbox9.add(Box.createHorizontalStrut(170));
      hbox9.add(textField9); 
                       
      button1 = new JButton(" ENTRY ");
      button1.addActionListener(this);
      button1.setActionCommand(" ENTRY ");
      
      button2 = new JButton("UPDATE");
      button2.addActionListener(this);
      button2.setActionCommand("UPDATE");
      button2.setEnabled(false);
      button3 = new JButton("SEARCH");
      button3.addActionListener(this);
      button3.setActionCommand("SEARCH");
      button3.setEnabled(false); 
      button4 = new JButton(" CLEAR ");
      button4.addActionListener(this);
      button4.setActionCommand("CLEAR"); 
      
      button5 = new JButton(" EXIT ");
      button5.addActionListener(this);
      button5.setActionCommand("EXIT"); 
      
      Box hbox10 = Box.createHorizontalBox();
      hbox10.add(button1);
      hbox10.add(Box.createHorizontalStrut(30));
      hbox10.add(button2);
      hbox10.add(Box.createHorizontalStrut(30));
      hbox10.add(button3);
      hbox10.add(Box.createHorizontalStrut(30));
      hbox10.add(button4);
      hbox10.add(Box.createHorizontalStrut(30));
      hbox10.add(button5);
     addRadiobutton1("New");
	    
		 hbox11.add(Box.createHorizontalStrut(20));
	   	 addRadiobutton1("Search"); 
	   
      vbox1 = Box.createVerticalBox();
      vbox1.add(Box.createVerticalStrut(10));
      vbox1.add(hbox11);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox1);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox12);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox2);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox3);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox4);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox5);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox6);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox7);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox8);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox9);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox10);
     desk = new JDesktopPane();

     }
     
     public void addRadiobutton1(String name)
	{
	JRadioButton button = new JRadioButton(name);
	button.setSelected(true);
	group.add(button);
	hbox11.add(button);
	
	 button.setActionCommand(name);
	 a1="New";
     a2="Search";
    button.addActionListener(new
         ActionListener()
         {
         	
            public void actionPerformed(ActionEvent e)
            {  
               System.out.println("here");
               if( a1.equals(e.getActionCommand()))
               {               	
               	System.out.println("for new");
               	button1.setEnabled(true);
               	button4.setEnabled(true);
               	button5.setEnabled(true);
               	button2.setEnabled(false);
               	button3.setEnabled(false);
               	
   	            namCombo.setVisible(false);
   	           textField3.setVisible(true);
             	textField4.setVisible(true);
             	adCombo.setVisible(false);
             
               }
               
              else if( a2.equals(e.getActionCommand()))
               {
               	System.out.println("for search");
              button1.setEnabled(false);
               	button4.setEnabled(false);
               	button5.setEnabled(true);
               	button2.setEnabled(true);
               	button3.setEnabled(true);
               	
               	adCombo.setVisible(true);
   	            namCombo.setVisible(true);
   	           textField3.setVisible(false);
             	textField4.setVisible(false);
               	
        try{
     		
             ResultSet mon2Results = statement.executeQuery("select name,ad from tbl_customer_details ");
     
          // namCombo.removeAllItems();
           //adCombo.removeAllItems();
           
      while (mon2Results.next()) {
     	      
      namCombo.addItem(mon2Results.getString(1));
      adCombo.addItem(mon2Results.getString(2));
      
          } 
 	       
       mon2Results.close();          
      } catch (Exception e1) {
        System.err.println(e1);
      }
               }
               
            }
         });
	}
      
 public void actionPerformed(ActionEvent e) { 
    
      txtid= textField1.getText();
      txtprofe=textField10.getText();
      txtgen= textField2.getText();
      txtname= textField3.getText();
      txtadd= textField4.getText();
      txtph= textField5.getText();
      txtemail= textField6.getText();
      txtquali= textField7.getText();
      txtdob= textField8.getText();
      txtnation= textField9.getText();

                
      if (" ENTRY ".equals(e.getActionCommand())) {
          
   try{
       String SQLStatement1 = null;
           
        SQLStatement1="INSERT INTO tbl_customer_details values ("+"'"+ txtid+"'" +",'"+txtprofe+"','"+txtgen+"'"+",'"+txtname+"'"+",'"+txtadd+"'"+",'"+txtph+"','"+txtemail+"','"+txtquali+"','"+txtdob+"','"+txtnation+"')";
        
     while(SQLStatement1!=null) {
        System.out.println(SQLStatement1);
        statement.executeUpdate(SQLStatement1);
        SQLStatement1=null;
        JOptionPane.showMessageDialog(desk, "Congratulation You Sucessfully Entry");
        
        }
      }
      catch (Exception e1) {
        System.err.println(e1);
      }
     
      textField1.setText(null);
      textField10.setText(null); 
      textField2.setText(null);
      textField3.setText(null);
      textField4.setText(null);
      textField5.setText(null);
      textField6.setText(null); 
      textField7.setText(null); 
      textField8.setText(null); 
      textField9.setText(null); 

      }
      
  else if("SEARCH".equals(e.getActionCommand())){ 
  
  boolean flag=false;
    try{
  		name=(String)namCombo.getSelectedItem();
     	name=name.trim();
     	ad=(String)adCombo.getSelectedItem();
     	ad=ad.trim();
     	String s="select * from tbl_customer_details where name='"+ name+"' and ad='"+ad+"'";
     
     ResultSet mon2Results = statement.executeQuery(s);
      while (mon2Results.next()) {
      		flag=true;
     	id=(mon2Results.getString(1));
     	id=id.trim();
     	
     	profe=(mon2Results.getString(2));
     	profe=profe.trim();
     
     	gen=(mon2Results.getString(3));
     	gen=gen.trim()	;
     	name=(mon2Results.getString(4));
     	name=name.trim()	;
     	ad=(mon2Results.getString(5));
     	ad=ad.trim()	;
     	ph=(mon2Results.getString(6));
     	ph=ph.trim()	;
     	email=(mon2Results.getString(7));
     	email=email.trim()	;
     	quali=(mon2Results.getString(8));
     	quali=quali.trim()	;
     	dob=(mon2Results.getString(9));
     	dob=dob.trim()	;
     	nation=(mon2Results.getString(10));
     	nation=nation.trim()	;
     	        	
        
      textField1.setText(id);
      textField10.setText(profe);
      textField2.setText(gen);
      textField3.setText(name);
      textField4.setText(ad);
      textField5.setText(ph);
      textField6.setText(email); 
      textField7.setText(quali); 
      textField8.setText(dob); 
      textField9.setText(nation); 
       break;               
          
       } 
        	if (flag==false){
        JOptionPane.showMessageDialog(desk,"Address Of Customer is Wrong","ERROR MESSAGE",JOptionPane.ERROR_MESSAGE);
       // button2.setEnabled(false);
        
        }
        
       mon2Results.close();          
      } catch (Exception e1) {
        System.err.println(e1);
      }
      
        }  
        
   else if("UPDATE".equals(e.getActionCommand())){ 
    try{ 	
        
          	
            String SQLStatement1 = null;
           
        SQLStatement1="UPDATE tbl_customer_details SET id="+"'"+ txtid +"',pro='"+txtprofe+"',"+"gen='"+txtgen+"'"+",name='"+txtname+"'"+",ad='"+txtadd+"'"+",ph='"+txtph+"',email='"+txtemail+"',"+"quali='"+txtquali+"',"+"dob='"+txtdob+"',"+"nationality='"+txtnation+"' WHERE id='"+txtid+"'";
   
        System.out.println(SQLStatement1);
        statement.executeUpdate(SQLStatement1);
        SQLStatement1=null;
        JOptionPane.showMessageDialog(desk, "Congratulation You Sucessfully Update");
        
    	 } 
    	 
    	 catch (Exception e1) {
        System.err.println(e1);
      }
      
      textField1.setText(null);
      textField10.setText(null);
      textField2.setText(null);
      textField3.setText(null);
      textField4.setText(null);
      textField5.setText(null);
      textField6.setText(null);
      textField7.setText(null);
      textField8.setText(null);
      textField9.setText(null);
      
     // button2.setEnabled(false);
     // button3.setEnabled(true);
        }  
            
   else if("CLEAR".equals(e.getActionCommand())) {
   	
   	  textField1.setText(null);
   	  textField10.setText(null);
      textField2.setText(null);
      textField3.setText(null);
      textField4.setText(null);
      textField5.setText(null);
      textField6.setText(null);
      textField7.setText(null);
      textField8.setText(null);
      textField9.setText(null);
      textField1.requestFocusInWindow();    
      }
      
      else if("EXIT".equals(e.getActionCommand())){ 
      
      //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       System.exit(1);
        // frame.dispose();      
      } 
  }
  
   public void showwindow(){
      	
      JFrame.setDefaultLookAndFeelDecorated(true);
	  frame = new JFrame(); 
      frame.setTitle(" Customer Register");
      Toolkit theKit = frame.getToolkit();      
      Dimension wndSize = theKit.getScreenSize();  
     frame.setBounds(wndSize.width/4, wndSize.height/4,   
                      2*wndSize.width/3, wndSize.height/2); 
       
      JPanel panel = new JPanel();
      panel.setBackground(Color.gray);
      panel.add(vbox1);

      frame.add(panel, BorderLayout.CENTER);

      frame.pack();  
      frame.setVisible(true);     
        //frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);             
      }
    
    /* public static void main(String[] args)
       {  
         biodata obj=new biodata(); 
         obj.showwindow();
         
       }*/  
 }
 
 
