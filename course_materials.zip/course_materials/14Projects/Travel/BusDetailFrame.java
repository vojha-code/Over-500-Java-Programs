import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.JTextField;
import javax.swing.JComboBox;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


public class BusDetailFrame  extends JFrame implements ActionListener{
	String str;
	 String buscart ;
     String ownert ;
     String phonet ;
     String seatt ;
	JFrame frame;
    String Exitvari;
    String Savevari;
    String Updatevari;
    JComboBox cb;
    JComboBox typeCombo;
    String busi;
    String typei;
    String cari;
     public String[] busStrings=new String[3];
     public String[] carStrings=new String[4];
    public String[] typeStrings=new String[3];
   public Statement statement; 
   public JTextField fieldbuscar;
   public JLabel labelbus;
   
     JTextField fieldowner;
    JTextField fieldphone;
    JTextField fieldseat;
    
    Box vbox1;
    Box vbox2;
    Box vbox3;
    Box hbox1;
    Boolean ans;
    public JButton savebutton;
    public JButton searchbutton;
    public JButton updatebutton;
    public JButton clearbutton;
    public JButton exitbutton;
   final JDesktopPane desk ;
  
    JComboBox busCombo;
  JComboBox carCombo;
	public BusDetailFrame( Statement statement,String grouptype)
	{
	    this.statement=statement;
	     	     
	     labelbus = new JLabel("Bus No");
	     JLabel Labelcar = new JLabel("Car No");
	     JLabel Labelowner = new JLabel("Ownwer");
	     JLabel Labelphone = new JLabel("Phone No.");
	     JLabel Labelseat = new JLabel("Seat");
	     JLabel Labeltype = new JLabel("Type");
	     JLabel Labelgroup = new JLabel("Group");
	     vbox1 = Box.createVerticalBox();
		 vbox1.add(Box.createVerticalStrut(12)); 
	     	     	    
		 fieldbuscar = new JTextField(18);
		 fieldbuscar.setMaximumSize(fieldbuscar.getPreferredSize());
		 JComboBox noCombo = new JComboBox();
		 noCombo.setVisible(false);
		 fieldowner = new JTextField(18);
		 fieldowner.setMaximumSize(fieldowner.getPreferredSize());
		 fieldphone = new JTextField(18); 
		 fieldphone.setMaximumSize(fieldphone.getPreferredSize());  
		 fieldseat = new JTextField(18); 
		 fieldseat.setMaximumSize(fieldseat.getPreferredSize());  
		 
		typeStrings[1]="Ac";
		typeStrings[0]=" ";
		typeStrings[2]="NonAc";
	
		  typeCombo = new JComboBox(typeStrings);
		 typeCombo.setEditable(false);
	   
	     typeCombo.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent ie){
        typei = (String)typeCombo.getSelectedItem();
       }
       });
	    
		 vbox2 = Box.createVerticalBox();
		 vbox2.add(Box.createVerticalStrut(10));
		 vbox2.add(fieldbuscar);
		 vbox2.add(noCombo);
		 vbox2.add(Box.createVerticalStrut(10));
		 vbox2.add(fieldowner);
		 vbox2.add(Box.createVerticalStrut(10));
		 vbox2.add(fieldphone);
		 vbox2.add(Box.createVerticalStrut(10));
		 vbox2.add(fieldseat);
		 vbox2.add(Box.createVerticalStrut(10));
		 vbox2.add(typeCombo);
		 vbox2.add(Box.createVerticalStrut(10));
		 if(grouptype.equals("Bus Detail"))
		 {

		 busStrings[0]=" ";
		 busStrings[1]="Delux";
		 busStrings[2]="General";
		 busCombo = new JComboBox(busStrings);
		 busCombo.setEditable(false);
		 
				 ans=true;
		
	busCombo.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent ie){
        busi = (String)busCombo.getSelectedItem();
       }
       });

		 vbox1.add( labelbus);
		 vbox2.add(busCombo);
	     }
		 else
		 {
		  carStrings[0]=" ";
		  carStrings[1]="Sumo";
		  carStrings[2]="Ambasader";
		  carStrings[3]="Van";
		 carCombo = new JComboBox(carStrings);
			carCombo.addItemListener(new ItemListener(){
      		public void itemStateChanged(ItemEvent ie){
        	cari = (String)carCombo.getSelectedItem();
       }
       }
       );
         vbox1.add(Labelcar);
		 vbox2.add(carCombo);
		 ans=false;
	     }
	     vbox1.add(Box.createVerticalStrut(15));
	     vbox1.add(Labelowner);
	     vbox1.add(Box.createVerticalStrut(15));
	     vbox1.add(Labelphone);
	     vbox1.add(Box.createVerticalStrut(15));
	     vbox1.add(Labelseat);
	     vbox1.add(Box.createVerticalStrut(17));
	     vbox1.add(Labeltype);
	     vbox1.add(Box.createVerticalStrut(17));
	     vbox1.add(Labelgroup);	 
	
		 savebutton  = new JButton("SAVE  ");
		
	    savebutton.addActionListener(this);
	     savebutton.setActionCommand("SAVE  ");
	    
	    searchbutton  = new JButton("SEARCH");
		 updatebutton  = new JButton("UPDATE");
		
		clearbutton  = new JButton("CLEAR  ");
	    
		 exitbutton  = new JButton("Exit  ");
         exitbutton.addActionListener(this);
	     exitbutton.setActionCommand("Exit  ");
		 
		 vbox3 = Box.createVerticalBox();
		 vbox3.add(Box.createVerticalStrut(10));
		 vbox3.add(savebutton);
		 vbox3.add(Box.createVerticalStrut(10));
		 vbox3.add(searchbutton);
		 vbox3.add(Box.createVerticalStrut(10));
		 vbox3.add(updatebutton);
		 vbox3.add(Box.createVerticalStrut(10));
		 vbox3.add(clearbutton);
		 vbox3.add(Box.createVerticalStrut(10));
		 vbox3.add(exitbutton);
	
		 hbox1 = Box.createHorizontalBox();
		 hbox1.add(vbox1);
		 hbox1.add(Box.createHorizontalStrut(10));
		 hbox1.add(vbox2);
		 hbox1.add(Box.createHorizontalStrut(10));
		 hbox1.add(vbox3);
		 desk = new JDesktopPane();   
		 
	}

 public void actionPerformed(ActionEvent e)
 {
 	
buscart = fieldbuscar.getText();
   ownert = fieldowner.getText();
    phonet = fieldphone.getText();
     seatt = fieldseat.getText();
	 
    System.out.println("data="+busi+" "+cari+" "+typei );  
 
 if( "SAVE  ".equals (e.getActionCommand()))
 	{
 	
 		if((buscart.equals(""))&&(ownert.equals(""))&&(phonet.equals(""))&&(seatt.equals("")))
 		{
 			JOptionPane.showMessageDialog(desk, "Write in textfield");
 		    
 		}
 		else
 		{
 			
 		try
 		{
 			 String SQLStatement1 = null;
       if(ans==true)
       {
      
      SQLStatement1="INSERT INTO Buscardetails VALUES('BUS','"+buscart+"','"+ownert+"','"+phonet+"','"+seatt+"','"+typei+"','"+busi+"')";
       }
       else
       {
       SQLStatement1="INSERT INTO Buscardetails VALUES('CAR','"+buscart+"','"+ownert+"','"+phonet+"','"+seatt+"','"+typei+"','"+cari+"')";
      	
       }
        if(SQLStatement1!=null) 
        {
        System.out.println(SQLStatement1);
        statement.executeUpdate(SQLStatement1);
        SQLStatement1=null;
         JOptionPane.showMessageDialog(desk, "Congratulation You Sucessfully Save");
       fieldbuscar.setText("");
     //    fieldcar.setText("");
         fieldowner.setText("");
         fieldphone.setText("");
         fieldseat.setText("");
        }
 			
 		}
 		catch(Exception e1)
 		{
 		 System.err.println(e1);	
 		}
 		}
 	}
      
   if( "Exit  ".equals (e.getActionCommand()))	
   {
   frame.setVisible(false);
    //System.exit(0);
   }
 	
 }
	
public String showindow()
{
      JFrame.setDefaultLookAndFeelDecorated(true);
	  frame = new JFrame(); 
      frame.setTitle("Vehicle Details Entery");
      Toolkit theKit = frame.getToolkit();      
      Dimension wndSize = theKit.getScreenSize();  
      frame.setBounds(wndSize.width/4, wndSize.height/20,   
                     3*wndSize.width/10, 2*wndSize.height/10);   
       JPanel panel1 = new JPanel();  
      panel1.add(hbox1);
      frame.add(panel1, BorderLayout.CENTER); 
       frame.pack();
      frame.setVisible(true);
      str="0";
      frame.addWindowListener(new WindowAdapter() {      
    
            public void windowClosing(WindowEvent e) {
            	 str="1";
           
             System.out.println("close="+str); 
                           
              //System.exit(0);                    
            }
          } );
          
           System.out.println("return="+str);
          return(str);         	
}	

/*	public static void main(String[] args)
	{
		
         BusDetailFrame BusDetailobj=new BusDetailFrame();
         BusDetailobj.showindow();
	}*/
}
