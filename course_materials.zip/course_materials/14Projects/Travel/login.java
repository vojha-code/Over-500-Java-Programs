import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.DriverManager;                  
import java.sql.Connection;                  
import java.sql.Statement;                  
import java.sql.SQLException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;



public class login implements ActionListener
                              
{
      JFrame logframe;
      Box vbox1;
      private JTextField textField1;
      private JPasswordField passwordField;
      JButton button1;
      JButton button2;
      public Statement statement;
      Connection connection;
      final JDesktopPane desk ;
       
      
 public login(){
 	  connectdatabase();
      
      JLabel label1 = new JLabel("USER ID:-");
      label1.setForeground(Color.black);

      textField1 = new JTextField(18);
      textField1.setMaximumSize(textField1.getPreferredSize());
        textField1.addKeyListener
      	(new KeyAdapter() {
         public void keyPressed(KeyEvent e) {
           int key = e.getKeyCode();
          if (key == KeyEvent.VK_ENTER) {
              //Toolkit.getDefaultToolkit().beep();   
              System.out.println("A");
             
              }
           }
         }
      );
       
      Box hbox1 = Box.createHorizontalBox();
      hbox1.add(label1);
      hbox1.add(Box.createHorizontalStrut(39));
      hbox1.add(textField1);
      
      JLabel label2 = new JLabel("PASSWORD:-");
      label2.setForeground(Color.black);

      passwordField = new JPasswordField(10);  

      Box hbox2 = Box.createHorizontalBox();
      hbox2.add(label2);
      hbox2.add(Box.createHorizontalStrut(15));
      hbox2.add( passwordField);	
                        
      JButton button1 = new JButton(" ENTER ");
      button1.addActionListener(this);
      button1.setActionCommand(" ENTER ");
      button1.setBackground(Color.white);
button1.addKeyListener
      	(new KeyAdapter() {
         public void keyPressed(KeyEvent e) {
           int key = e.getKeyCode();
           if (key == KeyEvent.VK_ENTER) {
              Toolkit.getDefaultToolkit().beep();   
              System.out.println("ENTER pressed");
              doevent();
              }
           }
         }
      );
      
       
      JButton button2 = new JButton("CANCEL");
      button2.addActionListener(this);
      button2.setActionCommand("CANCEL"); 
      button2.setBackground(Color.white);
            
button2.addKeyListener
      	(new KeyAdapter() {
         public void keyPressed(KeyEvent e) {
           int key = e.getKeyCode();
           if (key == KeyEvent.VK_ENTER) {
              Toolkit.getDefaultToolkit().beep();   
              System.out.println("CANCEL pressed");
              doeventclose();
              }
           }
         }
      );
      

                   
      Box hbox3 = Box.createHorizontalBox();
      hbox3.add(button1);
      hbox3.add(Box.createHorizontalStrut(60));
      hbox3.add(button2);
      
      vbox1 = Box.createVerticalBox();
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox1);
      vbox1.add(Box.createVerticalStrut(20));
      vbox1.add(hbox2);
      vbox1.add(Box.createVerticalStrut(50));
      vbox1.add(hbox3);
       desk = new JDesktopPane();
        
     }
      
 public void actionPerformed(ActionEvent e) { 
 
 if ("CANCEL".equals(e.getActionCommand()))  
    
    { //System.exit(0);
    	
    	logframe.dispose();
    	logframe.setVisible(false);
      
    	}   
    	
    else if (" ENTER ".equals(e.getActionCommand()))
        {
        	doevent();
        }
 
    
       }
       
       public void doeventclose()
       
       {
       	  logframe.dispose();
    	 logframe.setVisible(false);
       	
       	 }
  
       
                
 public void doevent()
  
  
  {
      String logindatetime;

      String txtuid =(textField1.getText());
      String txtpwd=new String (passwordField.getPassword()); 
      String uid=new String();
      String pwd=new String();
      
      boolean ans1=false; 
      boolean ans2=false;   	
       

           
     try{
    
      ResultSet loginResults = statement.executeQuery("select * from newuser");
      while (loginResults.next()) {
     	uid=(loginResults.getString(1));
     	
     	uid=uid.trim();
     System.out.println("uid");
     
     	pwd=(loginResults.getString(2));
     	pwd=pwd.trim();
   	System.out.println(" "+uid+" "+pwd);
      if ((uid.equals(txtuid)  )&&(pwd.equals(txtpwd)))      
        {
            
         ans1=true;
         break;
        }
        
      else if((txtuid.equals("admin"))&&(txtpwd.equals("sn"))){
      	ans2=true;
         break;
      } 
      
     
       }
       
      loginResults.close(); 
               
      } 
      
      catch (Exception e1) {
        System.err.println(e1);
      }
      
   
  if (ans1==true){
  	
       String currentPattern1 = "dd/MM/yy 'at' h:mm:ss a";
     Date today1 = new Date();
    
     SimpleDateFormat formatter1 =new SimpleDateFormat(currentPattern1);
            
     logindatetime= formatter1.format(today1);
     //System.out.println(logindatetime);
     
     try{
         
       String SQLStatement1 = null;
           
        SQLStatement1="INSERT INTO log_history VALUES("+"'"+uid+"','"+logindatetime+"'"+",' "+"')";
        
     while(SQLStatement1!=null) {
        System.out.println(SQLStatement1);
        statement.executeUpdate(SQLStatement1);
        SQLStatement1=null;
        
        }
         }catch (Exception e1) {
        System.err.println(e1);
      }
                   

                     JOptionPane.showMessageDialog(logframe,
                            "Valid UserId & Password.\nLogin successfully.", 
                            "CONFIRMATION MESSAGE",
                            JOptionPane.INFORMATION_MESSAGE);
                       	  
                       	  SketchKol obj=new  SketchKol(statement,"Welcome To Kolkata");
                         logframe.setVisible(false);


        }
            
   else if (ans2==true){
  	
       String currentPattern1 = "dd/MM/yy 'at' h:mm:ss a";
     Date today1 = new Date();
    
     SimpleDateFormat formatter1 =new SimpleDateFormat(currentPattern1);
            
     logindatetime= formatter1.format(today1);
     System.out.println(logindatetime);
     
     try{
         
       String SQLStatement1 = null;
           
        SQLStatement1="INSERT INTO log_history VALUES("+"'"+txtuid+"','"+logindatetime+"'"+",' "+"')";
        
     while(SQLStatement1!=null) {
        System.out.println(SQLStatement1);
        statement.executeUpdate(SQLStatement1);
        SQLStatement1=null;
        
        }
         }catch (Exception e1) {
        System.err.println(e1);
      }
                

                      JOptionPane.showMessageDialog(logframe,
                            "Valid UserID & Password.\nLogin successfully.", 
                            "CONFIRMATION MESSAGE",
                            JOptionPane.INFORMATION_MESSAGE);
                       
                       	SketchKol obj=new  SketchKol(statement,"Welcome To Kolkata");
                          logframe.setVisible(false);
                               //logframe.setVisible(true);


         }         
            
  else
           {
           	JOptionPane.showMessageDialog(logframe,
                 "Invalid UserID or Password.\nLogin fail. \n Please Try Again......", 
                     "ERROR MESSAGE",
                            JOptionPane.ERROR_MESSAGE);
           	}
  
       
 
                
      textField1.setText(null);
      passwordField.setText(null);
   
    }             

     public void showwindow(){
      	
      JFrame.setDefaultLookAndFeelDecorated(true);
	  logframe = new JFrame(); 
      logframe.setTitle("LOGIN WINDOW");
      Toolkit theKit = logframe.getToolkit();      
      Dimension wndSize = theKit.getScreenSize();  
      logframe.setBounds(wndSize.width/4, wndSize.height/4,   
                      2*wndSize.width/5, wndSize.height/3); 
      
      JPanel panel = new JPanel();
      panel.add(vbox1);
      logframe.add(panel, BorderLayout.CENTER);  
      panel.setBackground(Color.pink);
      
      logframe.setVisible(true);
      
      //logframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           
      }
      public void connectdatabase(){
      	 try {
    
      String url = "jdbc:odbc:db3";
      String driver = "sun.jdbc.odbc.JdbcOdbcDriver";

      Class.forName(driver);
      connection = DriverManager.getConnection(url); 
      statement = connection.createStatement();
          
       } catch (Exception e1) {
        System.err.println(e1);
       }
      }
      
     /*public static void main(String[] args)
       {  
          login obj=new login();
          obj.showwindow();
         
       }*/
 }
