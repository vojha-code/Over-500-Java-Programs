import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;

public class welcome                          
{     
	  static JFrame frame1;
	  static Box vbox1;
	  public  JButton button1;
          static JPanel panel;
      
public welcome(){
        
        JFrame.setDefaultLookAndFeelDecorated(true);
	    frame1 = new JFrame(); 

      frame1.setTitle("NAMASTE");
      //Toolkit theKit = frame1.getToolkit();
      Dimension wndSize = frame1.getToolkit().getScreenSize();  
      frame1.setBounds(wndSize.width/4, wndSize.height/4,   
                      2*wndSize.width/5, wndSize.height/3);
                      
     
      frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      //frame1.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    
      JLabel label0=new JLabel("Travel Tourism System"); 
	  JLabel label1=new JLabel("CONTINUE TO NEXT STEP  "); 
	  JLabel label2=new JLabel(".... PRESS ....");
	  
	  Box hbox0 = Box.createHorizontalBox();
      hbox0.add(label0);
      
	  Box hbox1 = Box.createHorizontalBox();
      hbox1.add(label1);
      
      Box hbox2 = Box.createHorizontalBox();
      hbox2.add(label2);
           
      JButton button1 = new JButton(" ENTER ");
      button1.setActionCommand(" ENTER ") ; 
      button1.setFont(new Font("SansSerif", Font.BOLD, 16));
      button1.setForeground(Color.black);
      button1.setBackground(Color.white);


     button1.addActionListener(new ActionListener() {
      	
                public void actionPerformed(ActionEvent e) {
                   if (" ENTER ".equals(e.getActionCommand())) {
                   	
                   	login obj=new login();
                    obj.showwindow();
                    frame1.setVisible(false);
                   //System.exit(0);
    	         }
                }
            });
          
 button1.addKeyListener
      	(new KeyAdapter() {
         public void keyPressed(KeyEvent e) {
           int key = e.getKeyCode();
          if (key == KeyEvent.VK_ENTER) {
              login obj=new login();
               obj.showwindow();
               frame1.setVisible(false);
             
              }
           }
         }
      );
                              
      Box hbox4= Box.createHorizontalBox();
      hbox4.add(button1);
      label0.setForeground(Color.red);
      label0.setBackground(Color.white);
      label0.setOpaque(true);
      label0.setFont(new Font("SansSerif", Font.BOLD, 20));
       
      vbox1 = Box.createVerticalBox();
      vbox1.add(hbox0);
      vbox1.add(Box.createVerticalStrut(22));
      vbox1.add(hbox1);
      //vbox1.add(Box.createVerticalStrut(8));
      vbox1.add(hbox2);
      vbox1.add(Box.createVerticalStrut(25));
      vbox1.add(hbox4);
        
      panel = new JPanel();
      //panel.setBorder(new TitledBorder(new EtchedBorder(),"Welcome to our")); 
      panel.setBorder(BorderFactory.createTitledBorder("Welcome To "));
         
      panel.add(vbox1);
      panel.setBackground(Color.gray);
      frame1.add(panel, BorderLayout.CENTER);  
      
      
     //frame1.pack();
                         
     frame1.setVisible(true);

    }  
        
 public static void main(String[] args)
       
       {   
      	 welcome obj=new welcome();
       }
       
}