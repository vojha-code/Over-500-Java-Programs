import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;

public class Exit 
                     
                              
{     
	  static JFrame frame1;
	  static Box vbox1;
	  public  JButton button1;
      static JPanel panel;
      
public Exit(){
        
        JFrame.setDefaultLookAndFeelDecorated(true);
	    frame1 = new JFrame(); 

      frame1.setTitle("Good Bye Everyone");
      //Toolkit theKit = frame1.getToolkit();
      Dimension wndSize = frame1.getToolkit().getScreenSize();  
      frame1.setBounds(wndSize.width/4, wndSize.height/4,   
                      2*wndSize.width/4, wndSize.height/3);
                      
     
      frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      //frame1.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    
      JLabel label0=new JLabel("Send the feedback of this project."); 
	  JLabel label1=new JLabel("Please don't forget."); 
	  JLabel label2=new JLabel(".............Have a good day...........");
	  
	  // Box hbox0 = Box.createHorizontalBox();
      ImageIcon icon = new ImageIcon("painting/picture.gif");
      JLabel piclable = new JLabel(icon); 
      
	  Box hbox0 = Box.createHorizontalBox();
      hbox0.add(label0);
      
	  Box hbox1 = Box.createHorizontalBox();
      hbox1.add(label1);
      
      Box hbox2 = Box.createHorizontalBox();
      hbox2.add(label2);
           
      JButton button1 = new JButton(" EXIT ");
      button1.setActionCommand(" EXIT ") ; 
      button1.setFont(new Font("SansSerif", Font.BOLD, 15));
      button1.setForeground(Color.blue);
      button1.setBackground(Color.white);


      button1.addActionListener(new ActionListener() {
      	
                public void actionPerformed(ActionEvent e) {
                   if (" EXIT ".equals(e.getActionCommand())) {
                   	
                   	//LoginScreen obj=new LoginScreen();
                    //obj.showwindow();
                   System.exit(0);
    	         }
                }
            });
                              
      Box hbox4= Box.createHorizontalBox();
      hbox4.add(button1);
      
      label0.setForeground(Color.blue);
      label0.setBackground(Color.green);
      //label2.setForeground(Color.red);

      label0.setOpaque(true);
      label0.setFont(new Font("SansSerif", Font.BOLD, 20));
       
      vbox1 = Box.createVerticalBox();
      //vbox1.add(hbox0);
      vbox1.add(Box.createVerticalStrut(22));
      vbox1.add(hbox1);
      //vbox1.add(Box.createVerticalStrut(8));
      vbox1.add(hbox2);
      vbox1.add(Box.createVerticalStrut(22));
      vbox1.add(hbox4);
      
      Box vbox2 = Box.createVerticalBox();
      //vbox2.add(Box.createVerticalStrut(22));
      vbox2.add(piclable);
       
      Box hbox5= Box.createHorizontalBox();
      hbox5.add(Box.createHorizontalStrut(100));
      hbox5.add(vbox1);
      hbox5.add(Box.createHorizontalStrut(20));
      hbox5.add(vbox2);
      
      Box vbox3= Box.createVerticalBox();
      vbox3.add(hbox0);
      vbox3.add(hbox5);
       
      panel = new JPanel();
      panel.setBorder(BorderFactory.createTitledBorder("Exit from the project"));
      panel.setBackground(Color.gray);
      panel.add(vbox3);

      frame1.add(panel, BorderLayout.CENTER);  
            
     //frame1.pack();
                         
     frame1.setVisible(true);

    }  
        
 public static void main(String[] args)
       
       {   
      	 Exit obj=new Exit();
       }
       
}