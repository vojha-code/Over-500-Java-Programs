class IfLoop
{

  public static void main(String args[])
  {

   int ia=4;
   int ib=4;
   char ca='a';
   char cb='a';
   String sa="Varun";
   String sb="Varun";



System.out.println("\n INTEGER >>:::::::::::::::::::::::::::::");

   System.out.println("\nTested 1st ---------> ");

   if(ia==4)
    System.out.println("The if(ia==4) Loop Running : Successed\n");
   else
    System.out.println("The if(ia==4)   Loop Running : Failed\n");


   System.out.println("\nTested 2nd ---------> ");

   if(ia==ib)
    System.out.println("The if(ia==ib)  Loop Running : Successed\n");
   else
    System.out.println("The If  Loop Running : Failed\n");


   System.out.println("\nTested 3rd ---------> ");

   if(true)//we can not write if(1)becouse in java it check boolean type i.c.  true/false
    System.out.println("The if(true) Loop Running : Successed\n");
   else
    System.out.println("The if(true) Loop Running : Failed\n");


System.out.println(" CHARECTER >>:::::::::::::::::::::::::::::");

   System.out.println("\nTested 1st ---------> ");

   if(ca=='a')
    System.out.println("The if(ca=='a')  Loop Running : Successed\n");
   else                           
    System.out.println("The if(ca=='a')  Loop Running : Failed\n");


   System.out.println("\nTested 2nd ---------> ");

   if(ca==cb)
    System.out.println("The if(ca==cb)  Loop Running : Successed\n");
   else
    System.out.println("The if(ca==cb)  Loop Running : Failed\n");


System.out.println(" STRING >>:::::::::::::::::::::::::::::");

   System.out.println("\nTested 1st ---------> ");

   if(sa=="Varun")
    System.out.println("The if(sa==\"Varun\") Loop Running : Successed\n");
   else
    System.out.println("The if(sa==\"Varun\") Loop Running : Failed\n");


   System.out.println("\nTested 2nd ---------> ");

   if(sa==sb)
    System.out.println("The  if(sa==sb) Loop Running : Successed\n");
   else
    System.out.println("The  if(sa==sb) Loop Running : Failed\n");

   System.out.println("\nTested 3rd ---------> ");

   if(sa.equals("Varun"))
    System.out.println("The  if(sa.equals(\"Varun\")) Loop Running : Successed\n");
   else
    System.out.println("The  if(sa.equals(\"Varun\")) Loop Running : Failed\n");

   System.out.println("\nTested 4th ---------> ");

   if(sa.equals(sb))
    System.out.println("The  if(sa.equals(sb)) Loop Running : Successed\n");
   else
    System.out.println("The  if(sa.equals(sb)) Loop Running : Failed\n");

  }
}
