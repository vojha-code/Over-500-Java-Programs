class WhileLoop
{

  public static void main(String args[])
  {
    System.out.println();
    int i=0;

    try
    {
     
     while(i<10)
     {
      System.out.print(" "+i);
      i++;
      Thread.sleep(1000);
     }
    }
    catch(Exception e)
    {
     System.out.println(e);
    }
    finally
    {
     System.out.println();
    } 
      
   }
}
      
