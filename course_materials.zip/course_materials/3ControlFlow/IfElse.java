import java.io.*;

class IfElse
{

  public static void main(String args[])
  {
   System.out.println();

    String name="";

    try
    {

      BufferedReader br  =  new BufferedReader(new InputStreamReader(System.in));

      System.out.print("\nEnter The Name :");
      name=br.readLine();

      if(name.equalsIgnoreCase("Varun"))
      {
        System.out.println("You Have Entered "+name);
      }
      else if(name.equalsIgnoreCase("Tarun"))
      {
       System.out.println("You Have Entered "+name);
      }
      else
       System.out.println("You Have Entered Wrong name :"+ name);
    }
    catch(Exception e)
    {
     System.out.println(e);
    }
  }
}

