class ForLoop
{

  public static void main(String args[])
  {
    int i;

    System.out.println("\nTest for(i=0 ; i<10 ; i++) :");
    for(i=0;i<10;i++)
     System.out.print(" "+i);

    System.out.println("\n\nTest for(i=0 ; i<10 ; i++); :");
    for(i=0;i<10;i++);
     System.out.print(" "+i);

    System.out.println("\n\nTest for( ; i<10 ; i++) :");
    i=0;
    for( ;i<10;i++)
     System.out.print(" "+i);

    System.out.println("\n\nTest for( ; i<10 ; ) :");
    i=0;
    for( ;i<10; )
     System.out.print(" "+i++);

    System.out.println("\n\nTest //for( ;  ; ) :");
   // for( ; ; )
     System.out.print(" BLANK : It is an infinite loop ");

    System.out.println("\n\nTest //for( ;true; ) :");
    //for( ;true; )
     System.out.print(" BLANK : It is an infinite loop ");


    System.out.println("\n\nTest for( ; i<10 ;System.out.print(\" \"+i++) ) :");
    i=0;
    for(  ;i<10; System.out.print(" "+i++) )
    {}

    System.out.println("\n\nTest for(System.out.print(\" \"+i) ; i<10 ;System.out.print(\" \"+i++) ) :");
    i=0;
    for(System.out.print(" "+i) ;i<10; System.out.print(" "+i++) )
    {}

    System.out.println();
   }
}
