class MethodOverload
{

  void printToScreen(int a,int b)
  {
   System.out.println();
   System.out.println(a);
   System.out.println(b);
  }
  void printToScreen(int a,char c)
  {
   System.out.println();
   System.out.println(a);
   System.out.println(c);
  }
  void printToScreen(char c,int a)
  {
   System.out.println();
   System.out.println(c);
   System.out.println(a);
  }
  void printToScreen(int a,int b,char c)
  {
   System.out.println();
   System.out.println(a);
   System.out.println(b);
   System.out.println(c);
  }
  void printToScreen(int a,char c,float f,String s)
  {
   System.out.println();
   System.out.println(a);
   System.out.println(c);
   System.out.println(f);
   System.out.println(s);
  }
}
class OverloadingTest
{
  public static void main(String args[])
  {
    MethodOverload mo;
    mo = new MethodOverload();


    mo.printToScreen(11,22);
    mo.printToScreen(11,'m');
    mo.printToScreen('m',11);
    mo.printToScreen(11,22,'m');
    mo.printToScreen(11,'m',11.11f,"string");
  }
}




