
class Student
 {
  void best(String name,int roll)
  {
   System.out.println("Name:"+name+"\nRoll:"+roll);
  }
 }
class Sub extends Student
 {
   void stu(String name,int roll)
    {
     super.best(name,roll);
    }
 }
class Inherit1
 {
   public static void main(String []args)
   {
    Sub su;
    su=new Sub();
    su.stu("varun",11);
   }
 }
