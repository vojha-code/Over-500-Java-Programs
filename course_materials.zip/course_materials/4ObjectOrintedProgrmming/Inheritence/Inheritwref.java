class A
{
  A()// i m the first constructor
 {
  int a=1;
  System.out.println("A:"+a);
 }
}
class B 
{
 B()// i m the second constructor
 {
  int a=2;
  System.out.println("B:"+a);
 }
 A obj2=new A();
}
class C
{
 int c=3;
 B obj1=new B();
}
class Inheritwref
{
  public static void main(String []args)
  {
   C obj=new C();
   System.out.println("C:"+obj.c);
  }
}
