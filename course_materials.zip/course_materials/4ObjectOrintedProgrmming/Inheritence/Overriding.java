

//final class x //cannot inherit from class x
                // class y extends x
                //                 ^

class x         
{
   int a,b,c;

   x(int m,int n)
    {
     a=m;
     b=n;
    }
  //final int add()  //add() in y cannot override add() in x:Overriden method cannot final
                     //public int add()
                     //           ^

   int add()
   {
     c = a+b;
   
    return(c);
   }
}
class y extends x 
{
 int d;

 y(int m,int n,int o)
  {
   super(m,n);
   d=o;
  }
  
  public int add()
  {
    //int s = super.add();
	
    c = 4+d;
    return(c);
  }
}

class Overriding
{
 public static void main(String args[])
  {

    x f=new x(2,4);

    y c = new y(3,6,9);

     System.out.println("F:"+f.add());
     System.out.println("C:"+c.add());
   }
}

