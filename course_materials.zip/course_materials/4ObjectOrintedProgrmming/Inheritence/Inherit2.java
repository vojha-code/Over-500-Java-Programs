
class Car
{
 Car()
  {
   name="Classic";
   cost=10000;
  }
 void display()
  {
   System.out.println(name);
  }
 void showme()
  {
   System.out.println("Model:"+name+" and Price:"+cost);
  }
 String name;
  int cost;
}
class Zen
{
 void display()
  {
   System.out.println(" I M ZEN ");
  }
 void model()
  {
   Car C=new Car();
   C.display();
   C.showme();
  }
 void showzen()
  {
   display();
    model();
  }
}
class Inherit2
{
 public static void main(String []args)
  {
   Zen Z=new Zen();
   //Z.model();
   Z.showzen();
  }

}  

  

 
