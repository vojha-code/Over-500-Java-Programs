class x
{
  x()
  {
    System.out.println("Execution Order No. 2 : Object of class x constructed!");
  }
}
class y extends x
{

  y()
  {
    System.out.println("Execution Order No. 3 : Object of class y constructed!");
  }
}
class z extends y
{
 static
 {
   System.out.println("\nExecution Order No. 1 : Class z :I m static block,I m The 1st wherever is me!");
 }

  z()
  {
    System.out.println("Execution Order No. 4 : Object of class z constructed!");
  }
}
class ConstructorOrderTest
{
  public static void main(String args[])
  {
    z obj = new z();
  }
}

