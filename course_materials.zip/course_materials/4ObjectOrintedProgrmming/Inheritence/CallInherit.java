class A
{
 //A()
 {
  System.out.println("I M BASE CLASS");
 }
}
class B extends A
{
 B()
 {
  //super();
  System.out.println("I M CLASS B");
 }
}
class C extends A
{
 C()
 {
  //super();
  System.out.println("I M CLASS C");
 }
}
class D extends A
{
 D()
 {
  //super();
  System.out.println("I M CLASS D");
 }
}

class CallInherit
{
  public static void main(String args[])
  {
   A[] obj={new B(),new C(),new D()};
    
  }
}
     
