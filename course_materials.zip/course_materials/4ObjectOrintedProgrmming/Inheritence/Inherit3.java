class car
{
 car()//Constructor
  {
   name="Clasic";
   cost=10000;
  }
 void display()
  {
    System.out.println(name);
  }
 void showname()
  {
   System.out.println("MODEL="+name+"\nand PRICE="+cost);
  }
  String name;
   int cost;
}
class zen extends car
{
 void display()
  {
   System.out.println("I M ZEN");
  }
 void model()
  {
    System.out.print("Model:");
    super.display();
  }
 void showzen()
  {
    display();
     model();
      showname();
  }
}
class Inherit3
{
 public static void main(String []args)
 {
  zen obj=new zen();
  obj.showzen();
 // obj.showname();
 }
}
