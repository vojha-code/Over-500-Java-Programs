class A
{
 int a=1;
}
class B extends A
{
 int a=2;
}
class C extends B
{
 int a=3;
}
class Inheritref
{
  public static void main(String []args)
  {
   C obj=new C();
  
   B obj1=obj;
   System.out.println("B:"+obj1.a); 
   A obj2=obj1;
   System.out.println("A:"+obj2.a);
   System.out.println("C:"+obj.a);
  }
}
