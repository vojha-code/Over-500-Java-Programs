class Variable
{
 int I;
 static int S;

{System.out.println("INSTANCE BLOCK");}//execute whenever instatiation occurs
 
static
{
   System.out.println("STATIC BLOCK");//executed first and once inspite sevral instatiation
 }
 
 Variable(int a)
 {
  I=a;
  S=a;
 }
 public static void main(String args[])
 {
  Variable v1=new Variable(2);
  Variable v2=new Variable(3);
  Variable v3=new Variable(4);

  System.out.println("\n INSTANCE VARIABLE :\n");//can modifide sevrals time , inspite initialized once 

   System.out.println(v1.I);//Once initialized
   System.out.println(v2.I);
   System.out.println(v3.I);
                                                
  System.out.println("\n STATIC VARIABLE :\n");//can not modified once initialized

   System.out.println(v1.S);//Once initialized
   System.out.println(v2.S);
   System.out.println(v3.S);

 
 }

}

