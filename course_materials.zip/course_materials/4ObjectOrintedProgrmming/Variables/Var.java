fclass Var
{
 public static void main(String ar[])
 {
  int a=64;
  int b=2;
  System.out.println(a<<<b);
  System.out.println(b<<a);
 }
}
