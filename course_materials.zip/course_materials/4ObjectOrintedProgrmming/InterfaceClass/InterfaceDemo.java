interface J
{
 void method1();
 void method2();
}

interface K extends J
{
 void method3();
 void method4();
}

interface L extends K
{
 void method4();
 void method6();
}
interface M
{
 void method6();
}


class TestInterface implements L,M
{

  public void method1()
  {
   System.out.println("inside method1");
  }

  public void method2()
  {
   System.out.println("inside method2");
  }

  public void method3()
  {
   System.out.println("inside method3");
  }

  public void method4()
  {
    System.out.println("inside method4");
  }

 public void method6()
  {
   System.out.println("inside method6");
  }
}

class InterfaceDemo
{

  public static void main(String args[])
  {

    TestInterface ti = new TestInterface();

    ti.method1();
    ti.method2();
    ti.method3();
    ti.method4();
    ti.method6();
  }
}


    
    
