abstract class Abstruct_Class
{
  abstract void m1();
}
class Concrete_Class extends Abstruct_Class
{

  void m1()
  {
   System.out.println("In m1");
  }
  void m2()
  {
   System.out.println("In m2");
  }
}

public class AbstractTest1
{

  public static void main(String args[])
  {

    Concrete_Class cC = new Concrete_Class();
    Abstruct_Class aC;

    //aC = new Abstruct_Class(); // abstract class can not be instantiated

    aC = cC; // here the abstract class is refreced

    aC.m1();
    cC.m2();
  }
}



 
