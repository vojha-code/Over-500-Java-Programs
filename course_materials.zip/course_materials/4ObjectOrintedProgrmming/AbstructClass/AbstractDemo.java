abstract class Polygon
{

  float dim1;
  float dim2;

  Polygon(float x, float y)
  {
   dim1=x;
   dim2=y;
  }
  abstract float area();
}

class Square extends Polygon
{

  Square(float side)
  {
   super(side,side);
  }

  float area()
  {
    return (dim1*dim2);
  }
}

class Triangle extends Polygon
{

 Triangle(float base,float height)
 {
  super(base,height);
 }

 float area()
 {
   return ((float)0.5*dim1*dim2);
 }
}
class Cylinder extends Polygon
{

  Cylinder(float radius,float height)
  {
   super(radius,height);
  }

  float area()
  {
   return ((float)3.14*dim1*dim1*dim2);
  }
}

class AbstractDemo
{

  public static void main(String args[])
  {

    Square   s = new Square(7);
    Triangle t = new Triangle(4,5);
    Cylinder c = new Cylinder(6,3);
    Polygon poly;

    poly = s;
     System.out.println("\nArea of Square   is : "+poly.area());

    poly = t;
     System.out.println("\nArea of Triangle is : "+poly.area());

    poly = c;
     System.out.println("\nArea of Cylinder is : "+poly.area());
    
  }
}
   
