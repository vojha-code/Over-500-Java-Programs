abstract class U
{
  abstract void method1();
  void method2()
  {
   System.out.println("inside method 2 of class : U");
  }
}

class V extends U
{

  void method1()
  {
   System.out.println("inside method 1 of class : V");
  }
}

class AbstractTest2
{

  public static void main(String args[])
  {

    V sub = new V();
    sub.method1();
    sub.method2();
  }
}

