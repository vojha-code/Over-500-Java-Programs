import java.util.*;

public class TreeSetRetainExample
{

  public static void main(String args[])
  {

    Set firstSet  = new TreeSet();
    Set secondSet = new TreeSet();

    firstSet.add("RAT");
    firstSet.add("CAT");
    firstSet.add("MAT");
    firstSet.add("BAT");

    secondSet.add("BALL");
    secondSet.add("CAP");
    secondSet.add("MAT");

    System.out.println("First  set Contain :"+firstSet);
    System.out.println("Second set Contain :"+secondSet);

    Set symmetricSet = new TreeSet(firstSet);
    symmetricSet.addAll(secondSet);

    Set tempSet = new TreeSet(firstSet);
    tempSet.retainAll(secondSet);
    symmetricSet.removeAll(tempSet);

    System.out.println("\nValue of either Set  :"+symmetricSet);
    System.out.println("\nValue common in both :"+tempSet);
  }
}



