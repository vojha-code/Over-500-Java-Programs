import java.util.*;

public class MergeList
{
  public static void main(String args[])
  {

    Vector v = new Vector();

    v.addElement("Apple");
    v.addElement("Banana");

    MergeList tempList = new MergeList();
    tempList.merge(v);
    tempList.arrayListDisplay(v);
  }

  public void merge(Collection c)
  {

    LinkedList merger = new LinkedList(c);
    merger.addFirst("Orange");
    merger.add("pomegrante");
    merger.addLast("Orange1");
    merger.removeLast();

    System.out.println(" We are in the Merger method :"+merger);

  }

  public void arrayListDisplay(Collection c)
  {

    ArrayList tempList = new ArrayList(c);
    System.out.println(" We are in the array list display method :"+tempList);
  }
}


