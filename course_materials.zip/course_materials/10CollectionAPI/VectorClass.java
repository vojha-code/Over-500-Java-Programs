import java.util.*;
class VectorClass
{

  private Vector pop;

  //create initial population
  void createpop()  
  {
    for(int j=0;j<5;j++)//totall 5 individualsa are created
    {
     double a[]=new double[10];
     for(int i=0;i<10;i++)
     {
       a[i] =  randomVaue();
     }
     pop.add(a);
    } 
  }


 //Double Random Value Generation
  double randomVaue()
  {
    Random rand = new Random();
     double prob ;
     //return prob =  (100 * rand.nextDouble());
     return prob =  rand.nextDouble();

  } 
  

  public static void main(String args[])
  {
     VectorClass ref = new VectorClass(); 
    
     ref.createpop();   
  }
  
}
