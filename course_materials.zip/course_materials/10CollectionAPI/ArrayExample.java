import java.util.*;

public class ArrayExample
{

  public static void main(String args[])
  {

    String objectArray[] = new String[]{"MAT","CAT","BAT","BALL"};

    System.out.println("List value are :"+Arrays.asList(objectArray));

    //System.out.println("index :"+Arrays.binarySearch(objectArray,"BAT"));

    System.out.println("List value before sorting :"+Arrays.asList(objectArray));

    Arrays.sort(objectArray);
    System.out.println("List value after  sorting :"+Arrays.asList(objectArray));
  }
}





