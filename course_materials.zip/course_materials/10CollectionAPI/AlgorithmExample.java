import java.util.*;

public class AlgorithmExample
{

  public static void main(String args[])
  {

    List list  = new ArrayList();

    list.add("MAT");
    list.add("CAT");
    list.add("BAT");
    list.add("BALL");

    System.out.println("List value are :"+list);

    Collections.reverse(list);
    System.out.println("List value after reversing :"+list);

    Random rnd = new Random();

    Collections.shuffle(list,rnd);
    System.out.println("List after shuffling :"+list);

    System.out.println("The key is found at index :"+Collections.binarySearch(list,new String("BAT")));

    Collections.sort(list);
    System.out.println("List value after sorting :"+list);

  }
}
