import java.util.*;

public class IteratorExample
{

  public static void main(String args[])
  {

    ArrayList aList = new ArrayList();

    aList.add("Apple");
    aList.add("Banana");

    Iterator iter = aList.iterator();

    while(iter.hasNext())
      System.out.println(iter.next());
  }
}

