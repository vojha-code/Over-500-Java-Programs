import java.util.*;

public class TreeMapExample
{

  private static final Integer ONCE = new Integer(1);

  public static void main(String args[])
  {

    Map map = new TreeMap();

    for(int j=0;j<args.length;j++)
    {

      Integer frequency = (Integer)map.get(args[j]);

      map.put(args[j],(frequency==null ? ONCE : new Integer(frequency.intValue()+1)));
    }

    
    System.out.println(" No. of distinct words detected :"+map.size());
    System.out.println(map);
    //System.out.println(map.get("jg"));
  
  }
}
