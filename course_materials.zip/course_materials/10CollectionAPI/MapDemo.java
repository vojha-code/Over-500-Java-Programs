import java.util.*;

public class MapDemo
{
  static
  {
   System.out.println();
  }

  public static void main(String args[])
  {

    Map courseHash = new Hashtable();

    courseHash.put(new Integer(1)," English");
    courseHash.put(new Integer(2)," Spanish");
    courseHash.put(new Integer(3)," Math");

    System.out.println(courseHash);
    System.out.println(courseHash.get(new Integer(3)));

    System.out.println();

    Map marksMap = new HashMap();

    marksMap.put(new Integer(1)," English");
    marksMap.put(new Integer(2)," Spanish");
    marksMap.put(new Integer(3)," Math");

    System.out.println(marksMap);
    System.out.println(marksMap.get(new Integer(2)));
    
  }
}

