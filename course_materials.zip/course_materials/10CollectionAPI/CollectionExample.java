import java.util.*;

public class CollectionExample implements Comparator
{

  public int compare(Object o1,Object o2)
  {
   return o1.toString().toLowerCase().compareTo(o2.toString().toLowerCase());
  }

  public static void main(String args[])
  {

    List list  = new ArrayList();

    list.add("MAT");
    list.add("CAT");
    list.add("BAT");
    list.add("ball");
    list.add("MAT");

    System.out.println("Sorting result Ignoring Case");

    Collections.sort(list,new CollectionExample());

    Iterator iter = list.iterator();

    while(iter.hasNext())
      System.out.println(iter.next());

    System.out.println("Sorting Results with case");

    Collections.sort(list);
    iter = list.iterator();

    while(iter.hasNext())
      System.out.println(iter.next());
  }
}


