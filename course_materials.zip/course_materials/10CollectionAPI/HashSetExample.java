import java.util.*;

public class HashSetExample
{

  public static void main(String args[])
  {

    Set argList = new HashSet();

    for(int i=0;i<args.length;i++)
    {

      if(!argList.add(args[i]))
      {
        System.out.println(" Duplicate detected :"+args[i]);
      }
    }

    System.out.println(" Size of Set :"+argList.size()+" distinct word detected :"+argList);
  }
}
