import java.util.*;

public class EnumerationExample
{

  public static void main(String args[])
  {

    Vector v = new Vector();

    v.addElement("Apple");
    v.addElement("Banana");

    Enumeration Enum = v.elements();

    while(Enum.hasMoreElements())
      System.out.println(Enum.nextElement());
  }
}
