import java.io.*;

class ByteArrayInputStreamExample
{

  public static void main(String args[])throws IOException
  {

    String strText = "hello World";
    System.out.println("\n "+strText);


    byte byteArray[] = strText.getBytes();

    ByteArrayInputStream bi = new ByteArrayInputStream(byteArray);

    System.out.print("\nByteArrayInputStream holds : ");

    int charRead;

     while((charRead = bi.read()) != -1)
      System.out.print(Character.toUpperCase((char)charRead));

    bi.reset();
    System.out.println();
  }
}
