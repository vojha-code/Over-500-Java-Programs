import java.io.*;

class file3
{
        public static void main(String []args) throws Exception
        {
          if(args.length==2)
          {
         // String s=args[1];
         try
         {
                 File sourcefile=new File(args[0]);
                 File destifile=new File(args[1]);

                 FileReader in=new FileReader(sourcefile);
                 FileWriter out=new FileWriter(destifile);

                 int c;
                 while((c=in.read())!=-1)
                 {
                        out.write(c);
                 }
                 in.close();
                 out.close();
        }catch(FileNotFoundException e){
                System.out.println("File Not Found ");
                System.exit(0);
        }
        catch(IOException e){
                System.out.println("IO Exception Occur");
        }
        }
        }
}
