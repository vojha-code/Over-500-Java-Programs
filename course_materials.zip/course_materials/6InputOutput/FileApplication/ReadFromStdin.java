
 
import java.io.*;



public class ReadFromStdin {

    private static void doReadFromStdin() {

        try {

            BufferedReader inStream = new BufferedReader (
                                            new InputStreamReader(System.in)
                                          );

            String inLine;

            while ((inLine = inStream.readLine()) != null) {
                System.out.println(inLine);
            }

        } catch (IOException e) {

            System.out.println("IOException: " + e);

        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doReadFromStdin();
    }

}
