
 
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;



public class ReadFromConsole {

    private static void process(String str) {
        System.out.println("  processing... > " + str + "\n");
    }

    private static void doReadFromStdin() {

        try {

            BufferedReader inStream = new BufferedReader (
                                            new InputStreamReader(System.in)
                                          );

            String inLine = "";

            while ( !(inLine.equalsIgnoreCase("quit"))
                    &&
                    !(inLine.equalsIgnoreCase("exit")) ) {
                System.out.print("prompt> ");
                inLine = inStream.readLine();
                process(inLine);
            }


        } catch (IOException e) {

            System.out.println("IOException: " + e);

        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doReadFromStdin();
    }

}

