import java.io.*;

class file2
{
        public static void main(String []args) throws Exception
        {
          if(args.length==1)
          {
          String s=args[0];
         try
         {
                 File fp=new File(s);
                if(fp.exists())
                {
                        InputStream IPS =new FileInputStream(s);
                        int size=IPS.available();
                        if(size>0)
                        {
                        System.out.println("No. Of Char ="+size);
                        for(int i=0;i<size;i++)
                        {
                                System.out.print((char)IPS.read());
                            //   System.out.print(IPS.read());
                        }
                        IPS.close();
                        }
                         else
                                System.out.print("There is no Data present in the File");
                }
                else
                {
                        System.out.println("FILE DOESN'T EXISTS");
                }
        }catch(FileNotFoundException e){
          System.out.println("error occour");
        }
        }
        }
}
