import java.io.*;
import java.util.Scanner; 

class MatrixRead
{

  public static void main(String args[])
  {

    try
    {

     FileReader  fr = new FileReader("usnumbers1.txt");

     BufferedReader br =  new BufferedReader(fr);
     
     Scanner s = null;

     String Data;
     double sum[][] = new double[3][3];


     for(int i=0;i<3;i++)
      {
        if( (Data = br.readLine()) != null);
           s = new Scanner(Data);
        for(int j=0;j<3;j++)
          { 
              if (s.hasNextDouble())
              sum[i][j] = s.nextDouble();              
          }
               
      }

     for(int i=0;i<3;i++)
       {
          for(int j=0;j<3;j++)
             System.out.print(sum[i][j]+" ");
       System.out.println();
       }

  
  /*   while( (Data = br.readLine()) != null)
     { 
                         
        s = new Scanner(Data);
        sum = s.nextDouble();
        System.out.println(sum);
     } */

     br.close();
     fr.close();
    }
    catch(FileNotFoundException e)
    {
     System.out.println("File Not Found ");
     System.exit(0);
    }
    catch(IOException e)
    {
     System.out.println("Error "+e);
    }
 }
}

      
