import java.io.*;
//import java.io.InputStream;

class file1
{
//string str;
        public static void main(String []args) throws Exception
        {
         try
         {
           String str="c:\\";
                 File fp=new File(str);
                
                if(fp.exists())
                {
                        InputStream IPS =new FileInputStream(str);
                        int size=IPS.available();
                        if(size>0)
                        {
                        System.out.println("No. Of Char ="+size);
                        for(int i=0;i<size;i++)
                        {
                                
                                System.out.print((char)IPS.read());
                            //   System.out.print(IPS.read());
                        }
                        IPS.close();
                        }
                         else
                                System.out.print("There is no Data present in the File");

                        
                }

                else
                {
                        System.out.println("FILE DOESN'T EXISTS");

                }
        }catch(FileNotFoundException e){
	System.out.println("file error occour");
	
        }
        }
}
