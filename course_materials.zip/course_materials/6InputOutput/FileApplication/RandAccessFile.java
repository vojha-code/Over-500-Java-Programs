import java.io.*;

public class RandAccessFile{
	public static void main(String[] args) throws IOException{
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Enter File name : ");
		String str = in.readLine();
		File file = new File(str);
		if(!file.exists())
		{
			System.out.println("File does not exist.");
			System.exit(0);
		}
		try{
			RandomAccessFile rand = new RandomAccessFile(file,"rw");	//Open the file for both reading and writing 
			char ch = rand.readChar();	//Read a character
			rand.seek(file.length());	//Seek to end of file
			rand.writeChars("ibm");	//Write end of file 
			rand.close();
			System.out.println("Successfully");
		}
		catch(IOException e)
		{
		System.out.println(e.getMessage());
		}
	}
}
