import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.Locale;


public class ScanMatrix {
    public static void main(String[] args) throws IOException {
        Scanner s = null;
        double sum[][] = new double[2][2];
        try {
            s = new Scanner(
                    new BufferedReader(new FileReader("usnumbers1.txt")));
           
   
            while (s.hasNext())
            {
 
              for(int i=0;i<2;i++)
              {
               for(int j=0;j<2;j++)
               {
                if (s.hasNextDouble())
                   sum[i][j] = s.nextDouble();              
               }
               
              }
            }

           for(int i=0;i<2;i++)
           {
             for(int j=0;j<2;j++)
                 System.out.print(sum[i][j]+" ");
             System.out.println();
           }
         
        }
        catch(Exception e)
        { 
          System.out.println("Exception:"+e);
        }  
         finally {
            s.close();
        }

        //System.out.println(sum);
    }
}