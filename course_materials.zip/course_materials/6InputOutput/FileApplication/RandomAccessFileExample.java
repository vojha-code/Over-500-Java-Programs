

public class RandomAccessFileExample {

    private static void doAccess() {

        try {
        
            File file = new File("RandomAccessFileExample.out");
            RandomAccessFile raf = new RandomAccessFile(file, "rw");

            // Read a character
            byte ch = raf.readByte();
            System.out.println("Read first character of file: " + (char)ch);

            // Now read the remaining portion of the line.
            // This will print out from where the file pointer is located
            // (just after the '+' character) and print all remaining characters
            // up until the end of line character.
            System.out.println("Read full line: " + raf.readLine());


            // Seek to the end of file
            raf.seek(file.length());

            // Append to the end of the file
            raf.write(0x0A);
            raf.writeBytes("This will complete the example");

            raf.close();
            
        } catch (IOException e) {

            System.out.println("IOException:");
            e.printStackTrace();

        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doAccess();
    }

}
