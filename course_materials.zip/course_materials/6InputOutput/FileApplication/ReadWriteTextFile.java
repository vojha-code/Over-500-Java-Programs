// -----------------------------------------------------------------------------
// ReadWriteTextFile.java
// -----------------------------------------------------------------------------


 
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.IOException;



public class ReadWriteTextFile {

    private static void doReadWriteTextFile() {

        try {
        
            // input/output file names
            String inputFileName  = "README_InputFile.txt";
            String outputFileName = "ReadWriteTextFile.out";

            // Create FileReader Object
            FileReader inputFileReader   = new FileReader(inputFileName);
            FileWriter outputFileReader  = new FileWriter(outputFileName);

            // Create Buffered/PrintWriter Objects
            BufferedReader inputStream   = new BufferedReader(inputFileReader);
            PrintWriter    outputStream  = new PrintWriter(outputFileReader);

            // Keep in mind that all of the above statements can be combined
            // into the following:
            //BufferedReader inputStream = new BufferedReader(new FileReader("README_InputFile.txt"));
            //PrintWriter outputStream   = new PrintWriter(new FileWriter("ReadWriteTextFile.out"));

            outputStream.println("+---------- Testing output to a file ----------+");
            outputStream.println();

            String inLine = null;

            while ((inLine = inputStream.readLine()) != null) {
                outputStream.println(inLine);
            }

            outputStream.println();
            outputStream.println("+---------- Testing output to a file ----------+");

            outputStream.close();
            inputStream.close();

        } catch (IOException e) {

            System.out.println("IOException:");
            e.printStackTrace();

        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doReadWriteTextFile();
    }

}
