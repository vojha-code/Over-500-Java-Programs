import java.io.*;

public class ByteArrayOutputStreamExample
{

   public static void main(String args[])throws IOException
   {

     try
      {
        String strText ;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        do{

           System.out.print("\nEnter Text :");

           strText = br.readLine();
           strText = strText.trim();

        }while(strText.length() == 0);

        byte byteArray1[] = strText.getBytes();

        ByteArrayOutputStream  bo = new ByteArrayOutputStream();
        bo.write(byteArray1);

        System.out.println("\nByteOutputStream holds :"+bo.toString());
        System.out.println("\nNow  ByteArrayOutputStream is copide to a byte array:");

        byte byteArray2[] = bo.toByteArray();

         for(int i = 0; i<byteArray2.length;i++)
          System.out.print((char)byteArray2[i]);

        System.out.println();
      }
      catch(IOException e)
      {
       System.out.println("Exception ioe :"+e);
      }
   }
}
        

    
