import java.io.*;

class BufferedInputStreamExample
{
  public static void main(String args[])
  {
    if(args.length != 1)
    {
     System.err.println("type BufferedInputStreamExample fileName ");
     System.exit(1);
    }

  try
   {

     FileInputStream fis = new FileInputStream(args[0]);
     BufferedInputStream bis  = new BufferedInputStream(fis);

      int count = 0;
      int b;

      while((b = bis.read()) != -1)
      {
       if(b == '\n')
        {
         count++;
        }
      }

      bis.close();

      System.out.println("Count of lines are "+count);
    }
    catch(IOException ioe)
    {
     System.err.println("Exception ioe :"+ioe);
    }
 }

}

