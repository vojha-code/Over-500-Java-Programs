import java.io.*;

class PushbackInputStreamExample
{

  public static void main(String args[])throws IOException
  {

    try
     {
      String strText = "if(mark==75)\n"+"result=distinction;\n";
      byte byteArray[] = strText.getBytes();

      ByteArrayInputStream bainStream = new ByteArrayInputStream(byteArray);
      PushbackInputStream pbinStream = new PushbackInputStream(bainStream);

      int charRead;

       while((charRead = pbinStream.read()) != -1)
        {

         if(charRead  == '=')
         {
           if((charRead = pbinStream.read()) == '=')
           {
            System.out.print(" .eq."+" ");
           }
           else
           {
            System.out.print("<-"+" ");
            pbinStream.unread(charRead);
           }
         }
         else
         {
          System.out.print((char) charRead);
         }
       }
     }
     catch(IOException ioe)
     {
      System.out.println(" Exception ioe :"+ioe);
     }
   }
}
