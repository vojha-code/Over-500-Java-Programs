import java.io.*;

class CharArrayWriterExample
{

  public static void main(String args[])throws IOException
  {
    try
    {

      CharArrayWriter cw = new CharArrayWriter();
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

      String strText;

      do
      {

       System.out.print("\nEnter the Text :");

       strText = br.readLine();
       strText = strText.trim();

      }while(strText.length() == 0);

      char buffer[] = new char[strText.length()];
      strText.getChars(0,strText.length(),buffer,0);
      cw.write(buffer);

      System.out.print("\nCharArrayWriter Contains :"+cw.toString());
      System.out.println("\n\nArray contains");

      char charArray[] = cw.toCharArray();

      for(int i = 0;i < charArray.length ; i++)
         System.out.print(charArray[i]);

      System.out.println();

      FileWriter  fw = new FileWriter("OutputFiles\\Array.txt");
      cw.writeTo(fw);

      fw.close();
      cw.reset();

      System.out.println("\nArray contents are written to a file Array.txt");
    }
    catch(IOException e)
    {
      System.out.println(e);
    }

  }
}

    
