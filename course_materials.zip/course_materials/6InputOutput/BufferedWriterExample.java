import java.io.*;

class BufferedWriterExample
{

  public static void main(String args[])throws IOException
  {

    try
    {

      BufferedReader  br  = new BufferedReader(new InputStreamReader(System.in));

      String empName;
      int empAge;
      float empSalary;
      boolean maritalStatus;
      int Status = 0;

      boolean flag = false;

      System.out.print("\nEnter The Employee Details \n\n ");

      do
      {

        System.out.print("\nName :");
        empName = br.readLine();
        empName = empName.trim();

        int i;

        for(i = 0; i < empName.length() ; i++)
        {
          char c  = empName.charAt(i);

          if( Character.isLetter(c) == true )
            flag = true;
          else
            flag = false;

        }

        if(flag == false)
          System.out.println("Only Alphabates are allowed");

       }while( empName.length() == 0 || flag == false);

       do
       {
        System.out.print("Age  :");
        empAge = Integer.parseInt(br.readLine());

       }while(empAge<=0);

       do
       {
        System.out.print("Salary :");
        empSalary = Float.parseFloat(br.readLine());

       }while(empSalary<=0);

       do
       {
         System.out.print("Married  (1->yes , 0->No ) :");
         Status = Integer.parseInt(br.readLine());

         if(Status == 0)
           maritalStatus = true;
         else
           maritalStatus = false;

        }while(Status != 0 && Status != 1);

        Writer out = new FileWriter("OutputFiles\\emp.txt");

        BufferedWriter bw = new BufferedWriter(out);
        PrintWriter pr = new PrintWriter(bw);

        pr.println(empName);
        pr.println(empAge);
        pr.println(empSalary);
        pr.println(maritalStatus);

        pr.close();

        System.out.println("\n The employee detail is written to file emp.txt");


     }
     catch(NumberFormatException e)
     {
      System.out.println(e);
     }
     catch(IOException e)
     {
      System.out.println(e);
     }
     catch(Exception e)
     {
      System.out.println(e);
     }

   }
}
