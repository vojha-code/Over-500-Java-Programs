/* This programme reads the contents of file , and reverse each
and every word read and write it to a destination file , whose
contents are read and the outputed to standard output.
*/

import java.io.*;

class Reverse
{
  static
  {
   System.out.println();
  }

  public static void main(String args[])
  {

    try
    {

     File f1 = new File("OutputFiles\\word.txt");

     if(!f1.exists())
       throw new FileNotFoundException("File "+ f1.getName() +"Not Found");

     File f2 = new File("OutputFiles\\NewWord.txt");

     FileInputStream fis1 = new FileInputStream(f1);
     FileInputStream fis2 = new FileInputStream(f1);
     FileOutputStream fos1 = new FileOutputStream(f2);
     FileInputStream fos2 = new FileInputStream(f2);

     int count = 0;
     int c = 0;

     while((c = fis1.read()) != -1)
     {
       StringBuffer str = new StringBuffer();
       count = 1;

       while((c = fis1.read()) != 10)
         count++;

       System.out.println("\nThe total number count is :"+count+"\n");

       char  array[] = new char[count];
       int m = 0;

       while((c = fis2.read()) != 10)
       {

          array[m] = (char)c;
          str = str.append(array[m]);
          System.out.println("The String now is "+str);
          m++;
       }

       str.reverse();
       System.out.println("\nAffter reversing the String becomes :\n ");
       System.out.println(str);

       char temp[] = new char[count];
       str.getChars(0,count,temp,0);

       for(int j = 0; j< count ;j++)
       {

         int k = (int)temp[j];
         fos1.write(k);
       }
     }

     fis1.close();
     fis2.close();
     fos1.close();

     System.out.println("\nThe content of the destination file is\n");

       while((c = fos2.read()) != -1)
         System.out.print((char)c);

     System.out.println();

     fos2.close();
   }
   catch(ArrayIndexOutOfBoundsException e)
   {
     System.out.println("Subscript problem:"+e);
   }
   catch(FileNotFoundException e)
   {
     System.out.println(e);
   }
   catch(Exception e)
   {
     System.out.println(e);
   }

 }
}
