import java.io.*;

class InputStreamReaderExample
{

   public static void main(String args[])throws IOException
   {
     System.out.println();

     try
     {

       BufferedReader br =  new BufferedReader( new InputStreamReader(System.in));

       System.out.print("\nEnter the Text :");
       String strText = br.readLine();
       System.out.println("\nYou have entered the text : "+strText);

     }
     catch(IOException e)
     {
      System.out.println(e);
     }
   }
}
    
