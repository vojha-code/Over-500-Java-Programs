import java.io.*;

public class CharArrayReaderExample
{

  public static void main(String args[])throws IOException
  {

    System.out.println();

     try
     {

       BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

       String strText;
       int strTextLength;

       do
       {

         System.out.print("\nEnter The Text :");
         strText = br.readLine();
         strText = strText.trim();

         strTextLength = strText.length();

         System.out.println("The Length of the enterd text is :"+strTextLength);

       }while(strTextLength == 0);

       char arrayText[] = new char[strTextLength];
       strText.getChars(0,strTextLength,arrayText,0);

       CharArrayReader charArray1 = new CharArrayReader(arrayText);

       System.out.println("Now copied the entire text into charArray1 ");

       int i;

       while((i = charArray1.read()) != -1)
         System.out.print((char)i);

       System.out.println();

       int startIndex,numOfChars;

       do
       {
         System.out.print("\nEnetr the Index value from which you want to copy:");
         startIndex = Integer.parseInt(br.readLine());

         if(startIndex < 0)
           System.out.println("The index can not be negetive ");

         if(startIndex > strTextLength-1 )
           System.out.println("The index can not be greater than the text length");

       }while(startIndex < 0 || startIndex > strTextLength-1);

       do
       {
         System.out.print("\nEnetr the no. of character you wnt to copy :");
         numOfChars = Integer.parseInt(br.readLine());

         if(numOfChars < 0)
           System.out.println("The character can not be negetive ");

         if(numOfChars > strTextLength )
           System.out.println("The character can not be greater than the text length");

       }while(numOfChars < 0 || numOfChars >strTextLength);

       CharArrayReader  charArray2 = new CharArrayReader(arrayText,startIndex,numOfChars);

       System.out.println("\ncharArray2 holds Specified no of chars ");

       while((i = charArray2.read()) != -1)
         System.out.print((char)i);

       System.out.println();

     }
     catch(NumberFormatException e)
     {
      System.out.println(e);
      System.exit(1);
     }
     catch(IOException e)
     {
      System.out.println("Error :"+e);
     }

  }

}



         


