import java.io.*;

public class OutputStreamWriterExample
{

  public static void main(String args[])throws IOException
  {

    try
    {

      if(args.length != 1)
      {
       System.err.println("\nType the following in command Line");
       System.err.println("java OutputStreamWriterExample sourcefile");
       System.exit(0);
      }

      FileReader fr = new FileReader(args[0]);
      System.out.println("\nDisplaying OutputStreamWriter to standerd output\n");

      OutputStreamWriter osw = new OutputStreamWriter(System.out);
      BufferedWriter bw = new BufferedWriter(osw);

      int c = fr.read();
      while(c != -1)
      {
        bw.write(c);
        c = fr.read();
      }

      fr.close();
      bw.close();

    }
    catch(FileNotFoundException e)
    {
     System.out.println("\n Source file"+args[0] +" not found");
     System.exit(0);
    }
    catch(IOException e)
    {
      System.out.println(e);
    }
  }
}



   
