import java.io.*;

class FileOutputStreamExample
{

  public static void main(String args[])
  {

    try
    {
      FileOutputStream out;
      PrintStream p;
      String strText;

      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

      do
      {
       
        System.out.print("\nEnter The Text :");

        strText = br.readLine();
        strText = strText.trim();

      }while(strText.length() == 0);

      out = new FileOutputStream("OutputFiles\\fileOutputExample.txt");
      p = new PrintStream(out);
      p.println(strText);

      System.out.println("\nThe Entered text written to the file fileOutputExample.txt ");

      p.close();
    }
    catch(Exception e)
    {
     System.out.println(e);
    }
  }
}


      
       
