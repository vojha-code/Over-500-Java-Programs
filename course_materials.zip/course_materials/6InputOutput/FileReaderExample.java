import java.io.*;

public class FileReaderExample
{

  public static void main(String args[])throws IOException
  {

    try
    {

      if(args.length != 2)
      {

        System.out.println("Type the following command line arrgument:");
        System.out.println("\n  java FileReaderExample  sourceFile  destinationFile");
        System.exit(1);
      }

      String sourceFile = args[0];
      String destinFile = args[1];

      File inputFile = new File(sourceFile);
      File outputFile = new File(destinFile);

      FileReader in  = new FileReader(inputFile);
      FileWriter out = new FileWriter(outputFile);

      int c;

      System.out.println("\nThe content of sourceFile is\n");

      while((c = in.read()) != -1)
      {
        System.out.print((char)c);
        out.write(c);
      }

      System.out.println("\n\n");

      in.close();
      out.close();

      File input = new File(destinFile);
      FileReader fr = new FileReader(input);

      System.out.println("\nThe content of destinationFile is\n");

      while((c = fr.read()) != -1)
         System.out.print((char)c);

      System.out.println();
      fr.close();

   }
   catch(FileNotFoundException e)
   {
    System.out.println(e);
   }
   catch(IOException e)
   {
    System.out.println(e);
   }
   catch(Exception e)
   {
    System.out.println(e);
   }

  }
}
