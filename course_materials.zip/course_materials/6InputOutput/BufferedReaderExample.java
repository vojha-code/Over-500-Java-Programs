import java.io.*;

class BufferedReaderExample
{

  public static void main(String args[])
  {

    try
    {

     FileReader  fr = new FileReader("OutputFiles\\MyText.txt");

     BufferedReader br =  new BufferedReader(fr);

     String Data;

     while( (Data = br.readLine()) != null)
       System.out.println(Data);

     br.close();
     fr.close();
    }
    catch(FileNotFoundException e)
    {
     System.out.println("File Not Found ");
     System.exit(0);
    }
    catch(IOException e)
    {
     System.out.println("Error "+e);
    }
 }
}

      
