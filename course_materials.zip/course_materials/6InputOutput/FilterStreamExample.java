import java.io.*;

public class FilterStreamExample extends FilterInputStream
{
  public FilterStreamExample(InputStream in)
  {
     super(in);
  }

  public int read()throws IOException
   {
     int value = in.read();

      if((value>='A' && value<='Z')||(value>='a' && value<='z'))
       return value;
      else if(value==10||value==13||value==9||value==-1)
       return value;
      else
       return '?';
   }

   public int read(byte[] fileData,int offset,int length)throws IOException
   {
     int result = in.read(fileData,offset,length);

       for(int i = offset;i < offset+result;i++)
       {
        if(fileData[i] == 10 || fileData[i] == 13 || fileData[i] == 9 || fileData[i] == -1);
        else if(fileData[i] < 32 || fileData[i] > 126)
        fileData[i] = (byte) '?';
       }
     return result;
   }

   public static void main(String[] args)throws IOException
   {

      System.out.println();
      for(int i = 0; i<args.length; i++)
      {
       FileInputStream fin = new FileInputStream(args[i]);
      
       FilterStreamExample pin = new FilterStreamExample(fin);


        while(true)
        {
         int c = pin.read();
         if(c == -1)
         break;

         System.out.print((char)c);
        }
      }
      System.out.println();

    }
 }

