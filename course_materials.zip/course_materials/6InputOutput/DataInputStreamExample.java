import java.io.*;

class DataInputStreamExample
{

  public static void main(String args[])throws IOException
  {
   System.out.println();

    try
    {
      DataInputStream  in = new DataInputStream(new BufferedInputStream(new FileInputStream("OutputFiles\\MyText.txt")));

      System.out.println("Reading From File : MyText.txt");
      System.out.print("\nContents of file are :");

       while(in.available() != 0)
         System.out.print((char)in.readByte());

      System.out.println();
    }
    catch(FileNotFoundException fnfe)
    {
     System.out.println("Exception fnfe :"+fnfe);
     System.exit(0);
    }
    catch(IOException ioe)
    {
     System.out.println("Exception ioe:"+ioe);
    }
  }
}
