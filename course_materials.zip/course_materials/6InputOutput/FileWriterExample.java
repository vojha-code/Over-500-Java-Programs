import java.io.*;

class FileWriterExample
{

  public static void main(String args[])throws IOException
  {

    try
    {

      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
      String strText;

      do
      {
        System.out.print("\nEnter the Text :");
        strText = br.readLine();
        strText = strText.trim();

      }while(strText.length() == 0);

      System.out.println("Yout entered Text is :"+strText);
            

      Reader inReader  = new StringReader(strText);
      Writer outWriter = new FileWriter("OutputFiles\\FileWrite.txt");

      int readChar;

      System.out.println("\nThe content written to file FileWrite.txt");

      while((readChar = inReader.read()) != -1)
      {
        outWriter.write(Character.toUpperCase((char)readChar));
        System.out.print(Character.toUpperCase((char)readChar));
      }

      System.out.println();

      outWriter.write('\n');

      outWriter.flush();
      outWriter.close();

    }
    catch(IOException e)
    {
     System.out.println(e);
    }
    catch(Exception e)
    {
     System.out.println(e);
    }
  }
}


                                   
