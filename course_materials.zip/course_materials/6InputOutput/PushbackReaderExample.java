import java.io.*;

public class PushbackReaderExample
{

  public static void main(String args[])throws Exception
  {

    char  buffer[] = {'I','B','M'};
    char  alpha;

    CharArrayReader car = new CharArrayReader(buffer);
    PushbackReader pbr = new PushbackReader(car,1);

    alpha = (char)pbr.read();
    System.out.println(alpha);

    alpha = (char)pbr.read();
    System.out.println(alpha);

    pbr.unread(alpha);

    alpha = (char)pbr.read();
    System.out.println(alpha);
  }
}




