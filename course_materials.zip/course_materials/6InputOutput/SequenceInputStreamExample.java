import java.io.*;
import java.util.*;

class Files implements Enumeration
{

  private String[] listOfFiles;
  private int current = 0;

  public Files(String[] listOfFiles)
  {
    this.listOfFiles =  listOfFiles;
  }

  public boolean hasMoreElements()
  {
   if(current < listOfFiles.length)
    return true;
   else
    return false;
  }

  public Object nextElement()
  {
   InputStream in = null;

   if(!hasMoreElements())
     throw new NoSuchElementException("No "+"more files");
   else
    {
     String nextFile = listOfFiles[current];
     current++;

      try
       {
        in = new FileInputStream(nextFile);
       }
       catch(FileNotFoundException e)
       {
        System.err.println("Unable to Open file : "+nextFile);
        System.exit(0);
       }
     }
     return in;
  }
}

public class SequenceInputStreamExample
{

  public static void main(String args[])throws IOException
  {

    if(args.length != 2)
    {
     System.err.println("\nType the following as comandline arrgument :");
     System.out.println("java SequenceInputStreamExample file 1 & file2");
     System.exit(0);
    }

    Files file = new Files(args);

    SequenceInputStream s = new SequenceInputStream(file);

    int c;

       while( (c = s.read()) != -1)
         System.out.write(c);

       s.close();

  }
}


    
   

 

