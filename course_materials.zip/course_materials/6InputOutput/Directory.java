import java.*;
import java.io.*;

class Directory
{

  public static void main(String args[])
  {

    System.out.println();
    String directoryName = "F:\\Current\\6InputOutput";

    try
    {

      File f = new File(directoryName);

      if(!f.exists())
        throw new FileNotFoundException("File "+f.getName() +" not found");

      if(f.isDirectory())
      {
         System.out.println("Directory of "+directoryName+"\n");

         String s[] = f.list();

         for(int i = 0; i< s.length ; i++)
         {
           File child  = new File(f,s[i]);

           if(f.isDirectory())
             System.out.println(s[i] +" is a sub " +" directory");
           else
             System.out.println(s[i] +" is a file");
         }
       }
       else
         System.out.println(directoryName + " is not a directory ");
    }
    catch(FileNotFoundException e)
    {
      System.out.println(e);
    }
    catch(Exception e)
    {
     System.out.println(e);
    }
    finally
    {
     System.out.println();
    }

 }
}





