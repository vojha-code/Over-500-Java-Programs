import java.io.*;

class FileInputStreamExample
{
 public static void main(String args[])throws Exception
 {
  try
   {
     int size;
     InputStream f = new FileInputStream("OutputFiles\\MyText.txt");
     size = f.available();

     System.out.println();
     System.out.println("Reading from file     : MyText.txt");
     System.out.println("Total available butes : "+size);
     System.out.println();

      for(int i = 0;i < size; i++)
      {
       System.out.print((char)f.read());
      }

     System.out.println();
     f.close();

   }
   catch(FileNotFoundException fne)
   {
    System.out.println("Exception FNE :"+fne);
   }
   catch(Exception e)
   {
    System.out.println("Exception 1 :"+e);
   }
 }
}



