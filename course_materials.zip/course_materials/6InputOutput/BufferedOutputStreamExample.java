import java.io.*;

public class BufferedOutputStreamExample
{

  public static void main(String args[])throws IOException
  {

    try
    {
      if(args.length != 2)
      {
       System.err.println("Type the following command line argumment ");
       System.err.println("The BufferedOutputStreamExample TextFileName BufferSize");
       System.exit(1);
      }

      int bufferSize = Integer.parseInt(args[1]);
      FileOutputStream fos = new FileOutputStream(args[0]);

      BufferedOutputStream bos = new BufferedOutputStream(fos,bufferSize);

      DataOutputStream dos = new DataOutputStream(bos);

      for(int i = 65;i<91 ; i++)
      {
        dos.writeInt(i);
        System.out.print((char)i+" ");
      }

      System.out.println();
      dos.close();
    }
    catch(FileNotFoundException e)
    {
     System.out.println("The File "+args[0]+" not Found");
     System.exit(0);
    }
    catch(IllegalArgumentException e)
    {
     System.out.println(" The buffer size can not be 0 or -");
     System.exit(0);
    }
 }
}


