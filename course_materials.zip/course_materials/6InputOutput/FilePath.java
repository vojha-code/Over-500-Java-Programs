import java.io.*;

class FilePath
{
 public static void main(String args[])
 {

 // String filepath = "F:\\Current\\6InputOutput\\OutputFiles\\MyText.txt";
  String filepath = "F:"+File.separator+"Current"+File.separator+"6InputOutput"
                    +File.separator+"OutputFiles"+File.separator+"MyText.txt";

  File fp = new  File(filepath);

      if (fp.exists())
       {
         System.out.println("\nName of File        :"+fp.getName());
         System.out.println("Absolute Path       :"+fp.getPath());
         System.out.println("Parent Directory    :"+fp.getParent());
         System.out.println("File Size (in Byte) :"+fp.length());
       }
      else
       {
        System.out.println("File "+fp.getName() +" Not Found");
       }
 }
}

          
 
