import java.io.*;

class LineNumberReaderExample
{

  public static void main(String args[])
  {
   System.out.println();

    if(args.length !=2)
    {
     System.out.println("Input the following as a command line arrgument");
     System.out.println("Type the LineNumberReaderexample SearchWord TextFileName ");
     System.exit(1);
    }

    String searchWord = args[0];
    String fileName   = args[1];
    boolean found     = false;
    
    String strText;

    try
    {

      FileReader fr = new FileReader(fileName);
      LineNumberReader lr = new LineNumberReader(fr);

      while((strText = lr.readLine()) != null)
      {
        if(strText.indexOf(searchWord) != -1)
        {

          int lineNumber = lr.getLineNumber();

          System.out.println(fileName +"  ["+lineNumber+"]  "+strText);

          found = true;
        }
      }

      if(!found)
         System.out.println("The word "+searchWord+" is not found in file " +fileName);


      lr.close();
      
    }
    catch(FileNotFoundException e)
    {
      System.out.println("File Not Found ");
    }
    catch(IOException e)
    {
      System.out.println(e);
    }

  }
}
         


       

