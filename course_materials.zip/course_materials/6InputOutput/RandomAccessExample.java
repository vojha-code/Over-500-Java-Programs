import java.io.*;

public class RandomAccessExample
{


  static String fileName = "F:\\Current\\6InputOutput\\OutputFiles\\Ranodm.txt";
  final static int CHAR_POSITION = 2;


  public static void main(String args[])
  {
   try
    {
     RandomAccessExample random = new RandomAccessExample();

     random.writeAlpha();
     random.readAlpha();

    }
    catch(Exception e)
    {
     System.out.println(e);
    }
   }

  public void writeAlpha()throws IOException
  {

    //String fileName = "F:\\Current\\6InputOutput\\OutputFiles\\Ranodm.txt";


    File dataFile = new File(fileName);
    RandomAccessFile raFile = new RandomAccessFile(dataFile,"rw");

    System.out.println("The data written to file Random.txt are :");

     for(int i = 65;i<90;i++)
      {
        raFile.writeChar(i);
        System.out.print((char)i+" ");
      }

     System.out.println();
     raFile.close();
  }

  public void readAlpha()throws IOException
  {

   try
    {

      File dataFile = new File(fileName);
      RandomAccessFile raFile = new RandomAccessFile(dataFile,"r");

      System.out.println("\nRandom Alphabates from fileRandom.txt\n");

      long length = raFile.length();
      //System.out.println("Length :"+length);

      int i=0;

       //for(i = CHAR_POSITION ; i<length; i++ );
        // {
          // raFile.seek(i);
                
           System.out.print(raFile.readLine());

        // }
       raFile.close();
     }
     catch(FileNotFoundException fne)
      {
        System.out.println("Eroor :"+fne);
        System.exit(0);
      }
     catch(IOException ioe)
      {
        System.out.println("Error1 :"+ioe);
      }
   }
}
