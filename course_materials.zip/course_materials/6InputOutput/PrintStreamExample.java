import java.io.*;

class PrintStreamExample
{

  public static void main(String args[])
  {

    try
    {
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream("OutputFiles\\word.txt"));

      PrintStream ps = new PrintStream(new BufferedOutputStream(new FileOutputStream("OutputFiles\\PrintFile.txt")));

      System.setIn(bis); //setting Standered Input
      System.setOut(ps); //setting Standered Output
      System.setErr(ps); //setting Standered Error

      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

      String strText;

      while((strText = br.readLine()) != null)
        System.out.println(strText);

      System.out.println("\n\nOutput is written to PrintFile.txt");

      ps.close();

    }
    catch(FileNotFoundException e)
    {
     System.out.println("File Not Found ");
     System.exit(0);
    }
    catch(IOException e)
    {
     e.printStackTrace();
    }
 }
}



