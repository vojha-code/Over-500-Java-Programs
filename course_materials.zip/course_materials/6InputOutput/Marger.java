import java.io.*;

class Marger
{

  public static void main(String args[])
  {

    String line1=" ", line2=" ";
    int count1=0, count2=0;

    try
    {
      FileReader fr1 =  new FileReader("OutputFiles\\dat1.txt");
      FileReader fr2 =  new FileReader("OutputFiles\\dat2.txt");
      BufferedReader br1 =  new BufferedReader(fr1);
      BufferedReader br2 =  new BufferedReader(fr2);
      FileWriter fw = new FileWriter("OutputFiles\\dat3.txt");

      while(((line1 = br1.readLine()) != null) && ((line2 = br2.readLine()) != null))
      {
        fw.write(line1+"\n");
        fw.write(line2+"\n");
      }

      fr2.close();
      br1.close();
      fw.close();

      fr1 = new FileReader("OutputFiles\\dat3.txt");
      br1 = new BufferedReader(fr1);

      System.out.println("\nThe content of file dat3.txt is\n");

      while((line1 = br1.readLine()) != null )
        System.out.println(line1);

      br1.close();
      fr1.close();

    }
    /*catch(FileNotFoundException e)
    {
     System.out.println(e);
    } */
    catch(Exception e)
    {
     System.out.println(e);
    }
  }
}

