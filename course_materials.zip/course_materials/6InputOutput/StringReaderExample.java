import java.io.*;

public class  StringReaderExample
{
  static { System.out.println(); }

   public static void main(String args[])throws IOException
   {

     try
     {

       String strText = " Mr.Varun is an Engineer." ;

       StringReader strRead = new StringReader(strText);

       int i;

       while((i = strRead.read()) != -1)
         System.out.print((char)i);

       System.out.println();

     }
     catch(IOException e)
     {
      System.out.println(e);
     }
   }
}

