/* ########################################
10/27/09 testing to see if removing this js code affects anything - email teresa.london@sun.com if you see an issue
######################################## */
