try {
var pageTracker = _gat._getTracker("UA-7451780-1");
pageTracker._trackPageview();
} catch(err) {}