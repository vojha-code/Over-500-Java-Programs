import java.rmi.*;

public interface Validiator extends Remote
{

   String  validiate(String aUserName,String aPassword)throws RemoteException;

}   

