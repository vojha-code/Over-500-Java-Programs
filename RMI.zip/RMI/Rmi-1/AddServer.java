import java.net.*;
import java.rmi.*;

public class AddServer
{

  public static void main(String argc[])
  {
    AddServerImplementation addServerImplementation;

    try
    {
      addServerImplementation = new AddServerImplementation();

      Naming.rebind("AddServer",addServerImplementation);
    }
    catch(Exception e)
    {
      System.out.println(e);
    }  

  }
}
