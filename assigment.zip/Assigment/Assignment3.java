class A //create class 
{
  static int s=20;
}
class Assignment3 //creating class
{

   static int i=10;//deaclearing static variable
   
   public static void main(String args[]) //calling main
   {

    System.out.println(i);//acessing without object help

    System.out.println(Assignment3.i); //acessing with classname

    Assignment3 a=new Assignment3();
    System.out.println(a.i);//accsseing with object help

    System.out.println(A.s);//access static var of diff class with class name

   }
}
    
  

