class BaseClass
{
    void m1()
    {
        System.out.println("I M Base Class m1 method");
    }
    void m1(int a)
    {
        System.out.println("Method OverLoading location: BaseClass :Value :"+a);
    }
}
class SubClass extends BaseClass
{
    void m1(int y)
    {
        System.out.println("Method Overriding Location: SubClass :Value :"+y);
    }
    void m1(int y,int x)
    {
      System.out.println("Method Overloading Location: SubClass :Value :"+y+" & "+x);
    }
}
public class Assignment7 {
    
    public static void main(String args[])
    {
        SubClass obj=new SubClass();

        BaseClass obj1=obj;

        obj1.m1();

        obj1=new BaseClass();
        obj1.m1(1);

        obj.m1(2);
        obj.m1(3,4);

    }

}
