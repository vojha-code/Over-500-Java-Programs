/*class Animal
{
    public void eat()throws Exception{}        
}*/
class Cow //extends Animal
{
    public void eat()throws Exception
    {
        System.out.println("Eat Meat");
        throw new Exception("Not Able to eat");
    }
}
public class Assignment6 {
 
    public static void main(String args[])
    {
        Cow obj=new Cow();
        
        try
        {
          obj.eat();
        }
        catch(Exception e)
        {
            System.out.println("Exception :"+e);
        }
    }
}
