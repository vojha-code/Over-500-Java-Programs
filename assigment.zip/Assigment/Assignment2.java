class Fibonaci extends Thread //extending thread class
{
 Fibonaci()  //declearing constructor
 {
   start(); //calling start to run the thread
 }
 public void run() //implementing run method
 {
   try
   {
     int i=0,a=0,b=1,c=0; // declearing variables

     System.out.print(a+" "); // printing a 
     Thread.sleep(1000); //calling sleep for wait 1000ns
     System.out.print(b); // printing b value

      while(i<=10) //loop 10 times
      {
        c=a+b; //adding a and b to get follow digit in serise
        System.out.print(" "+c); //printing value c

        a=b; //assigning value b to a
        b=c; //assigning value c to b

        i++; //increamenting loop variable i
        Thread.sleep(1000); //calling sleep for wait 1000ns
      }
   }
   catch(Exception e) //catching the exception
   {
    System.out.println(e); //printing the exception catched
   }
 }
}
class Assignment2
{
  public static void main(String args[])
  {
    Fibonaci fb=new Fibonaci();
  }
}

 
