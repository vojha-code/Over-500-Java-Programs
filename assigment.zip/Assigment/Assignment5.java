class SuperClass
{
 int a=10;

  int method()
  {
   return 1;
  }

}
class SubClass extends SuperClass
{
 int b=20;

 int method()
 {
   return 2;
 }
}

class Assignment5
{
  public static void main(String args[])
  {
    /*SuperClass obj= new SuperClass();
    SubClass obj1= obj;*/ 

    SubClass obj= new SubClass();
    SuperClass obj1=obj;
    
    
    System.out.println(obj.method());
    System.out.println(obj.method());

  } 
} 

