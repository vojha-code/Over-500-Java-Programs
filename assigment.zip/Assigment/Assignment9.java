interface I
{
    public void m1();
    public void m2();
    public void m3();
    public void m4();
}

abstract class A implements I {
    
   public void  m1()  
   {
       System.out.println("I M m1");
   }
   public void m2()
   {
       System.out.println("I M m2");
   }
}

class Assignment9 extends A
{

   public void m3()
   {
       System.out.println("I M m3");
   }
   public void m4()
   {
       System.out.println("I M m4");
   }


   public static void main(String args[])
   {
       Assignment9 obj= new Assignment9();

       obj.m1();
       obj.m2();
       obj.m3();
       obj.m4();
   }
}
