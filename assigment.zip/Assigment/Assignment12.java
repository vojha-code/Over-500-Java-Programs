public class Assignment12 {
    
    void ThrowExcp()throws ArithmeticException
    {
         try
         {
             int a=5/0;
             System.out.print("Div"+a);
             throw new ArithmeticException("Divided By Zero");
                        
         }
         catch(Exception e)         
         {
             System.out.println("Exception Cought :"+e);
         }
         finally
         {
             System.out.println("Hello");
         }
    }

     public static void main(String args[])
     {
         Assignment12 obj=new Assignment12();
         obj.ThrowExcp();
       
     }
    
}
