public class Assignment10 {
    
   public static void main(String args[])
   {
       try
       {
           int i;
           String s="V";
           
           i=Integer.parseInt(s);
           System.out.println("Value of I :"+i);
                 
        }
       catch(NumberFormatException e)
       {
           System.out.println("Exception :"+e);
       }
   }
}
