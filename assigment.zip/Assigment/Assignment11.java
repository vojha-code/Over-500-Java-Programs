
public class Assignment11 {
  
    public static void main(String args[])
    {
        
        try
        {
            int a=5;
            int b=0;
            int d=a/b;
            System.out.println("The div:"+d);
            int array[]=new int[4];
            for(int i=0;i<6;i++)
            {
                array[i]=i+2;
                System.out.println("The array["+i+"]:"+array[i]);
            }
        }
        catch(ArithmeticException e)
        {
            System.out.println("Arithmetic Exception -> "+e);
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
          System.out.println("Array Index Out Of Bounds Exception->"+e);
        }
    }
    
}
