class Thread1 extends Thread                        //extending thread class
{
 Thread1(String s)                                  //declearing constructor
 {               
   super(s);                                        //calling super to set thread name
   System.out.println("My Thread :"+this);          //printing the current thread name
   start();                                         //calling thread  to run
 }
 public void run()                                  //implementing run method
 {
   try // start try
   {
    for(int i=0;i<10;i++)                            // 10 times loop
    {
     System.out.println("Sourav Ganguly");           //print name
     Thread.sleep(1000);                             //call 1000ns sleep to current thread
    }
   }
   catch(Exception e)                                //catching exception 
   {
    System.out.println(e);                           //printing exception catched
   }
  }
}
class Thread2 extends Thread                         //extending thread class
{
 Thread2(String s)                                   // declearing constructor
 {
   super(s);                                         //calling super to set thread name
   System.out.println("My Thread :"+this);           // printing the current thread name
   start();                                          //calling thread  to run
 }
 public void run()                                   //implementing run method
 {
   try // start try
   {
    for(int i=0;i<10;i++)                             // 10 times loop
    { 
     System.out.println("Sachin Ramesh Tendulkar");    //print name
     Thread.sleep(1000);                              //call 1000ns sleep to current thread
    }
   }
   catch(Exception e)                                 //catching exception 
   {
    System.out.println(e);                            //printing exception catched
   }
  }
}

public class Assignment1
{
  public static void main(String args[])
  {
   Thread1 th1=new Thread1("1st");                  //instatiation of class Thread1 
   Thread2 th2=new Thread2("2nd");                  //instatiation of class Thread2
  }
}

  


