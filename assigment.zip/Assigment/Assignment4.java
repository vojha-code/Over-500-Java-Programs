class A //create class 
{
  static int method()  //declearing static method
   {
     System.out.print("I class A  method :");
     return 1;
   }

}
class Assignment4 //creating class
{

   static int method1()  //declearing static method
   {
     System.out.print("I class A4 method :");
     return 2;
   }

   
   public static void main(String args[]) //calling main
   {

    System.out.println(method1());             //acessing without object help

    System.out.println(); // printing a blank line

    System.out.println(Assignment4.method1()); //acessing with classname

    System.out.println(); // printing a blank line

    Assignment4 a=new Assignment4();
    System.out.println(a.method1());           //accsseing with object help

    System.out.println(); // printing a blank line

    System.out.println(A.method());            //access static var of diff class with class name
 
   }
}
