class A
{
    static int v=10;
  
    void m1()
    {
      B obj=new B();
      obj.m2(1);
      B.m2(2);
    }  
   
    public static class B
    {
      static void m2(int a)
      {
        System.out.println("I M Innerclass method "+a);
      }
      {
          System.out.println("The variable from class A :v :"+v);
      }
    }
}
public class Assignment8 {
    
    public static void main(String args[])
    {
        A obj=new A();
        obj.m1();

        A.B obj1=new A.B();
        obj1.m2(3);
    }
    
    
}
